// ************************ Processing Grid Role Based Check ***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Role based check in Processing Grid
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking whether the grid data is displayed according to the user role
// 2.Checking whether the grid columns are visible according to the user role



import processing from '../functions/processing'
const processing_data = require('../queries/processing')
let envi = Cypress.env('ENV')
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';




describe('Processing Grid Role based',function(){

  beforeEach(() => {
    cy.viewport(2500, 1000);
  });


  


  it.only('Launching Consumer Data',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{

    dup.launching_consumer_data()
     cy.wait(30000)
   })

  it.only('changing the role to ww_program_manager',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    processing.role_change(config,'1')
    dup.launching_consumer_data()
})

it.only('TC01 - Checking for Inprocess tab and subdescription',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
  processing.uploadHistoryButton_click()
  processing.InprocessTab_validation(processing_data.inprocesstab_title,processing_data.inprocesspage_subdesc)
  cy.wait(30000)
  
})

it.only('TC02 - Checking the columns for ww_program_manager',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
  processing.columns_validaiton(['','File Reference Id',"Partner","","File Name","Uploaded Date (UTC)","Upload Mode","Status",
  "Validation Report","Enriched File"])

})


it.only('TC03 - Checking the grid count for ww_program_manager',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.grid_count_all(config)

})



it.only('changing the role to Account Manager',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
  processing.role_change(config,'2')
  cy.reload()
  cy.wait(30000)
})

it.only('TC01 - Checking for Inprocess tab and subdescription',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.uploadHistoryButton_click_1()
processing.InprocessTab_validation(processing_data.inprocesstab_title,processing_data.inprocesspage_subdesc)
cy.wait(30000)

})

it.only('TC04 - Checking the columns for account_manager',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.columns_validaiton(['','File Reference Id',"Partner","","File Name","Uploaded Date (UTC)","Upload Mode","Status",
"Validation Report","Enriched File"])

})


it.only('TC05 - Checking the grid count for account_manager',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.grid_count_org(config)

})



it.only('changing the role to Intel Bizops',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
  processing.role_change(config,'3')
  cy.reload()
  cy.wait(30000)
})

it.only('TC01 - Checking for Inprocess tab and subdescription',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.uploadHistoryButton_click()
processing.InprocessTab_validation(processing_data.inprocesstab_title,processing_data.inprocesspage_subdesc)
cy.wait(30000)

})

it.only('TC06 - Checking the columns for Intel Bizops',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.columns_validaiton(['','File Reference Id',"Partner","","File Name","Uploaded Date (UTC)","Upload Mode","Status",
"Validation Report","Enriched File"])

})


it.only('TC07 - Checking the grid count for Intel Bizops',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.grid_count_all(config)

})




it.only('changing the role to Partner Data Submitter',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
  processing.role_change(config,'5')
  cy.reload()
  cy.wait(30000)
})

it.only('TC01 - Checking for Inprocess tab and subdescription',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.uploadHistoryButton_click_1()
processing.InprocessTab_validation(processing_data.inprocesstab_title,processing_data.inprocesspage_subdesc)
cy.wait(30000)

})

it.only('TC08 - Checking the columns for Partner Data Submitter',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.columns_validaiton(['','File Reference Id',"Partner","","File Name","Uploaded Date (UTC)","Upload Mode","Status"])

})


it.only('TC09 - Checking the grid count for Partner Data Submitter',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.grid_count_org(config)

})



it.only('changing the role to Third party Data Submitter',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
  processing.role_change(config,'6')
  cy.reload()
  cy.wait(30000)
})

it.only('TC01 - Checking for Inprocess tab and subdescription',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.uploadHistoryButton_click_1()
processing.InprocessTab_validation(processing_data.inprocesstab_title,processing_data.inprocesspage_subdesc)
cy.wait(30000)

})

it.only('TC10 - Checking the columns for Third party Data Submitter',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.columns_validaiton(['','File Reference Id',"Partner","","File Name","Uploaded Date (UTC)","Upload Mode","Status"])

})


it.only('TC11 - Checking the grid count for Third party Data Submitter',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
processing.grid_count_org(config)

})


it.only('changing the role to Intel Bizops',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
  processing.role_change(config,'3')
})




















    })
