// ************************ Encrypting the Sensitive Information***********************************
// Created by Vignesh Sekar
//
// This page is used to encrypt the sensitive information using the crypto library
// Give the values which you want to encrypt inside the encrypt function and get the encrypted version of the secret value
// 

const { encrypt, decrypt } = require("./crypto");

const hash_1 = encrypt(``);

console.log(hash_1);

console.log(decrypt(hash_1));
