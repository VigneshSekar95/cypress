// ************************ Modify Template Screen ***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Modify Template by Partner screen
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking the dropdown values of all the dropdowns
// 2.Checking the error messages are populated as expected when adding new field for a template
// 3.Checking the update button is disabled when there is no change made
// 4.Checking the is-active button functionality
// 5.Add switch and Edit the field names for the particular template
// 6.Inactivate and Activate a Template for a particular template version

import modifytmplt from '../functions/modify_template'
let envi = Cypress.env('ENV')
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';


describe("Modify Template", () => {
    beforeEach(() => {
      cy.viewport(1400, 1000);
    });

    afterEach(function () { 

        if(this.currentTest.title == 'TC15 - Updating a record for a template'){
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `                update cdm_core.delim_templt_fld_def set fld_eff_dtm='2030-09-09T00:00:00+00:00', fld_expr_dtm='2033-09-09T00:00:00+00:00' where templt_fld_id =(
                  Select  fl.templt_fld_id  from cdm_core.templt t
                          inner join cdm_core.delim_templt_fld_def fl on fl.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = fl.pltfrm_cd 
                          and t.dset_cd = fl.dset_cd and fl.tier2_3_hier_id = t.tier2_3_hier_id
                          inner join cdm_core.tier2_3_hier ti on fl.tier2_3_hier_id = ti.tier2_3_hier_id
                  where fl.dset_cd='dummy4_dataset' and fl.pltfrm_cd='dummy1_plt' and t.templt_ver_nm='Desktop' and ti.tier2_hier_nm='dummy2_sub' and fl.fld_nm='Field3')`
              }).then((result) => {
                
              })
           }


           if(this.currentTest.title == 'TC15 - Updating a record for different template template'){
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `                update cdm_core.delim_templt_fld_def set fld_eff_dtm='2030-09-09T00:00:00+00:00', fld_expr_dtm='2033-09-09T00:00:00+00:00' where templt_fld_id =(
                  Select  fl.templt_fld_id  from cdm_core.templt t
                          inner join cdm_core.delim_templt_fld_def fl on fl.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = fl.pltfrm_cd 
                          and t.dset_cd = fl.dset_cd and fl.tier2_3_hier_id = t.tier2_3_hier_id
                          inner join cdm_core.tier2_3_hier ti on fl.tier2_3_hier_id = ti.tier2_3_hier_id
                  where fl.dset_cd='dummy4_dataset' and fl.pltfrm_cd='dummy1_plt' and t.templt_ver_nm='Tablet' and ti.tier2_hier_nm='dummy2_sub' and fl.fld_nm='Field1')`
              }).then((result) => {
                
              })
           }


           if(this.currentTest.title == 'TC18 - checking the entry in backend for a template'){
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `delete from cdm_core.templt_switc t 
                where templt_id in  (select templt_id from cdm_core.templt where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt') and t.switc_cd='switch_test1'`
              }).then((result) => {
                
              })

              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `       delete from  cdm_core.delim_templt_fld_def where templt_fld_id in (
                  Select  fl.templt_fld_id  from cdm_core.templt t
                          inner join cdm_core.delim_templt_fld_def fl on fl.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = fl.pltfrm_cd 
                          and t.dset_cd = fl.dset_cd and fl.tier2_3_hier_id = t.tier2_3_hier_id
                          inner join cdm_core.tier2_3_hier ti on fl.tier2_3_hier_id = ti.tier2_3_hier_id
                  where fl.dset_cd='dummy4_dataset' and fl.pltfrm_cd='dummy1_plt' and t.templt_ver_nm='Tablet' and ti.tier2_hier_nm='dummy2_sub' and fld_nm in ('Field4','Field5'))`
              }).then((result) => {
                
              })


              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `delete from cdm_core.switc_lkup where switc_lkup.switc_cd='switch_test1'`
              }).then((result) => {
                
              })
           }

           if(this.currentTest.title == 'TC18 - checking the entry in backend for different template'){
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `delete from cdm_core.templt_switc t 
                where templt_id in  (select templt_id from cdm_core.templt where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt') and t.switc_cd='switch_test1'`
              }).then((result) => {
                
              })

              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `       delete from  cdm_core.delim_templt_fld_def where templt_fld_id in (
                  Select  fl.templt_fld_id  from cdm_core.templt t
                          inner join cdm_core.delim_templt_fld_def fl on fl.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = fl.pltfrm_cd 
                          and t.dset_cd = fl.dset_cd and fl.tier2_3_hier_id = t.tier2_3_hier_id
                          inner join cdm_core.tier2_3_hier ti on fl.tier2_3_hier_id = ti.tier2_3_hier_id
                  where fl.dset_cd='dummy4_dataset' and fl.pltfrm_cd='dummy1_plt' and t.templt_ver_nm='Desktop' and ti.tier2_hier_nm='dummy2_sub' and fld_nm in ('Field4','Field5'))`
              }).then((result) => {
                
              })


              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `delete from cdm_core.switc_lkup where switc_lkup.switc_cd='switch_test1'`
              }).then((result) => {
                
              })
           }


          //  if(this.currentTest.title == 'TC18 - checking the entry in backend'){
          //   cy.task("DATABASE", {
          //       dbConfig: Cypress.env(config),
          //       sql: `delete from cdm_core.templt_switc t 
          //       where templt_id = (select templt_id from cdm_core.templt where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt') and t.switc_cd='switch_test1'`
          //     }).then((result) => {
                
          //     })

          //     cy.task("DATABASE", {
          //       dbConfig: Cypress.env(config),
          //       sql: `       delete from  cdm_core.delim_templt_fld_def where templt_fld_id in (
          //         Select  fl.templt_fld_id  from cdm_core.templt t
          //                 inner join cdm_core.delim_templt_fld_def fl on fl.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = fl.pltfrm_cd 
          //                 and t.dset_cd = fl.dset_cd and fl.tier2_3_hier_id = t.tier2_3_hier_id
          //                 inner join cdm_core.tier2_3_hier ti on fl.tier2_3_hier_id = ti.tier2_3_hier_id
          //         where fl.dset_cd='dummy4_dataset' and fl.pltfrm_cd='dummy1_plt' and t.templt_ver_nm='Tablet' and ti.tier2_hier_nm='dummy2_sub' and fld_nm in ('Field4','Field5'))`
          //     }).then((result) => {
                
          //     })


          //     cy.task("DATABASE", {
          //       dbConfig: Cypress.env(config),
          //       sql: `delete from cdm_core.switc_lkup where switc_lkup.switc_cd='switch_test1'`
          //     }).then((result) => {
                
          //     })
          //  }


           if(this.currentTest.title == 'TC20 - Updating json schema and adding switch'){


            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `delete from cdm_core.templt_switc t 
                where templt_id = (select templt_id from cdm_core.templt where dset_cd='json based dataset' and pltfrm_cd='json_plt') and t.switc_cd='switch_test1'`
              }).then((result) => {
                
              })

              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `update cdm_core.templt set json_schma='my new json' where dset_cd='json based dataset' and pltfrm_cd='json_plt'`
              }).then((result) => {
                
              })


             


              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `delete from cdm_core.switc_lkup where switc_lkup.switc_cd='switch_test1'`
              }).then((result) => {
                
              })
           }


           if(this.currentTest.title == 'TC22 - Updating xml schema and adding switch'){


            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `delete from cdm_core.templt_switc t 
                where templt_id = (select templt_id from cdm_core.templt where dset_cd='xml_dataset' and pltfrm_cd='xml_plt') and t.switc_cd='switch_test1'`
              }).then((result) => {
                
              })

              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `update cdm_core.templt set xml_schma='my xml json' where dset_cd='xml_dataset' and pltfrm_cd='xml_plt'`
              }).then((result) => {
                
              })


             


              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `delete from cdm_core.switc_lkup where switc_lkup.switc_cd='switch_test1'`
              }).then((result) => {
                
              })
           }


           if(this.currentTest.title == 'TC26 - Adding localisation text to the field name'){
            cy.task("DATABASE", {
              dbConfig: Cypress.env(config),
              sql: `delete from  cdm_core.delim_templt_fld_def where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt' and fld_nm in ('維涅什','виньеш')`
            }).then((result) => {
              
            })
           }

           if(this.currentTest.state === 'failed'){
            cy.reload()
            cy.wait(10000)
           }

    })


    it.only('Launching Consumer Data',()=>{

      dup.launching_consumer_data()
       cy.wait(10000)
     })
  
     
  it.only("Changing th role to Intel bizops", () => {
   dup.role_change(config,'3');
   dup.launching_consumer_data()
  });

it.only('TC01 - Going to Modify Template page',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.modify_template_page()
})


it.only('TC02 - Checking heading and subheading',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.heading_subheading()
})

it.only('TC03 - Dropdown Header',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.dropdown_header()
})

it.only('TC22 - Template Dropdown Validation',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.version_dropdown_validation(config,'Desktop')
})



it.only('TC04 - Selecting Template for a partner',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Tablet')
})






it.only('TC05 - Checking whether all data is reterived for a partner',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.backend_data_checking(config,'Tablet')
})

it.only('TC04 - Selecting Template for a partner',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.modify_template_page()
    modifytmplt.selecting_template('Desktop')
})






it.only('TC05 - Checking whether all data is reterived for a partner',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.backend_data_checking(config,'Desktop')
})




it.only('TC06 - Adding Empty Record ',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.empty_record()
})


it.only('TC07 - Adding Record with spaces',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.blank_spaces()
})


it.only('TC08 - Character with Above Max allowed limit ',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.max_allowed_limit()
})

it.only('TC09 - Start date less than end date ',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.startdate_less_than_end_date()
})


it.only('TC10 - Blank start date',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.blank_start_date()
})


it.only('TC11 - Duplicate Entry',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.duplicate_entry()
})


it.only('TC12 - Special Character Validation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.special_character()
})




it.only('TC13 - Update button disabled for not making changes',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.update_button_disabled()
})


it.only('TC14 - Checking Error message when start date > end date when updating  ',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.update_start_date_higher_than_end_date()
})


it.only('TC23 - Is_active - Change to todays date and null on inactive',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Desktop')
 // modifytmplt.updating_a_record_version(config)
 modifytmplt.is_active_todays_date()
})


it.only('TC24 - Is_active - Inactive on on changing to future date',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Desktop')
 // modifytmplt.updating_a_record_version(config)
 modifytmplt.inactive_button_future_date()
})


it.only('TC25 - Is_active - New Record Past ineffective date',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Desktop')
 // modifytmplt.updating_a_record_version(config)
 modifytmplt.new_record_past_ineffective_date()
})




it.only('TC15 - Updating a record for different template template',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Tablet')
  modifytmplt.updating_a_record_version(config)
})

it.only('TC15 - Updating a record for a template',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.modify_template_page()
    modifytmplt.selecting_template('Desktop')
    modifytmplt.updating_a_record(config)
})





it.only('TC16 - Checking Existing Switch Check for a template',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.modify_template_page()
    modifytmplt.selecting_template('Tablet')
    modifytmplt.switch_check(config,'Tablet')
})

it.only('TC16 - Checking Existing Switch Check for different template',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Desktop')
  modifytmplt.switch_check(config,'Desktop')
})

it.only('TC17 - Adding a Record',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.modify_template_page()
    modifytmplt.selecting_template('Tablet')
    modifytmplt.Adding_new_record_switch()
})



it.only('TC18 - checking the entry in backend for a template',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    modifytmplt.checking_backend_entry(config,'Tablet')
})


it.only('TC17 - Adding a Record',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Desktop')
  modifytmplt.Adding_new_record_switch()
})



it.only('TC18 - checking the entry in backend for different template',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.checking_backend_entry(config,'Desktop')
})



it.only('TC19 - Checking the Inactivate template for a particular version',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Desktop')
 modifytmplt.Inactivate_template(config)
})


it.only('TC20 - Checking the other version is active',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Tablet')
  modifytmplt.activate_template_version(config)
})


it.only('TC21 - Checking the Activate template',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Desktop')
 modifytmplt.activate_template(config)
})







it.only('TC26 - Adding localisation text to the field name',{
  retries: {
    runMode: 2,
    openMode: 2,
  },
},()=>{
  modifytmplt.modify_template_page()
  modifytmplt.selecting_template('Desktop')
 modifytmplt.localisation_test(config)
})

})












// it.skip('TC19 - Checking existing Json schema value',{
//   retries: {
//     runMode: 2,
//     openMode: 2,
//   },
// },()=>{
//   modifytmplt.modify_template_page()
//   modifytmplt.json_schema_existing(config)
// })


// it.skip('TC20 - Updating json schema and adding switch',{
//   retries: {
//     runMode: 2,
//     openMode: 2,
//   },
// },()=>{
//   modifytmplt.modify_template_page()
//   modifytmplt.updating_json_schema(config)
// })


// it.skip('TC21 - Checking existing xml schema value',{
//   retries: {
//     runMode: 2,
//     openMode: 2,
//   },
// },()=>{
//   modifytmplt.modify_template_page()
//   modifytmplt.xml_schema_existing(config)
// })

// it.skip('TC22 - Updating xml schema and adding switch',{
//   retries: {
//     runMode: 2,
//     openMode: 2,
//   },
// },()=>{
//   modifytmplt.modify_template_page()
//   modifytmplt.updating_xml_schema(config)
// })


// it.skip('TC23 - Checking the inactive button',{
// retries: {
//   runMode: 2,
//   openMode: 2,
// },
// },()=>{
// modifytmplt.modify_template_page()
// modifytmplt.selecting_template()
// modifytmplt.checking_inactive_button(config)
// })


