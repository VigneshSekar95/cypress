// ************************ New File Onbaord ***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the New File onboard page
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking the dropdown values of all the dropdowns in the Choose Partner and Template section
// 2.Checking whether the user can able to add values in the Choose Partner and related Attributes , Override Template Field Names, Modify/Add Template Switch section
// 3.Checking the input boxes of Retention and Others section
// 4.Ability to add override fields names
// 5.Checking the error messages in case if we add Retention and Restatement values above the allowed max limit
// 6. Checking whether user can able to onboard a dataset

import newonboard from '../functions/new_onboard'
let envi = Cypress.env('ENV')
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';
  
  describe("New_File_Onboard", function () {
    before(() => {
      cy.viewport(1400, 1000);
     // launch_app.launching_app();
     // config_new_temp.config_page(config_data.title, config_data.button);
    });
  
    beforeEach(() => {
      cy.viewport(1400, 1000);
      // setTimeout(() => {
      //   throw new Error("Test taking tooooo long!");
      // }, 60000 * 3);
    });

    afterEach(function () {

      if(this.currentTest.title === 'TC09 - NewOnboard add new ingestion mode dropdown') {
        newonboard.deleting_dummy_entries_ingestion_lkup(config)
      }


      if(this.currentTest.title === 'TC17 - NewOnboard Duplicate Dataset Onboard' 
      || this.currentTest.title === 'TC22 - NewOnboard Entering more than the allowed limit in Override Fields'){
        newonboard.deleting_dummy_entries_org_delim_templt_fld_ovrrd(config,'Desktop')
        newonboard.deleting_dummy_entries_org_allw_templt_ingest_mode(config,'Desktop')
        newonboard.deleting_dummy_entries_org_allw_templt(config,'Desktop')
        newonboard.deleting_dummy_entries_ingestion_lkup(config)
      }

      if(this.currentTest.title === 'TC24 - NewOnboard Duplicate Dataset Onboard') 
      {
        newonboard.deleting_dummy_entries_org_delim_templt_fld_ovrrd(config,'Tablet')
        newonboard.deleting_dummy_entries_org_allw_templt_ingest_mode(config,'Tablet')
        newonboard.deleting_dummy_entries_org_allw_templt(config,'Tablet')
        //newonboard.deleting_dummy_entries_ingestion_lkup(config)
      }

      if(this.currentTest.state === 'failed'){
        cy.reload()
        cy.wait(10000)
       }
    })

    it.only('Launching Consumer Data',()=>{

      dup.launching_consumer_data()
       cy.wait(10000)
     })
 
     
 it.skip("Changing th role to Intel bizops", () => {
   dup.role_change(config,'3');
   dup.launching_consumer_data()
 });




 

  it.only('Going to NewOnboard page',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.going_to_newonboard_page()
  })

  it.only('TC01 - New Onboard Page Title and Description Check',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.checking_title_description()
  })

 



  

  it.only('TC02 - New Onboard Section1 heading Check',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.checking_section1_heading()
  })

  it.only('TC03 - NewOnboard Section1 dropdown header check',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.checking_section1_dropdown_header()
  })

  it.only('TC04 - NewOnboard Check if Create_New_Entries button is redirecting to New template Creation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.checking_create_new_entry_button()
  })

  it.only("TC05 - Dropdown Selection Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.version_dropdown_validation(config,'Tablet')
  });



  it.only('TC06 - NewOnboard Section2 Heading',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.section2_heading_check()
  })

  it.only('TC07 - NewOnboard organisation dropdown',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.organisation_dropdown_check()
  })

  it.only('TC08 - NewOnboard ingestion mode dropdown',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.ingestion_mode_dropdown_check()
  })

  it.only('TC09 - NewOnboard add new ingestion mode dropdown',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.add_ingestion_mode()
  })


  it.only('TC10 - NewOnboard Retention before Archival check',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.retention_before_archival()
  })

  it.only('TC11 - NewOnboard Retention before Purge check',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.retention_before_purge()
  })

  it.only('TC12 - NewOnboard Restatement allowed days check',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.restatement_allowed_days()
  })

  it.only('TC13 - NewOnboard Collab Ind check',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.collab_indicator()
  })

  it.only('TC14 - NewOnboard File split Check',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.file_split_ratio()
  })

  it.only('TC15 - NewOnboard Org Template Check',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.org_tmplt_priority()
  })



  it.only('TC16 - NewOnboard Dataset Onboard Success',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.override_field_name()
  })

  it.only('TC17 - NewOnboard Duplicate Dataset Onboard',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.duplicate_dataset_onboard()
  })


  
  it.only('TC18 - NewOnboard Entering more than the allowed limit in Retention Fields',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.greater_integer_value()
  })

  it.only('TC19 - NewOnboard Entering more than the allowed limit in Restatement Field',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.greater_integer_value_restatement()
  })

  it.only('TC20 - NewOnboard Entering more than the allowed limit in Purge Field',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.greater_integer_value_purge()
  })

  it.only('TC21 - NewOnboard Entering more than the allowed limit in File Split Ratio Field',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.greater_numeric_value()
  })


  
  it.only('TC22 - NewOnboard Entering more than the allowed limit in Override Fields',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.greater_override_fields()
  })


  it.only('TC23 - Onboarding a new dataset for a template version',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.override_field_name('version')
  })


  it.only('TC24 - NewOnboard Duplicate Dataset Onboard',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
    newonboard.duplicate_dataset_onboard('version')
  })


})






it.skip('Deleting created dummy record',()=>{
  newonboard.deleting_dummy_entries_org_delim_templt_fld_ovrrd(config)
  newonboard.deleting_dummy_entries_org_allw_templt_ingest_mode(config)
  newonboard.deleting_dummy_entries_org_allw_templt(config)
//  newonboard.deleting_dummy_entries_tmplt_fields(config)
//   newonboard.deleting_dummy_entries_tmplt(config)
//   newonboard.deleting_dummy_entries_dset_lkup(config)
//   newonboard.deleting_dummy_entries_tier2_3_hier(config)
//   newonboard.deleting_dummy_entries_class_hier_lkup_tier2(config)
//   newonboard.deleting_dummy_entries_class_hier_lkup_tier3(config)
//   newonboard.deleting_dummy_entries_pltfrm_lkup(config)
  newonboard.deleting_dummy_entries_ingestion_lkup(config)
})

