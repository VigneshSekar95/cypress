// ************************ Configuration page - File Metadata Tables Check***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Metadata tables in the UI Configuration page
// 
// In this spec file, we are checking the below tables in the FileMeta section:
// 1.Organisation Id Type
// 2.Platform
// 3.Provider
// 4.Processing Pipeline Type
// 5.Processing Status
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Adding a Record and checking the record is available in the grid
// 2.Search for a Record in the Grid
// 3.Edit a  Record and Check the edited data is available in Grid
// 4.Pagination
// 5.Grid Data Validation
// 6.Is_active button functionality
// 7.Uniqueness Violation Check
// 8.Cheking the Maxallowed character for the input fields
// 9.Checking in the backend whether the new entries are created.






let envi = Cypress.env('ENV')
import config_page from '../functions/config_page'
let excel_data = require("../fixtures/output.json");
let character_50 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
let character_255 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';


describe("Configuration Page - II", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    before(() => {
      cy.viewport(1400, 1000);
    });
  
    beforeEach(() => {
      cy.viewport(1400, 1000);
    });

    afterEach(function(){
    if(this.currentTest.state === 'failed'){
      cy.reload()
      cy.wait(10000)
    
      
     }


     

    })

    it.only('Launching Consumer Data',()=>{

      dup.launching_consumer_data()
       cy.wait(10000)
     })
 
     
 it.only("Changing th role to Intel bizops", () => {
   dup.role_change(config,'3');
   dup.launching_consumer_data()
 });


  it.only("Going to Configuration page", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.config_page('Configuration', 'Configure Tables')
    
  });

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Organisation_Id_Type"
    ) {
      it.only("TC51 - Add a new Organisation Id Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('7')
        config_page.add_new_record('7',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Organisation Id Type',
          'Organisation Id Type Name',
          'Organisation Id Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Organisation_Id_Type"
    ) {
      it.only("TC52 - Search for a Record in the Organisation Id Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('7')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Organisation_Id_Type"
    ) {
      it.only("TC53 - Edit a  Organisation Id Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('7')
        config_page.edit('7',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Organisation Id Type',
          'Organisation Id Type Name',
          'Organisation Id Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Organisation_Id_Type"
    ) {
      it.only("TC54 - Organisation Id Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.action_pagination();
        config_page.going_to_table('7')
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Organisation_Id_Type"
    ) {
      it.only("TC55 - Organisation Id Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('7')
        config_page.griddata('select org_id_type_cd,org_id_type_dsc from cdm_accs_enttl.org_id_type_lkup order by cre_dtm desc',
        config,
        ['org_id_type_cd','org_id_type_dsc','Organisation Id Type Name','Organisation Id Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Organisation_Id_Type"
    ) {
      it.only("TC56 - Organisation Id Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('7')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Organisation_Id_Type"
    ) {
      it.only("TC57 - Organisation Id Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('7')
        config_page.backend_entry("select count(*) as cnt from cdm_accs_enttl.org_id_type_lkup where cre_dtm <> chg_dtm and org_id_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Organisation_Id_Type"
    ) {
      it.only("TC58 - Organisation Id Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('7')
        config_page.error_check('7',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Organisation_Id_Type"
    ) {
      it.only("TC59 - Organisation Id Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('7')
           config_page.add_new_record('7',
            character_50,
          character_255,
        'Add a new Organisation Id Type',
        'Organisation Id Type Name',
        'Organisation Id Type Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Organisation_Id_Type"
    ) {
      it.only("TC60 - Deleting Dummy Record for Organisation Id Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_accs_enttl.org_id_type_lkup where org_id_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_accs_enttl.org_id_type_lkup where org_id_type_cd='",character_50.substring(0,47),config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Platform"
    ) {
      it.only("TC61 - Add a new Platform and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('8')
        config_page.add_new_record('8',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Platform',
          'Platform Name',
          'Platform Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Platform"
    ) {
      it.only("TC62 - Search for a Record in the Platform Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('8')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Platform"
    ) {
      it.only("TC63 - Edit a  Platform and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('8')
        config_page.edit('8',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Platform',
          'Platform Name',
          'Platform Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Platform"
    ) {
      it.only("TC64 - Platform pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('8')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Platform"
    ) {
      it.only("TC65 - Platform Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('8')
        config_page.griddata('select pltfrm_cd,pltfrm_dsc from cdm_core.pltfrm_lkup order by cre_dtm desc',
        config,
        ['pltfrm_cd','pltfrm_dsc','Platform Name','Platform Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Platform"
    ) {
      it.only("TC66 - Platform Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('8')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Platform"
    ) {
      it.only("TC67 - Platform Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('8')
        config_page.backend_entry("select count(*) as cnt from cdm_core.pltfrm_lkup where cre_dtm <> chg_dtm and pltfrm_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Platform"
    ) {
      it.only("TC68 - Platform Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('8')
        config_page.error_check('8',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Platform"
    ) {
      it.only("TC69 - Platform MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('8')
           config_page.add_new_record('8',
            character_50,
          character_255,
        'Add a new Platform',
        'Platform Name',
        'Platform Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Platform"
    ) {
      it.only("TC70 - Deleting Dummy Record for Platform", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.pltfrm_lkup where pltfrm_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.pltfrm_lkup where pltfrm_cd='",character_50.substring(0,47),config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Provider"
    ) {
      it.only("TC71 - Add a new Provider and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('9')
        config_page.add_new_record('9',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Provider',
          'Provider Name',
          'Provider Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Provider"
    ) {
      it.only("TC72 - Search for a Record in the Provider Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('9')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Provider"
    ) {
      it.only("TC73 - Edit a  Provider and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('9')
        config_page.edit('9',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Provider',
          'Provider Name',
          'Provider Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Provider"
    ) {
      it.only("TC74 - Provider pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('9')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Provider"
    ) {
      it.only("TC75 - Provider Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('9')
        config_page.griddata('select prvd_cd,prvd_dsc from cdm_core.prvd_lkup order by cre_dtm desc',
        config,
        ['prvd_cd','prvd_dsc','Provider Name','Provider Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Provider"
    ) {
      it.only("TC76 - Provider Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('9')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Provider"
    ) {
      it.only("TC77 - Provider Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('9')
        config_page.backend_entry("select count(*) as cnt from cdm_core.prvd_lkup where cre_dtm <> chg_dtm and prvd_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Provider"
    ) {
      it.only("TC78 - Provider Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('9')
        config_page.error_check('9',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Provider"
    ) {
      it.only("TC79 - Provider MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('9')
           config_page.add_new_record('9',
            character_50,
          character_255,
        'Add a new Provider',
        'Provider Name',
        'Provider Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Provider"
    ) {
      it.only("TC80 - Deleting Dummy Record for Provider", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.prvd_lkup where prvd_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.prvd_lkup where prvd_cd='",character_50.substring(0,47),config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Pipeline_Type"
    ) {
      it.only("TC81 - Add a new Processing Pipeline Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('10')
        config_page.add_new_record('10',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Processing Pipeline Type',
          'Processing Pipeline Type Name',
          'Processing Pipeline Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Pipeline_Type"
    ) {
      it.only("TC82 - Search for a Record in the Processing Pipeline Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('10')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Processing_Pipeline_Type"
    ) {
      it.only("TC83 - Edit a  Processing Pipeline Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('10')
        config_page.edit('10',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Processing Pipeline Type',
          'Processing Pipeline Type Name',
          'Processing Pipeline Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Pipeline_Type"
    ) {
      it.only("TC84 - Processing Pipeline Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('10')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Pipeline_Type"
    ) {
      it.only("TC85 - Processing Pipeline Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('10')
        config_page.griddata('select prcss_ppln_type_cd,prcss_ppln_type_dsc from cdm_core.prcss_ppln_type_lkup order by cre_dtm desc',
        config,
        ['prcss_ppln_type_cd','prcss_ppln_type_dsc','Processing Pipeline Type Name','Processing Pipeline Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Pipeline_Type"
    ) {
      it.only("TC86 - Processing Pipeline Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('10')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Pipeline_Type"
    ) {
      it.only("TC87 - Processing Pipeline Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('10')
        config_page.backend_entry("select count(*) as cnt from cdm_core.prcss_ppln_type_lkup where cre_dtm <> chg_dtm and prcss_ppln_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Pipeline_Type"
    ) {
      it.only("TC88 - Processing Pipeline Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('10')
        config_page.error_check('10',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Pipeline_Type"
    ) {
      it.only("TC89 - Processing Pipeline Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('10')
           config_page.add_new_record('10',
            character_50,
          character_255,
        'Add a new Processing Pipeline Type',
        'Processing Pipeline Type Name',
        'Processing Pipeline Type Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Pipeline_Type"
    ) {
      it.only("TC90 - Deleting Dummy Record for Processing Pipeline Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.prcss_ppln_type_lkup where prcss_ppln_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.prcss_ppln_type_lkup where prcss_ppln_type_cd='",character_50.substring(0,47),config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Status"
    ) {
      it.only("TC91 - Add a new Processing Status and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('11')
        config_page.add_new_record('11',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Processing Status',
          'Processing Status Name',
          'Processing Status Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Status"
    ) {
      it.only("TC92 - Search for a Record in the Processing Status Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('11')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Processing_Pipeline_Type"
    ) {
      it.only("TC93 - Edit a  Processing Status and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('11')
        config_page.edit('11',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Processing Status',
          'Processing Status Name',
          'Processing Status Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Status"
    ) {
      it.only("TC94 - Processing Status pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('11')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Status"
    ) {
      it.only("TC95 - Processing Status Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('11')
        config_page.griddata('select prcss_sts_cd,prcss_sts_dsc from cdm_core.prcss_sts_lkup order by cre_dtm desc',
        config,
        ['prcss_sts_cd','prcss_sts_dsc','Processing Status Name','Processing Status Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Status"
    ) {
      it.only("TC96 - Processing Status Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('11')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Status"
    ) {
      it.only("TC97 - Processing Status Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('11')
        config_page.backend_entry("select count(*) as cnt from cdm_core.prcss_sts_lkup where cre_dtm <> chg_dtm and prcss_sts_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Status"
    ) {
      it.only("TC98 - Processing Status Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('11')
        config_page.error_check('11',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Status"
    ) {
      it.only("TC99 - Processing Status MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('11')
           config_page.add_new_record('11',
            character_50,
          character_255,
        'Add a new Processing Status',
        'Processing Status Name',
        'Processing Status Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Processing_Status"
    ) {
      it.only("TC100 - Deleting Dummy Record for Processing Status", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.prcss_sts_lkup where prcss_sts_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.prcss_sts_lkup where prcss_sts_cd='",character_50.substring(0,47),config);
      });
    }
  }

})