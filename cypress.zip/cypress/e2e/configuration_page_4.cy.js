// ************************ Configuration page - File Metadata Tables Check***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Metadata tables in the UI Configuration page
// 
// In this spec file, we are checking the below tables in the FileMeta section:
// 1.Action
// 2.Application
// 3.Affiliation Type
// 4.Resource Type
// 5.Principal Type
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Adding a Record and checking the record is available in the grid
// 2.Search for a Record in the Grid
// 3.Edit a  Record and Check the edited data is available in Grid
// 4.Pagination
// 5.Grid Data Validation
// 6.Is_active button functionality
// 7.Uniqueness Violation Check
// 8.Cheking the Maxallowed character for the input fields
// 9.Checking in the backend whether the new entries are created.


let envi = Cypress.env('ENV')
import config_page from '../functions/config_page'
let excel_data = require("../fixtures/output.json");
let character_50 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
let character_255 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';

describe("Configuration Page - IV", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    before(() => {
      cy.viewport(1400, 1000);
    });
  
    beforeEach(() => {
      cy.viewport(1400, 1000);
    });

    afterEach(function(){
    if(this.currentTest.state === 'failed'){
      cy.reload()
      cy.wait(10000)
   
      
     }


     

    })

    it.only('Launching Consumer Data',()=>{

      dup.launching_consumer_data()
       cy.wait(10000)
     })
 
     
 it.only("Changing th role to Intel bizops", () => {
   dup.role_change(config,'3');
   dup.launching_consumer_data()
 });

  it.only("Going to Configuration page", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.config_page('Configuration', 'Configure Tables')
    
  });

 
  it.only("Going to Access Entitlement page", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.config_page('Configuration', 'Configure Tables')
    config_page.access_entitlement()
    
  });

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Action"
    ) {
      it.only("TC131 - Add a new Action and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('1','Access')
        config_page.add_new_record('1',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Action',
          'Action Name',
          'Action Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Action"
    ) {
      it.only("TC132 - Search for a Record in the Action Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('1','Access')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Action"
    ) {
      it.only("TC133 - Edit a  Action and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('1','Access')
        config_page.edit('1',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Action',
          'Action Name',
          'Action Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Action"
    ) {
      it.only("TC134 - Action pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('1','Access')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Action"
    ) {
      it.only("TC135 - Action Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('1','Access')
        config_page.griddata('select actn_cd,actn_dsc from cdm_accs_enttl.actn_lkup order by cre_dtm desc',
        config,
        ['actn_cd','actn_dsc','Action Name','Action Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Action"
    ) {
      it.only("TC136 - Action Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('1','Access')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Action"
    ) {
      it.only("TC137 - Action Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    
        config_page.backend_entry("select count(*) as cnt from cdm_accs_enttl.actn_lkup where cre_dtm <> chg_dtm and actn_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Action"
    ) {
      it.only("TC138 - Action Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('1','Access')
        config_page.error_check('1',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Action"
    ) {
      it.only("TC139 - Action MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('1','Access')
           config_page.add_new_record('1',
            character_50,
            character_50,
        'Add a new Action',
        'Action Name',
        'Action Description',
        'Access'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Action"
    ) {
      it.only("TC140 - Deleting Dummy Record for Action", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_accs_enttl.actn_lkup where actn_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_accs_enttl.actn_lkup where actn_cd='",character_50.substring(0,47),config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application"
    ) {
      it.only("TC141 - Add a new Application and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('2','Access')
        config_page.add_new_record('2',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Application',
          'Application Name',
          'Application Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application"
    ) {
      it.only("TC142 - Search for a Record in the Application Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('2','Access')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Application"
    ) {
      it.only("TC143 - Edit a  Application and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('2','Access')
        config_page.edit('2',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Application',
          'Application Name',
          'Application Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application"
    ) {
      it.only("TC144 - Application pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('2','Access')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application"
    ) {
      it.only("TC145 - Application Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('2','Access')
        config_page.griddata('select app_cd,app_dsc from cdm_ui_cntnt.app_lkup order by cre_dtm desc',
        config,
        ['app_cd','app_dsc','Application Name','Application Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application"
    ) {
      it.only("TC146 - Application Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('2','Access')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application"
    ) {
      it.only("TC147 - Application Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_ui_cntnt.app_lkup where cre_dtm <> chg_dtm and app_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application"
    ) {
      it.only("TC148 - Application Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('2','Access')
        config_page.error_check('2',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application"
    ) {
      it.only("TC149 - Application MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('2','Access')
           config_page.add_new_record('2',
            character_50,
          character_255,
        'Add a new Application',
        'Application Name',
        'Application Description',
        'Access'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application"
    ) {
      it.only("TC150 - Deleting Dummy Record for Application", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_ui_cntnt.app_lkup where app_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_ui_cntnt.app_lkup where app_cd='",character_50.substring(0,47),config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Affiliation_Type"
    ) {
      it.only("TC151 - Add a new Affiliation Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('3','Access')
        config_page.add_new_record('3',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Affiliation Type',
          'Affiliation Type Name',
          'Affiliation Type Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Affiliation_Type"
    ) {
      it.only("TC152 - Search for a Record in the Affiliation Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('3','Access')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Affiliation_Type"
    ) {
      it.only("TC153 - Edit a  Affiliation Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('3','Access')
        config_page.edit('3',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Affiliation Type',
          'Affiliation Type Name',
          'Affiliation Type Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Affiliation_Type"
    ) {
      it.only("TC154 - Affiliation Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('3','Access')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Affiliation_Type"
    ) {
      it.only("TC155 - Affiliation Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('3','Access')
        config_page.griddata('select afil_type_cd,afil_type_dsc from cdm_accs_enttl.afil_type_lkup order by cre_dtm desc',
        config,
        ['afil_type_cd','afil_type_dsc','Affiliation Type Name','Affiliation Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Affiliation_Type"
    ) {
      it.only("TC156 - Affiliation Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('3','Access')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Affiliation_Type"
    ) {
      it.only("TC157 - Affiliation Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_accs_enttl.afil_type_lkup where cre_dtm <> chg_dtm and afil_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Affiliation_Type"
    ) {
      it.only("TC158 - Affiliation Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('3','Access')
        config_page.error_check('3',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Affiliation_Type"
    ) {
      it.only("TC159 - Affiliation Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('3','Access')
           config_page.add_new_record('3',
            character_50,
          character_255,
        'Add a new Affiliation Type',
        'Affiliation Type Name',
        'Affiliation Type Description',
        'Access'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Affiliation_Type"
    ) {
      it.only("TC160 - Deleting Dummy Record for Affiliation Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_accs_enttl.afil_type_lkup where afil_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_accs_enttl.afil_type_lkup where afil_type_cd='",character_50.substring(0,47),config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Resource_Type"
    ) {
      it.only("TC161 - Add a new Resource Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('4','Access')
        config_page.add_new_record('4',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Resource Type',
          'Resource Type Name',
          'Resource Type Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Resource_Type"
    ) {
      it.only("TC162 - Search for a Record in the Resource Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('4','Access')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Resource_Type"
    ) {
      it.only("TC163 - Edit a  Resource Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('4','Access')
        config_page.edit('4',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Resource Type',
          'Resource Type Name',
          'Resource Type Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Resource_Type"
    ) {
      it.only("TC164 - Resource Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('4','Access')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Resource_Type"
    ) {
      it.only("TC165 - Resource Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('4','Access')
        config_page.griddata('select rsrc_type_cd, rsrc_type_dsc from cdm_accs_enttl.rsrc_type_lkup order by cre_dtm desc',
        config,
        ['rsrc_type_cd', 'rsrc_type_dsc','Resource Type Name','Resource Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Resource_Type"
    ) {
      it.only("TC166 - Resource Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('4','Access')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Resource_Type"
    ) {
      it.only("TC167 - Resource Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_accs_enttl.rsrc_type_lkup where cre_dtm <> chg_dtm and rsrc_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Resource_Type"
    ) {
      it.only("TC168 - Resource Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('4','Access')
        config_page.error_check('4',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Resource_Type"
    ) {
      it.only("TC169 - Resource Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('4','Access')
           config_page.add_new_record('4',
            character_50,
          character_255,
        'Add a new Resource Type',
        'Resource Type Name',
        'Resource Type Description',
        'Access'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Resource_Type"
    ) {
      it.only("TC170 - Deleting Dummy Record for Resource Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_accs_enttl.rsrc_type_lkup where rsrc_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_accs_enttl.rsrc_type_lkup where rsrc_type_cd='",character_50.substring(0,47),config);
      });
    }
  }
  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Principal_Type"
    ) {
      it.only("TC171 - Add a new Principal Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('5','Access')
        config_page.add_new_record('5',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Principal Type',
          'Principal Type Name',
          'Principal Type Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Principal_Type"
    ) {
      it.only("TC172 - Search for a Record in the Principal Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('5','Access')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Principal_Type"
    ) {
      it.only("TC173 - Edit a  Principal Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('5','Access')
        config_page.edit('5',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Principal Type',
          'Principal Type Name',
          'Principal Type Description',
          'Access'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Principal_Type"
    ) {
      it.only("TC174 - Principal Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('5','Access')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Principal_Type"
    ) {
      it.only("TC175 - Principal Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('5','Access')
        config_page.griddata('select prncpl_type_cd, prncpl_type_dsc from cdm_accs_enttl.prncpl_type_lkup order by cre_dtm desc',
        config,
        ['prncpl_type_cd', 'prncpl_type_dsc','Principal Type Name','Principal Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Principal_Type"
    ) {
      it.only("TC176 - Principal Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('5','Access')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Principal_Type"
    ) {
      it.only("TC177 - Principal Type Checking the Backend Entry", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_accs_enttl.prncpl_type_lkup where cre_dtm <> chg_dtm and prncpl_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Principal_Type"
    ) {
      it.only("TC178 - Principal Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('5','Access')
        config_page.error_check('5',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Principal_Type"
    ) {
      it.only("TC179 - Principal Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.access_entitlement()
    config_page.going_to_table('5','Access')
           config_page.add_new_record('5',
            character_50,
          character_255,
        'Add a new Principal Type',
        'Principal Type Name',
        'Principal Type Description',
        'Access'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Principal_Type"
    ) {
      it.only("TC180 - Deleting Dummy Record for Principal Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_accs_enttl.prncpl_type_lkup where prncpl_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_accs_enttl.prncpl_type_lkup where prncpl_type_cd='",character_50.substring(0,47),config);
      });
    }
  }


  

})