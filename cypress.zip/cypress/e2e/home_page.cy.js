// ************************ Duplicate Tab - Historical Data Section***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Home Page
// 
//
//
// Below are the Scenarios Covered for testing Home page:
// 1.Checking the Title of the Homepage
// 2.Verifying the Navbar Menu in the Home page
// 3.Verifying all the submenu under the Navbar Menu
// 4.Carousel Check
// 5.Links in the Home page is working as expected




import homepage from '../functions/home_page'
let envi = Cypress.env('ENV')
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';



describe("Home page", function () {
  before(() => {
    cy.viewport(1400, 1000);
  });

  beforeEach(() => {
    cy.viewport(1400, 1000);
  });


  it.only('Launching Consumer Data',()=>{

    dup.launching_consumer_data()
     cy.wait(10000)
   })

   
it.only("Changing th role to Account Manager", () => {
 dup.role_change(config,'2');
 dup.launching_consumer_data()
 cy.wait(20000)
});


  it.only('TC01 - Title Validation',()=>{
    homepage.title_validation()
  })

 

  it.only('TC03 - Banner Text Validation',()=>{
    homepage.banner_text_validation()
  })


  it.only('TC04 - Dataset SubMenu Validation',()=>{
    homepage.dataset_submenu_validation()
  })

  it.only('TC05 - Language SubMenu Validation',()=>{
    homepage.language_submenu_validation()
  })


  it.only('TC12 - Upload file link',()=>{
    homepage.upload_file_link()
  })

  it.only('TC13 -  Historical Data link',()=>{
    homepage.historical_data_link()
  })


  it.only('TC06 - Dataset SubMenu -  Upload File',()=>{
    homepage.upload_file()
  })

  it.only('TC07 - Dataset SubMenu -  Historical Data',()=>{
    homepage.historical_data()
  })

  it.only('TC08 - Dataset SubMenu -  Workflow Area',()=>{
    homepage.workflow_area()
  })


  it.only("Changing th role to Intel bizops", () => {
    dup.role_change(config,'3');
    dup.launching_consumer_data()
    cy.wait(20000)
   });


   it.only('TC02 - Navbar Menu Validation',()=>{
    homepage.navbar_menu_validation()
  })

  it.only('TC09 - Configuration Page Menu',()=>{
    homepage.configuration_page()
  })

  it.skip('TC11 - Carousel Check',()=>{
    homepage.carousel_check()
  })

  it.skip('TC10 - Return to Home Page',()=>{
    homepage.homepage_click()
  })











})