const env_var = require('../support/environment')
//let envi = Cypress.env('ENV'); 
const { encrypt, decrypt } = require('../e2e/crypto')
//const config_encrypt = env_var.getpostgres_conn(envi);
//const config = JSON.parse(decrypt(config_encrypt));
//let arguments = process.argv ;
//let envi = arguments[3].slice(4,(arguments[3].length))
let envi = Cypress.env('ENV')
console.log(env_var.getBaseUrl(envi))


describe("Config Page", () => {
    beforeEach(() => {
      cy.viewport(1400, 1000);
    });
  
    it.only('waitning',()=>{
      cy.log(envi)
        cy.log(env_var.getBaseUrl(envi))
        cy.visit(env_var.getBaseUrl('dev'))
        cy.log(process.argv)
        
        cy.wait(10000)
    })

})