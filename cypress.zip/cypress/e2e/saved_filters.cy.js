// ************************ Saving Filters Section***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Custom filters sections in the Historical grid
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Last 12 Months are enabled and Months previous to the Last 12 months should be disabled in the Month picker
// 2.Verifing whether the Months are highlighted when selecing it from the date picker
// 3.Applying filter and checking whether the grid data is refershed according to the filter
// 4.Saving a filter and selecting it from the Saved filters section
// 5.Making a filter as default and on reload the grid data should be prepopulated with the filter



import uploadHistory from "../functions/upload_history";
import saved_filters from '../functions/saved_filters';
const env_var = require('../support/environment')
let envi = Cypress.env('ENV'); 
const { encrypt, decrypt } = require('../e2e/crypto')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';
import rolefunc from '../functions/role'

describe("Saved Filters", () => {
  
  beforeEach(function()  {
    
    cy.viewport(1400, 1000);
    if (Cypress.mocha.getRunner().suite.ctx.currentTest.title === 'Saving Filter  - Curr_Month - I' ||
    Cypress.mocha.getRunner().suite.ctx.currentTest.title === 'Saving Filter - Prev_Curr_Month - II' ||
    Cypress.mocha.getRunner().suite.ctx.currentTest.title === 'Saving Filter - Prev_Month - III' ||
    Cypress.mocha.getRunner().suite.ctx.currentTest.title === 'Saving Filter - Different Partners  - IV' ||
    Cypress.mocha.getRunner().suite.ctx.currentTest.title === 'Make as default'  ) {
      //this.skip()

      // saved_filters.user_profile.click()
   // saved_filters.show_filter_button.click()
  // cy.xpath('//*[@id="nav-dropdown-light-example"]').click()
   //this.email_addr.should('have.text',result.rows[0].email_addr)
     cy.wait(5000)
     cy.xpath('//*[@id="userSignOutDropdown"]/div/text()').then(($el) => {
     cy.task("DATABASE", {
       dbConfig: Cypress.env(config),
       sql:` DELETE FROM cdm_ui_cntnt.ui_sav_srch_dtl WHERE ui_sav_srch_dtl_id in (select dtl.ui_sav_srch_dtl_id
         FROM
         cdm_ui_cntnt.ui_sav_srch_nm nm
         inner join cdm_ui_cntnt.ui_sav_srch_dtl dtl on nm.ui_sav_srch_nm_id=dtl.ui_sav_srch_nm_id
         where nm.sav_by_usr_prncpl_id=(select prncpl_id from cdm_accs_enttl.usr where usr_nm='`+$el.text().trim()+`') 
         and nm.sav_srch_nm='Saving_filter_test' )`
 
     })

     cy.task("DATABASE", {
       dbConfig: Cypress.env(config),
       sql:`  delete from cdm_ui_cntnt.ui_sav_srch_nm where sav_srch_nm='Saving_filter_test'`
 
     })
   })


    }
    else{
 
    }
   

    

  });
  afterEach(function () {
    // if(this.currentTest.state === 'failed'){
    //   cy.reload()
    //   cy.wait(10000)
    //  }

     
  })

  it.only('Launching Consumer Data',()=>{
    dup.launching_consumer_data()
    cy.wait(10000)
  })

  it.only("Changing th role to Intel bizops", () => {
    dup.role_change(config,'3');
    dup.launching_consumer_data()
    cy.wait(20000)
  });


  it.only('make dflt_ind-N',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.make_dflt_ind(config)
      })

  it.only("Going to upload history page", () => {
    uploadHistory.uploadHistoryButton_click("Historical Data");
    cy.wait(5000);
  });


  it.only("Show and Hide Filters", () => {
  
    saved_filters.show_hide_filter('Show Filters','Hide Filters')
  });


 



  it.only('Future Months Disabled',()=>{
    saved_filters.future_months_disabled_current_month_enabled()
  
    
    
})


it.only('Past Months Disabled',()=>{
saved_filters.past_months_disabled_current_month_enabled()
  
  
})


it.only('Months highlighted',()=>{
  saved_filters.months_highlighted()

})
  
it.skip('Partner Dropdown Check',()=>{
  saved_filters.partner_dropdown(`select o1.org_nm from cdm_accs_enttl.org o1 where org_nm<>'-1' and org_nm<>'Intel' order by org_nm asc`,config)
})

it.only('Seleting current month for all partner',()=>{
  saved_filters.current_month_all_partners(config)
})

it.only('Seleting prev and current month for all partner',()=>{
  saved_filters.prev_curr_month_all_partners(config)
})

it.only('Seleting prev  month for all partner',()=>{
  saved_filters.prev_month_all_partners(config)
})


it.only('Seleting different partner - I',()=>{
  saved_filters.saving_for_different_partners_1(config)
})


it.only('Seleting different partner - II',()=>{
  saved_filters.saving_for_different_partners_2(config)
})


it.only('Saving Filter  - Curr_Month - I',()=>{
  saved_filters.saving_filter_combination(config)
})

it.only('Saving Filter - Prev_Curr_Month - II',()=>{
  saved_filters.saving_filter_combination_II(config)
})


it.skip('Saving Filter - Prev_Month - III',()=>{
  saved_filters.saving_filter_combination_III(config)
})


it.skip('Saving Filter - Different Partners  - IV',()=>{
  saved_filters.saving_filter_combination_IV(config)
})


it.only('Make as default',()=>{
  saved_filters.saving_filter_combination_III(config)
  saved_filters.make_as_default(config)
})








  
  


 


});
