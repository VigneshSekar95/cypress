// ************************ Configuration page - File Metadata Tables Check***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Metadata tables in the UI Configuration page
// 
// In this spec file, we are checking the below tables in the FileMeta section:
// 1.Classification_Hierarchy
// 2.Data_Dimension
// 3.Data_Ingestion_Mode
// 4.File_Type
// 5.Hierarchy_Type
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Adding a Record and checking the record is available in the grid
// 2.Search for a Record in the Grid
// 3.Edit a  Record and Check the edited data is available in Grid
// 4.Pagination
// 5.Grid Data Validation
// 6.Is_active button functionality
// 7.Uniqueness Violation Check
// 8.Cheking the Maxallowed character for the input fields
// 9.Checking in the backend whether the new entries are created.






//<reference types="cypress" />
let envi = Cypress.env('ENV')
import config_page from '../functions/config_page';
let excel_data = require("../fixtures/output.json");
let character_50 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
let character_255 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';


describe("Configuration Page - I", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    before(() => {
      cy.viewport(1400, 1000);
    });
  
    beforeEach(() => {
      cy.viewport(1400, 1000);
    });

    afterEach(function(){
    if(this.currentTest.state === 'failed'){
      cy.reload()
      cy.wait(10000)
 
      
     }


     

    })

    

    it.only('Launching Consumer Data',()=>{

     dup.launching_consumer_data()
      cy.wait(10000)
    })

    
it.only("Changing th role to Intel bizops", () => {
  dup.role_change(config,'3');
  dup.launching_consumer_data()
});


  it.only("Going to Configuration page", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.config_page('Configuration', 'Configure Tables')
    
  });

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Classification_Hierarchy"
    ) {
      it.only("TC01 - Add a New Class Hier and Check the data is available in Grid", {

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('1')
        config_page.add_new_record('1',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Classification Hierarchy',
          'Classification Hierarchy Name',
          'Classification Hierarchy Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Classification_Hierarchy"
    ) {
      it.only("TC02 - Search for a Record in the Class Hier Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    
        config_page.going_to_table('1')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Classification"
    ) {
      it.only("TC03 - Edit a  Class Hier and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('1')
        config_page.edit('1',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Classification Hierarchy',
          'Classification Hierarchy Name',
          'Classification Hierarchy Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Classification_Hierarchy"
    ) {
     it.only("TC04 - Class Hier pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    
        config_page.going_to_table('1')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Classification_Hierarchy"
    ) {
      it.only("TC05 - Class Hier Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('1')
        config_page.griddata('select hier_cd,hier_dsc from cdm_core.class_hier_lkup order by cre_dtm desc',
        config,
        ['hier_cd','hier_dsc','Classification Hierarchy Name','Classification Hierarchy Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Classification_Hierarchy"
    ) {
      it.only("TC06 - Class Hier Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('1')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Classification_Hierarchy"
    ) {
      it.only("TC07 - Class Hier Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_core.class_hier_lkup where cre_dtm <> chg_dtm and hier_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Classification_Hierarchy"
    ) {
      it.only("TC08 - Class Hier Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('1')
        config_page.error_check('1',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Classification_Hierarchy"
    ) {
      it.only("TC09 - Class Hier MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('1')
           config_page.add_new_record('1',
            character_50,
          character_255,
        'Add a new Classification Hierarchy',
        'Classification Hierarchy Name',
        'Classification Hierarchy Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Classification_Hierarchy"
    ) {
      it.only("TC10 - Deleting Dummy Record for Class Hier", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('1')
           config_page.delete_the_record("delete from cdm_core.class_hier_lkup where hier_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.class_hier_lkup where hier_cd='",character_50.substring(0,47),config);
      });
    }
  }


 


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Dimension"
    ) {
     it.only("TC11 - Add a New Data Dimension and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
        config_page.add_new_record('3',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Data Dimension',
          'Data Dimension Name',
          'Data Dimension Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Dimension"
    ) {
     it.only("TC12 - Search for a Record in the Data Dimension Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Data_Dimension"
    ) {
     it.only("TC13 - Edit a  Data Dimension and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
        config_page.edit('3',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Data Dimension',
          'Data Dimension Name',
          'Data Dimension Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Dimension"
    ) {
     it.only("TC14 - Data Dimension pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Dimension"
    ) {
     it.only("TC15 - Data Dimension Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
        config_page.griddata('select dim_cd,dim_dsc from cdm_core.data_dim_lkup order by cre_dtm desc',
        config,
        ['dim_cd','dim_dsc','Data Dimension Name','Data Dimension Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Dimension"
    ) {
     it.only("TC16 - Data Dimension Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Dimension"
    ) {
     it.only("TC17 - Data Dimension Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
        config_page.backend_entry("select count(*) as cnt from cdm_core.data_dim_lkup where cre_dtm <> chg_dtm and dim_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Dimension"
    ) {
     it.only("TC18 - Data Dimension Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
        config_page.error_check('3',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Dimension"
    ) {
     it.only("TC19 - Data Dimension MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
           config_page.add_new_record('3',
            character_50,
          character_255,
        'Add a new Data Dimension',
        'Data Dimension Name',
        'Data Dimension Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Dimension"
    ) {
     it.only("TC20 - Deleting Dummy Record for Data Dimension", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('3')
           config_page.delete_the_record("delete from cdm_core.data_dim_lkup where dim_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.data_dim_lkup where dim_cd='",character_50.substring(0,47),config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Ingestion_Mode"
    ) {
     it.only("TC21 - Add a new Data Ingestion Mode and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('4')
        config_page.data_ingestion_new_record('4',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'OL',
          'Add a new Data Ingestion Mode',
          'Data Ingestion Mode Name',
          'Data Ingestion Mode Description',
          'Use Case Type'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Ingestion_Mode"
    ) {
     it.only("TC22 - Search for a Record in the Data Ingestion Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('4')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Data_Ingestion_Mode"
    ) {
     it.only("TC23 - Edit a  Data Ingestion and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('4')
        config_page.data_ingestion_edit_record('4',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'OFF',
          'Edit Data Ingestion Mode',
          'Data Ingestion Mode Name',
          'Data Ingestion Mode Description',
          'Use Case Type'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Ingestion_Mode"
    ) {
     it.only("TC24 - Data Ingestion pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('4')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Ingestion_Mode"
    ) {
     it.only("TC25 - Data Ingestion Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('4')
        config_page.qual_griddata('select data_ingest_mode_cd,data_ingest_mode_dsc,use_case_type_cd from cdm_core.data_ingest_mode_lkup order by cre_dtm desc',
        config,
        ['data_ingest_mode_cd','data_ingest_mode_dsc','use_case_type_cd','Data Ingestion Mode Name','Data Ingestion Mode Description','Use Case Type'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Ingestion_Mode"
    ) {
     it.only("TC26 - Data Ingestion Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('4')
        config_page.qual_is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Ingestion_Mode"
    ) {
     it.only("TC27 - Data Ingestion Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('4')
        config_page.backend_entry("select count(*) as cnt from cdm_core.data_ingest_mode_lkup where cre_dtm <> chg_dtm and data_ingest_mode_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Ingestion_Mode"
    ) {
     it.only("TC28 - Data Ingestion Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('4')
        config_page.data_ingestion_error_check('4',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'OL'
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Ingestion_Mode"
    ) {
     it.only("TC29 - Data Ingestion MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('4')
           config_page.data_ingestion_new_record('4',
            character_50,
          character_255,
          'OL',
        'Add a new Data Ingestion Mode',
        'Data Ingestion Mode Name',
        'Data Ingestion Mode Description',
        'Use Case Type'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Data_Ingestion_Mode"
    ) {
     it.only("TC30 - Deleting Dummy Record for Data Ingestion", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.data_ingest_mode_lkup where data_ingest_mode_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.data_ingest_mode_lkup where data_ingest_mode_cd='",character_50.substring(0,47),config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_File_Type"
    ) {
     it.only("TC31 - Add a new File Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
        config_page.add_new_record('5',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new File Type',
          'File Type Name',
          'File Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_File_Type"
    ) {
     it.only("TC32 - Search for a Record in the File Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_File_Type"
    ) {
     it.only("TC33 - Edit a  File Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
        config_page.edit('5',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit File Type',
          'File Type Name',
          'File Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_File_Type"
    ) {
     it.only("TC34 - File Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_File_Type"
    ) {
     it.only("TC35 - File Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
        config_page.griddata('select file_type_cd,file_type_dsc from cdm_core.file_type_lkup order by cre_dtm desc',
        config,
        ['file_type_cd','file_type_dsc','File Type Name','File Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_File_Type"
    ) {
     it.only("TC36 - File Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_File_Type"
    ) {
     it.only("TC37 - File Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
        config_page.backend_entry("select count(*) as cnt from cdm_core.file_type_lkup where cre_dtm <> chg_dtm and file_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_File_Type"
    ) {
     it.only("TC38 - File Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
        config_page.error_check('5',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_File_Type"
    ) {
     it.only("TC39 - File Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
           config_page.add_new_record('5',
            character_50,
          character_255,
        'Add a new File Type',
        'File Type Name',
        'File Type Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_File_Type"
    ) {
     it.only("TC40 - Deleting Dummy Record for File Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('5')
           config_page.delete_the_record("delete from cdm_core.file_type_lkup where file_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.file_type_lkup where file_type_cd='",character_50.substring(0,47),config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Hierarchy_Type"
    ) {
     it.only("TC41 - Add a new Hierarchy Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('6')
        config_page.add_new_record('6',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Hierarchy Type',
          'Hierarchy Type Name',
          'Hierarchy Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Hierarchy_Type"
    ) {
     it.only("TC42 - Search for a Record in the Hierarchy Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('6')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Hierarchy_Type"
    ) {
     it.only("TC43 - Edit a  Hierarchy Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('6')
        config_page.edit('6',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Hierarchy Type',
          'Hierarchy Type Name',
          'Hierarchy Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Hierarchy_Type"
    ) {
     it.only("TC44 - Hierarchy Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('6')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Hierarchy_Type"
    ) {
     it.only("TC45 - Hierarchy Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('6')
        config_page.griddata('select hier_type_cd,hier_type_dsc from cdm_core.hier_type_lkup order by cre_dtm desc',
        config,
        ['hier_type_cd','hier_type_dsc','Hierarchy Type Name','Hierarchy Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Hierarchy_Type"
    ) {
     it.only("TC46 - Hierarchy Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('6')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Hierarchy_Type"
    ) {
     it.only("TC47 - Hierarchy Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('6')
        config_page.backend_entry("select count(*) as cnt from cdm_core.hier_type_lkup where cre_dtm <> chg_dtm and hier_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Hierarchy_Type"
    ) {
     it.only("TC48 - Hierarchy Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('6')
        config_page.error_check('6',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Hierarchy_Type"
    ) {
     it.only("TC49 - Hierarchy Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.going_to_table('6')
           config_page.add_new_record('6',
            character_50,
          character_255,
        'Add a new Hierarchy Type',
        'Hierarchy Type Name',
        'Hierarchy Type Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Hierarchy_Type"
    ) {
     it.only("TC50 - Deleting Dummy Record for Hierarchy Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.hier_type_lkup where hier_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.hier_type_lkup where hier_type_cd='",character_50.substring(0,47),config);
      });
    }
  }

})