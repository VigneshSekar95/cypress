// ************************ Input File ***********************************
// Created by Vignesh Sekar
// 
// All the Input values required for testing the Configuration File - Metadata Tables are available in the Cypress_Input_Sheet.csv
// 
// Run this spec file before running all the test cases so that all the input data will be stored in JSON format - output.json
//
// The Files Cypress_Input_Sheet.csv, output.json is placed under the Fixtures Folder




describe("Getting Data from Excel", function () {
  beforeEach(() => {
    cy.viewport(1400, 1000);
  });

  it.only("Stroing the Data from Excel", () => {
    const excelFilePath = "./cypress/fixtures/Cypress_Input_Sheet.csv";

    cy.task("readCSVfile", excelFilePath).then((user_data) => {
      
      cy.task("setUserId", user_data).then((user) => {
      });

      cy.task("getUserId").then(async (user_id) => {
        const run_id = user_id;

        await cy.task("writetoaFile", run_id).then((user) => {
        });
      });
    });
  });
});
