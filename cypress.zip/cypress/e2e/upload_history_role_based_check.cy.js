// ************************ Upload History Grid Role Based Check ***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Role based check in History Grid
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking whether the grid data is displayed according to the user role
// 2.Checking whether the grid columns are visible according to the user role
// 3.Checking whether the buttons are visible according to the user role
// 4.Checking whether the partners are visible in the Custom filter partner dropdown according to the user role

import rolefunc from '../functions/role'
const role = require('../queries/role')
import dup from '../functions/duplicate';
let envi = Cypress.env('ENV')
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));

describe('Upload History page Role based',function(){

  beforeEach(() => {
    cy.viewport(2500, 1000);
    // uploadHistory.uploadFileButton_click.click()
    // setTimeout(() => {
    //   throw new Error("Test taking tooooo long!");
    // }, 60000 * 3);
  });

  // afterEach(function () { 
  //   if(this.currentTest.state === 'failed'){
  //     dup.launching_consumer_data()
  //     cy.wait(10000)
  //    }
  
  // })

  
  it.only('Launching Consumer Data',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{

   dup.launching_consumer_data()
     cy.wait(30000)
   })

    it.only('make dflt_ind-N',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.make_dflt_ind(config)
      })


    



      it.only("Changing th role to WW Program Manager", () => {
        rolefunc.role_change(config,'1');
        dup.launching_consumer_data()
        cy.wait(30000)
      });

      it.only("Going to upload history page",{}, () => {
            rolefunc.uploadHistoryButton_click();
            cy.wait(30000)
          });


      it.only('TC01 - WW Program Manger - Columns Validation',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.columns_validaiton(role.expected_columns)

      })

      it.only('TC02 - WW Program Manger - Checking all data is loaded',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.data_count(config)
      })

      it.only('TC03 - WW Program Manger - Checking all buttons are visible',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.five_buttons_visible(['Show Filters','Inactive','Restatement','Reprocess','Export'])
      })


      it.only('TC04 - WW Program Manger - Checking all Partners are avaialble in the Dropdowns',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.all_partners_available(new Date().getMonth(),role.org_nm,config)
      })

     


      it.only("Changing th role to Account Manager", () => {
        rolefunc.role_change(config,'2');
        dup.launching_consumer_data()
        cy.wait(30000)
      });

      it.only("Going to upload history page",{}, () => {
            rolefunc.uploadHistoryButton_click_1();
            cy.wait(30000)
          });


      it.only('TC05 - Account Manager - Columns Validation',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.columns_validaiton(role.expected_columns)

      })

      it.only('TC06 - Account Manager - Checking only the org data is loaded',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.grid_count_org(config)
      })

      it.only('TC07 - Account Manager - Checking all buttons are visible',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.all_buttons_visible(['Show Filters','Inactive','Restatement','Publish','Reprocess','Export'])
      })


      it.only('TC08 - WW Program Manger - Checking Particular Partners are avaialble in the Dropdowns',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.particular_partner_available(config)
      })


      
      it.only("Changing th role to Intel Bizops", () => {
        rolefunc.role_change(config,'3');
        dup.launching_consumer_data()
        cy.wait(30000)
      });

      it.only("Going to upload history page",{}, () => {
            rolefunc.uploadHistoryButton_click();
            cy.wait(30000)
          });


      it.only('TC09 - Intel Bizops - Columns Validation',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.columns_validaiton(role.expected_columns)

      })

      it.only('TC10 - Intel Bizops - Checking only the org data is loaded',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.data_count(config)
      })

      it.only('TC11 - Intel Bizops - Checking all buttons are visible',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.all_buttons_visible(['Show Filters','Inactive','Restatement','Publish','Reprocess','Export'])
      })


      it.only('TC12 - Intel Bizops - Checking All Partners are avaialble in the Dropdowns',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.all_partners_available(new Date().getMonth(),role.org_nm,config)
      })
     

      

      it.only("Changing th role to Third Party Data Submitter", () => {
        rolefunc.role_change(config,'5');
        dup.launching_consumer_data()
        cy.wait(30000)
      });

      it.only("Going to upload history page",{}, () => {
            rolefunc.uploadHistoryButton_click_1();
            cy.wait(30000)
          });


      it.only('TC13 - Third Party Data Submitter - Columns Validation',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.columns_validaiton(role.expected_columns_min)

      })

      it.only('TC14 - Third Party Data Submitter - Checking only the org data is loaded',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.grid_count_org(config)
      })

      it.only('TC15 - Third Party Data Submitter - Checking all buttons are visible',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.only_four_buttons_visible(['Show Filters','Inactive','Restatement','Export'])
      })


      it.only('TC16 - Third Party Data Submitter - Checking Particular Partners are avaialble in the Dropdowns',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.particular_partner_available(config)
      })


      

      it.only("Changing th role to Partner Data Submitter", () => {
        rolefunc.role_change(config,'6');
        dup.launching_consumer_data()
        cy.wait(30000)
      });

      it.only("Going to upload history page",{}, () => {
            rolefunc.uploadHistoryButton_click_1();
            cy.wait(30000)
          });


      it.only('TC13 - Partner Data Submitter - Columns Validation',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.columns_validaiton(role.expected_columns_min)

      })

      it.only('TC14 - Partner Data Submitter - Checking only the org data is loaded',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.grid_count_org(config)
      })

      it.only('TC15 - Partner Data Submitter - Checking all buttons are visible',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.only_four_buttons_visible(['Show Filters','Inactive','Restatement','Export'])
      })


      it.only('TC16 - Partner Data Submitter - Checking Particular Partners are avaialble in the Dropdowns',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.particular_partner_available(config)
      })



      it.only("Changing th role to Intel Bizops", () => {
        rolefunc.role_change(config,'3');
      });


























    })
