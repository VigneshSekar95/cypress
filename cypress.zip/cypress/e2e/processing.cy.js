// ************************ Processing Grid***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the  Processing Grid
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Grid Data Valdiation
// 2.Grid Columns Validation
// 3.Pagination
// 4.Real Time Data refresh on the Processing Grid



/// <reference types='cypress'/>
const processing_data = require('../queries/processing')
import processing from '../functions/processing'
import dup from '../functions/duplicate';
let envi = Cypress.env('ENV')
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));


describe('Processing',function(){

    beforeEach(() => {
        cy.viewport(1400, 1000);
      });

   
      it.only('Launching Consumer Data',()=>{
        dup.launching_consumer_data()
      })
   

      it.only("Changing th role to Intel bizops", () => {
        dup.role_change(config,'3');
        dup.launching_consumer_data()
      });

    it.only('TC01 - Checking for Inprocess tab and subdescription',()=>{
        processing.uploadHistoryButton_click()
        processing.InprocessTab_validation(processing_data.inprocesstab_title,processing_data.inprocesspage_subdesc)
        cy.wait(5000)
        
    })


    it.only('TC02 - Columns Validation',()=>{
        
       processing.columns_validaiton(processing_data.expected_columns_processing)

    })


       

    it.only('TC03 - Pagination',()=>{
        processing.action_pagination()
    })


    it.only('TC04 - Grid Data ',()=>{
      processing.griddata(processing_data.grid_query,config)
    })


    it.only('Setting the onboard_status=Internal_success',()=>{
        processing.set_status(processing_data.set_status_success,config)
        
    })

    it.only('Setting the path for enriched file original',()=>{
        processing.set_status(processing_data.set_status_data_dump_path_original,config)
        
    })


    it.only('Setting the path for validation report original',()=>{
        processing.set_status(processing_data.set_validation_report_original,config)
        
    })




    it.only('TC05 - Checking the status field for runtime change of values',()=>{
      processing.set_status_failed(processing_data.set_status_failed,config)
    })

    it.only('TC06 - Checking the enriched field for runtime change of values',()=>{
       processing.enriched_file_data(processing_data.set_status_data_dump_path,config)
     })

     it.only('TC07 - Checking the validation report for runtime change of values',()=>{
       processing.valdiation_report_data(processing_data.set_validation_report,config)
     })

    it.only('TC08 - Filter column Partner and Status',()=>{
        processing.filter_allcolumns(processing.filter_all['partner'],processing_data.filter_partner_data,processing_data.filter_partner_query,config)
        processing.filter_allcolumns(processing.filter_all['status'],processing_data.filter_status,processing_data.filter_status_query,config)
    })


})


