// ************************ Upload history page***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Upload history Grid
// 
// There are few requisite that needs to be done beofre running this spec file, otherwise the test cases may fail
// 1.The Grid should not be empty
// 2.It should contain atleast 5 inactive records to test the inactive button functionality
// 3.It should contain atleast 5 published and processed files to test the publish button functionality
//
// Below are the Scenarios Covered for testing these tables:
// 1.Grid Columns Validation
// 2.Export button functionality
// 3.Column level filter validation
// 4.Sorting in the columns Uploaded date and Modified Date
// 5.File Link Validation
// 6.Inactive button Functionality
// 7.Publish button functionality

//<reference types="cypress" />
import uploadHistory from "../functions/upload_history";
const queries = require("../queries/history_page_queries");
const env_var = require('../support/environment')
let envi = Cypress.env('ENV'); 
const { encrypt, decrypt } = require('../e2e/crypto')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';
import rolefunc from '../functions/role'

describe("Upload_History_Page", () => {
  before(() => {
    cy.viewport(1400, 1000);
  });

  beforeEach(() => {
    cy.viewport(2500, 1000);

  });


  afterEach(function(){
    if(this.currentTest.state === 'failed'){
      cy.reload()
      cy.wait(20000)
 
      
     }
    })

 

  it.only('Launching Consumer Data',()=>{
    dup.launching_consumer_data()
    cy.wait(10000)
  })

  it.only("Changing th role to Intel bizops", () => {
    dup.role_change(config,'3');
    dup.launching_consumer_data()
    cy.wait(20000)
  });

  it.only('make dflt_ind-N',{

    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        rolefunc.make_dflt_ind(config)
      })

  it.only("Going to upload history page", () => {
    uploadHistory.uploadHistoryButton_click("Historical Data");
    cy.wait(5000);
  });

  it.only("TC01 - Checking for the title of the Upload History Page", function () {
    uploadHistory.pageTitle_validation("Historical Data");
  });

  it.only("TC02 - Checking for the History tab and subdescription", function () {
    uploadHistory.HistoryTab_validation(
      "History",
      "Search and view historical data and take follow up action accordingly."
    );
  });

  it.only("TC03 - Checking for Inprocess tab and subdescription", function () {
    uploadHistory.InprocessTab_validation(
      "Processing",
      "All processed files will be moved to the history section."
    );
  });

  it.only("TC04 - Columns Validation", () => {
    cy.wait(1000);
    uploadHistory.columns_validaiton([
      "",
      "File Reference Id",
      "Partner",
      "Uploaded Date (UTC)",
      "Dataset",
      "File Name",
      "Submission Period",
      "Rows Loaded",
      "Restatement",
      "Duplicate",
      "Submitted By",
      "File Status",
      "Enriched File",
      "Modified By",
      "Modified Date (UTC)",
    ]);
  });

  it.only("TC05 - Export Full Data", () => {
    uploadHistory.exportfulldata(
      "Export",
      "./cypress/downloads",
      "./cypress/downloads/export_fulldata.csv",
      "./cypress/downloads"
    );
  });

  it.only("TC06 - Export Selected Data", () => {
    uploadHistory.exportSelectedData(
      "./cypress/downloads",
      "./cypress/downloads/export_selecteddata.csv"
    );
  });

  it.only("TC07 - Export button Disabled", () => {
    uploadHistory.export_button_disabled("???///");
  });

  it.only("TC08 - Export Column Filtered Data", () => {
    uploadHistory.exportcolumnFIlteredData(
      "./cypress/downloads",
      "./cypress/downloads/export_columnlevelfiltereddata.csv",
      "b"
    );
  });

  it.skip("TC09 - Export Paginated Selected Data", () => {
    uploadHistory.exportPaginatedData(
      "./cypress/downloads",
      "./cypress/downloads/export_paginateddata.csv"
    );
  });

  it.only("TC10 - Filter File Ref ID Column", () => {
    // console.log(uploadHistory.filter_all['file_reference_id'])
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["file_reference_id"],
      "6",
      queries.filter_fil_ref_id,
      config
    );
  });

  it.only("TC11 - Filter Partner Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["partner"],
      "Ar",
      queries.filter_partner,
      config
    );
  });

  it.only("TC12 - Filter uploaded_date Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["uploaded_date"],
      "05",
      queries.filter_uploaded_date,
      config
    );
  });

  it.only("TC13 - Filter Dataset Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["dataset"],
      "i",
      queries.filter_dataset,
      config
    );
  });

  it.only("TC14 - Filter File Name Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["filename"],
      "happy",
      queries.filter_filename,
      config
    );
  });

  it.only("TC15 - Filter Submission Period Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["submission_period"],
      "sep",
      queries.filter_submission_period,
      config
    );
  });

  it.only("TC16 - Filter Rows Loaded Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["rowsloaded"],
      "9",
      queries.filter_rows_loaded,
      config
    );
  });

  it.only("TC17 - Filter Restatement Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["restatement"],
      "y",
      queries.filter_restatement,
      config
    );
  });

  it.only("TC18 - Filter Submitted By Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["submitted_by"],
      "Vignesh",
      queries.filter_submitted_by,
      config
    );
  });

  it.only("TC19 - Filter File Status Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["filestatus"],
      "Publish",
      queries.filter_file_status,
      config
    );
  });

  it.only("TC20 - Filter Modified By Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["modified_by"],
      "y",
      queries.filter_modified_by,
      config
    );
  });

  it.only("TC21 - Filter Modified Datetime Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["modified_datetime"],
      "07",
      queries.filter_modified_datetime,
      config
    );
  });

  it.only("TC22 - Filter Duplicate Column", () => {
    uploadHistory.filter_allcolumns(
      uploadHistory.filter_all["duplicate"],
      "y",
      queries.filter_duplicate,
      config
    );
  });

  it.only('TC23 - Inactive button disabled on page load',()=>{
    
      uploadHistory.inactive_button_diabled_Validation()
  })

  it.only('TC24 - Inactive button disabled for Inactive Selection',()=>{
      uploadHistory.inactive_button_disabled_inactive_selection_Validation()
  })

  it.only('TC25 - Inactive button enabled and Multiple Files Selection',()=>{
    uploadHistory.inactive_button_enabled_selection_Validation('multiple',2)
})

  it.only('TC26 - Inactive button enabled and File Status Validation',()=>{
      uploadHistory.inactive_button_enabled_selection_Validation('single','1')
  })

 

  it.only('TC27 - Sorting Uploaded Date in ascending and Checking the first and last value',()=>{
     
     uploadHistory.sorting(config,queries.uploadedDate_ascending,"Uploaded Date",'Asc')
  })

  it.only('TC28 - Sorting Uploaded Date in descending and Checking the first and last value',()=>{
     
     uploadHistory.sorting(config,queries.uploadedDate_descending,"Uploaded Date",'Desc')
  })

  it.only('TC29 - Sorting Modified Date in ascending and Checking the first and last value',()=>{
     
     uploadHistory.sorting(config,queries.modifiedDate_ascending,"Modified Date",'Asc')
  })

  it.only('TC30 - Sorting Modified Date in descending and Checking the first and last value',()=>{
      
     uploadHistory.sorting(config,queries.modifiedDate_descending,"Modified Date",'Desc')
  })

  it.only('TC31 - Grid Data Count and Data Validation',()=>{
      uploadHistory.griddata(queries.grid_data,config)

  })

  it.only('TC32 - Pagination',()=>{
      
      uploadHistory.action_pagination()
  })

  

  it.only('TC33 - File Name - Link to Download',()=>{
      uploadHistory.file_name_link()
  })

  it.only('TC33 - Checking the Downloaded File - For Rows Count',()=>{
      uploadHistory.read_csv('./cypress/downloads/',queries.file_name_query,config)
  })


  it.only("TC34 - Publish button disabled on page load", () => {
    uploadHistory.publish_button_disabled_page_load();
  });

  it.only("TC35 - Publish button diabled on selecting Published File ", () => {
    uploadHistory.publish_button_disabled_publish_file();
  });

  it.only("TC36 - Publish button diabled on selecting Published and Processed Files ", () => {
    uploadHistory.selecting_published_processed()
  });

  it.only("TC37 - Publish button diabled when no data is present in the grid", () => {
    uploadHistory.no_data_grid_publish_button()

  });

  it.only("TC38 - Publish button enabled on selecting processed files", () => {
    uploadHistory.selecting_process_Files()

  });

  it.only("TC39 - Publishing a Single File and check the status change in UI and backend", () => {
    uploadHistory.selecting_single_file(config)

  });

  it.only("TC40 - Publishing multiple Files and check the status change in UI and backend", () => {

    uploadHistory.selecting_multiple_files(config)
  });

  it.only("TC41 - PUblish button visible for Account Manager and Intel Bizops", () => {
    uploadHistory.publish_button_visible_role(config,2)
    uploadHistory.publish_button_visible_role(config,3)
   
  });

  

  it.only("TC42 - PUblish button not visible for other roles except Account Manager and Intel Bizops", () => {
    uploadHistory.publish_button_not_visible_role(config,1)  //parametes - config , role_id
    uploadHistory.publish_button_not_visible_role(config,5)
    uploadHistory.publish_button_not_visible_role(config,6)
  });


  it.only("Changing th role to Intel bizops", () => {
    dup.role_change(config,'3');
    dup.launching_consumer_data()
  });

  it.only("Going to upload history page", () => {
    uploadHistory.uploadHistoryButton_click("Historical Data");
    cy.wait(5000);
  });


  it.only("TC43 - Inactive button disabled for duplicate row selection", () => {
   uploadHistory.inactive_disabled_duplicate()

  });






  



});
