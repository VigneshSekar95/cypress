// ************************ Configuration page - File Metadata Tables Check***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Metadata tables in the UI Configuration page
// 
// In this spec file, we are checking the below tables in the FileMeta section:
// 1.Restate Reason
// 2.Switch
// 3.Transformation
// 4.Qualification System
// 5.Dataset
// 6.Use Case Type
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Adding a Record and checking the record is available in the grid
// 2.Search for a Record in the Grid
// 3.Edit a  Record and Check the edited data is available in Grid
// 4.Pagination
// 5.Grid Data Validation
// 6.Is_active button functionality
// 7.Uniqueness Violation Check
// 8.Cheking the Maxallowed character for the input fields
// 9.Checking in the backend whether the new entries are created.



let envi = Cypress.env('ENV')
import config_page from '../functions/config_page'
let excel_data = require("../fixtures/output.json");
let character_50 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
let character_255 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';


describe("Configuration Page - III", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    before(() => {
      cy.viewport(1400, 1000);
     
    });
  
    beforeEach(() => {
      cy.viewport(1400, 1000);
     
    });

    afterEach(function(){
    if(this.currentTest.state === 'failed'){
      cy.reload()
      cy.wait(10000)
      
     }


     

    })

    it.only('Launching Consumer Data',()=>{

      dup.launching_consumer_data()
       cy.wait(10000)
     })
 
     
 it.only("Changing th role to Intel bizops", () => {
   dup.role_change(config,'3');
   dup.launching_consumer_data()
 });



  it.only("Going to Configuration page", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.config_page('Configuration', 'Configure Tables')
    
  });

 

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Restate_Reason"
    ) {
      it.only("TC101 - Add a new Restate Reason and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('13')
        config_page.add_new_record('13',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Restate Reason',
          'Restate Reason Name',
          'Restate Reason Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Restate_Reason"
    ) {
      it.only("TC102 - Search for a Record in the Restate Reason Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('13')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Restate_Reason"
    ) {
      it.only("TC103 - Edit a  Restate Reason and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('13')
        config_page.edit('13',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Restate Reason',
          'Restate Reason Name',
          'Restate Reason Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Restate_Reason"
    ) {
      it.only("TC104 - Restate Reason pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('13')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Restate_Reason"
    ) {
      it.only("TC105 - Restate Reason Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('13')
        config_page.griddata('select restate_rsn_cd,restate_rsn_dsc from cdm_core.restate_rsn_lkup order by cre_dtm desc',
        config,
        ['restate_rsn_cd','restate_rsn_dsc','Restate Reason Name','Restate Reason Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Restate_Reason"
    ) {
      it.only("TC106 - Restate Reason Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('13')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Restate_Reason"
    ) {
      it.only("TC107 - Restate Reason Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_core.restate_rsn_lkup where cre_dtm <> chg_dtm and restate_rsn_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Restate_Reason"
    ) {
      it.only("TC108 - Restate Reason Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('13')
        config_page.error_check('13',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Restate_Reason"
    ) {
      it.only("TC109 - Restate Reason MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('13')
           config_page.add_new_record('13',
            character_50,
          character_255,
        'Add a new Restate Reason',
        'Restate Reason Name',
        'Restate Reason Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Restate_Reason"
    ) {
      it.only("TC110 - Deleting Dummy Record for Restate Reason", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.restate_rsn_lkup where restate_rsn_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.restate_rsn_lkup where restate_rsn_cd='",character_50.substring(0,47),config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Switch"
    ) {
      it.only("TC111 - Add a new Switch and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('14')
        config_page.add_new_record('14',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Switch',
          'Switch Name',
          'Switch Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Switch"
    ) {
      it.only("TC112 - Search for a Record in the Switch Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('14')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Switch"
    ) {
      it.only("TC113 - Edit a  Switch and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('14')
        config_page.edit('14',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Switch',
          'Switch Name',
          'Switch Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Switch"
    ) {
      it.only("TC114 - Switch pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('14')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Switch"
    ) {
      it.only("TC115 - Switch Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('14')
        config_page.griddata('select switc_cd,switc_dsc from cdm_core.switc_lkup order by cre_dtm desc',
        config,
        ['switc_cd','switc_dsc','Switch Name','Switch Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Switch"
    ) {
      it.only("TC116 - Switch Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('14')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Switch"
    ) {
      it.only("TC117 - Switch Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_core.switc_lkup where cre_dtm <> chg_dtm and switc_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Switch"
    ) {
      it.only("TC118 - Switch Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('14')
        config_page.error_check('14',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Switch"
    ) {
      it.only("TC119 - Switch MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('14')
           config_page.add_new_record('14',
            character_50,
          character_255,
        'Add a new Switch',
        'Switch Name',
        'Switch Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Switch"
    ) {
      it.only("Deleting Dummy Record for Switch", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.switc_lkup where switc_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.switc_lkup where switc_cd='",character_50.substring(0,47),config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Transformation"
    ) {
      it.only("TC121 - Add a new Transformation and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('15')
        config_page.add_new_record('15',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Transformation',
          'Transformation Name',
          'Transformation Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Transformation"
    ) {
      it.only("TC122 - Search for a Record in the Transformation Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('15')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Transformation"
    ) {
      it.only("TC123 - Edit a  Transformation and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('15')
        config_page.edit('15',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Transformation',
          'Transformation Name',
          'Transformation Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Transformation"
    ) {
      it.only("TC124 - Transformation pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('15')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Transformation"
    ) {
      it.only("TC125 - Transformation Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('15')
        config_page.griddata('select xfrm_cd,xfrm_dsc from cdm_core.xfrm_lkup order by cre_dtm desc',
        config,
        ['xfrm_cd','xfrm_dsc','Transformation Name','Transformation Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Transformation"
    ) {
      it.only("TC126 - Transformation Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('15')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Transformation"
    ) {
      it.only("TC127 - Transformation Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_core.xfrm_lkup where cre_dtm <> chg_dtm and xfrm_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Transformation"
    ) {
      it.only("TC128 - Transformation Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('15')
        config_page.error_check('15',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Transformation"
    ) {
      it.only("TC129 - Transformation MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('15')
           config_page.add_new_record('15',
            character_50,
          character_255,
        'Add a new Transformation',
        'Transformation Name',
        'Transformation Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Transformation"
    ) {
      it.only("TC130 - Deleting Dummy Record for Transformation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    
           config_page.delete_the_record("delete from cdm_core.xfrm_lkup where xfrm_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.xfrm_lkup where xfrm_cd='",character_50.substring(0,47),config);
      });
    }
  }


  

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Qualification_System"
    ) {
      it.only("TC231 - Add a Qualification System and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('12')
        config_page.qualification_new_record('12',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Input_Parameter_Value_3,
          'Add a new Qualification System',
          'Qualification System Name',
          'Qualification System Description',
          'Platform',
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Qualification_System"
    ) {
      it.only("TC232 - Search for a Record in the Qualification System Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('12')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Qualification_System"
    ) {
      it.only("TC233 - Edit a  Qualification System and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('12')
        config_page.qualfication_edit_record('12',
        excel_data[i].Input_Parameter_Value_1,
        excel_data[i].Input_Parameter_Value_2,
        excel_data[i].Input_Parameter_Value_3,
        'Edit Qualification System',
        'Qualification System Name',
        'Qualification System Description',
        'Platform',
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Qualification_System"
    ) {
      it.only("TC234 - Qualification System pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('12')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Qualification_System"
    ) {
      it.only("TC235 - Qualification System Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('12')
        config_page.qual_griddata('select qlfy_sys_cd,pltfrm_cd,qlfy_sys_dsc  from cdm_core.qlfy_sys_lkup order by cre_dtm desc',
        config,
        ['qlfy_sys_cd','pltfrm_cd','qlfy_sys_dsc','Qualification System Name','Qualification System Description,File Type'],
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Qualification_System"
    ) {
      it.only("TC236 - Qualification System Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('12')
        config_page.qual_is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Qualification_System"
    ) {
      it.only("TC237 - Qualification System Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_core.qlfy_sys_lkup where cre_dtm <> chg_dtm and qlfy_sys_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Qualification_System"
    ) {
      it.only("TC238 - Qualification System Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('12')
        config_page.qual_error_check('12',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Input_Parameter_Value_3
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Qualification_System"
    ) {
      it.only("TC239 - Qualification System MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('12')
           config_page.qualification_new_record('12',
            character_50,
          character_255,
          'ERP',
          'Add a new Qualification System',
          'Qualification System Name',
          'Qualification System Description',
          'Platform',
      
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Qualification_System"
    ) {
      it.only("TC240 - Deleting Dummy Record for External Object Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.qlfy_sys_lkup where qlfy_sys_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.qlfy_sys_lkup where qlfy_sys_cd='",character_50.substring(0,47),config);
      });
    }
  }


  
  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Dataset"
    ) {
      it.only("TC241 - Add a Dataset and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('2')
        config_page.dataset_new_record('2',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Input_Parameter_Value_3,
          excel_data[i].Input_Parameter_Value_4,
          excel_data[i].Input_Parameter_Value_5,
          'Add a new Dataset',
          'Dataset Name',
          'Dataset Description',
          'File Type',
          'File Delimiter',
          'Header Indicator'
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Dataset"
    ) {
      it.only("TC242 - Search for a Record in the Dataset Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('2')
        config_page.search(
            
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Dataset"
    ) {
      it.only("TC243 - Edit a  Qualification System and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('2')
        config_page.dataset_edit_record('2',
        excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Input_Parameter_Value_3,
          excel_data[i].Input_Parameter_Value_4,
          excel_data[i].Input_Parameter_Value_5,
        'Edit Dataset',
        'Dataset Name',
          'Dataset Description',
          'File Type',
          'File Delimiter',
          'Header Indicator'
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Dataset"
    ) {
      it.only("TC244 - Dataset pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('2')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Dataset"
    ) {
      it.only("TC245 - Dataset Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('2')
        config_page.dataset_griddata('select dset_cd,dset_dsc,file_type_cd,file_dlmtr,hdr_ind  from cdm_core.dset_lkup order by cre_dtm desc',
        config,
        ['dset_cd','dset_dsc','file_type_cd','file_dlmtr','hdr_ind','Dataset Name','Dataset Description','File Type','File Delimiter','Header Indicator'],
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Dataset"
    ) {
      it.only("TC246 - Dataset Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('2')
        config_page.dataset_is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Dataset"
    ) {
      it.only("TC247 - Dataset Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_core.dset_lkup where cre_dtm <> chg_dtm and dset_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Dataset"
    ) {
      it.only("TC248 - Dataset Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('2')
        config_page.dataset_error_check('2',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Input_Parameter_Value_3,
          excel_data[i].Input_Parameter_Value_4,
          excel_data[i].Input_Parameter_Value_5,
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Dataset"
    ) {
      it.only("TC249 - Dataset MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('2')
           config_page.dataset_new_record('2',
            character_50,
          character_255,
          'Delimited',
          '|',
          'N',
          'Add a new Dataset',
          'Dataset Name',
          'Dataset Description',
          'File Type',
          'File Delimiter',
          'Header Indicator'
      
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Dataset"
    ) {
      it.only("TC250 - Deleting Dummy Record for Dataset", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.dset_lkup where dset_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.dset_lkup where dset_cd='",character_50.substring(0,47),config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Use_Case_Type"
    ) {
      it.only("TC251 - Add a new Use Case type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('16')
        config_page.add_new_record('16',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Usecase Type',
          'Usecase Type Name',
          'Usecase Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Use_Case_Type"
    ) {
      it.only("TC252 - Search for a Record in the Use Case Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('16')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Use_Case_Type"
    ) {
      it.only("TC253 - Edit a  Use case type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('16')
        config_page.edit('16',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Usecase Type',
          'Usecase Type Name',
          'Usecase Type Description'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Use_Case_Type"
    ) {
      it.only("TC254 - Use Case type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('16')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Use_Case_Type"
    ) {
      it.only("TC255 - Use Case Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('16')
        config_page.griddata('select use_case_type_cd,use_case_type_dsc from cdm_core.use_case_type_lkup order by cre_dtm desc',
        config,
        ['use_case_type_cd','use_case_type_dsc','Usecase Type Name','Usecase Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Use_Case_Type"
    ) {
      it.only("TC256 - Use Case Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('16')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Use_Case_Type"
    ) {
      it.only("TC107 - Use Case Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_core.use_case_type_lkup where cre_dtm <> chg_dtm and use_case_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Use_Case_Type"
    ) {
      it.only("TC258 - Use Case Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('16')
        config_page.error_check('16',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Use_Case_Type"
    ) {
      it.only("TC259 - UseCase Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.going_to_table('16')
           config_page.add_new_record('16',
            character_50,
          character_255,
          'Add a new Usecase Type',
          'Usecase Type Name',
          'Usecase Type Description'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Use_Case_Type"
    ) {
      it.only("TC260 - Deleting Dummy Record for Use Case Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_core.use_case_type_lkup where use_case_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_core.use_case_type_lkup where use_case_type_cd='",character_50.substring(0,47),config);
      });
    }
  }


})