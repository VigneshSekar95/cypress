// ************************ Upload New File***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Upload New File page
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking the Dropdown selection
// 2.Template Name for the selected template
// 3.Uploading the File
// 4.Checking the Preload and External Messages for various scenarios.


import homepage from '../functions/home_page'
let envi = Cypress.env('ENV')
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';
import uploadfile from '../functions/uploadnewfile'

describe("UploadNewFile", function () {
  beforeEach({
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
    cy.viewport(1400, 1000);
    
  });

  afterEach(function(){
    if(this.currentTest.state === 'failed'){
      cy.reload()
      cy.wait(10000)
 
      
     }


     

    })

 

  it.only('Launching Consumer Data App',()=>{

   dup.launching_consumer_data()
    cy.wait(10000)
    
  })


  it.only("Changing th role to Account Manager", () => {
    dup.role_change(config,'2');
    dup.launching_consumer_data()
    cy.wait(20000)
   });

  it.only("TC01 - Going to File Upload page", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
        uploadfile.visit_upload_file_page()
  });

  it.only("TC02 - Checking the page title", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
    uploadfile.uploadfilebutton.click()
    uploadfile.pagetitle_validation()
});

it.only("TC03 - Checking Dropdown headers", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
    uploadfile.dropdown_header()
});


it.only("TC04 - Dropdown Selection and browse button Disabled", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.Dropdown_selection()
});

it.only("TC05 - Template Name", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.Template_name(config)
});

it.only("Changing the file type to csv", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
},()=>{
uploadfile.file_type_changing_to_csv(config)
});

it.only("TC06 - CSV - Preload and External Pass", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.preload_external_pass('CSV','E2E_Databricks_job_All_Pass.csv')
});

it.only("TC07 - CSV - Upload a file with no headers", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
},()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_no_headers('CSV','E2E_No_header_ony_rows.csv')
});


it.only("TC08 - CSV - Upload a file with Mismatch headers", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
}, ()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_no_headers('CSV','E2E_Databricks_job_1_wrong_header.csv')
});


it.only("TC09 - CSV - Upload a file with only header", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_only_header('CSV','E2E_only_header.csv')
});

it.only("TC10 - CSV - Uploading xlsx file", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.uploading_xlsx_file('CSV','All_Pass.xlsx')
});

it.only("TC11 - CSV - Upload a file with different extension", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_different_extension('CSV','1.png')
});


it.only("TC12 - CSV - Preload Pass and External Fail", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.external_fail_scenario('CSV','Sample_fail.csv')
});


it.only("TC13 - CSV - TXT file with comma delimiter", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.preload_external_pass('CSV','All_Pass_comma_new.txt')
});


it.only("TC14 - CSV - TXT file with pipe delimiter", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_no_headers('CSV','All_Pass_pipe.txt')
});


it.skip("Changing the file type to xlsx", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.file_type_changing_to_xlsx(config)
});


it.skip("TC15 - Excel - Preload and External Pass ", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.preload_external_pass('excel','All_Pass.xlsx')
});



it.skip("TC16 - Excel - Upload a file with no headers", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
},()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_no_headers('excel','No_header_only_rows.xlsx')
});


it.skip("TC17 - Excel - Upload a file with Mismatch headers", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
},()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_only_header('excel','wrong_header.xlsx')
});


it.skip("TC18 - Excel - Upload a file with only header", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_only_header('excel','only_header.xlsx')
});


it.skip("TC19 - Excel - Uploading CSV file", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.uploading_csv_file('excel','Sample_fail.csv')
});

it.skip("TC20 - Excel - Upload a file with different extension", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_different_extension('excel','1.png')
});


it.skip("TC21 - Excel - Preload Pass and External Fail", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.external_fail_scenario('excel','Fail_scenario.xlsx')
});


it.skip("Changing the file type to pipe", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.file_type_changing_to_pipe(config)
});


it.skip("TC22 - Pipe - Preload and External Pass ", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.preload_external_pass('txt','All_Pass.txt')
});



it.skip("TC23 - Pipe - Upload a file with no headers", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
}, ()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_no_headers('txt','No_header_only_rows.txt')
});


it.skip("TC24 - Pipe - Upload a file with Mismatch headers", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
}, ()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_no_headers('txt','wrong_header.txt')
});


it.skip("TC25 - Pipe - Upload a file with only header", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_only_header('txt','only_header.txt')
});


it.skip("TC26 - Pipe - Uploading CSV file", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_no_headers('txt','Sample_fail.csv')
});


it.skip("TC27 - Pipe - Upload a file with different extension", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.upload_file_different_extension('txt','1.png')
});


it.skip("TC28 - Pipe - Preload Pass and External Fail", {
    retries: {
      runMode: 1,
      openMode: 1,
    },
  },()=>{
  uploadfile.access_token_storage()
  uploadfile.external_fail_scenario('txt','Fail_scenario.txt')
});


it.skip("TC29 - pipe - Uploading xlsx file", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
},()=>{
uploadfile.access_token_storage()
uploadfile.uploading_xlsx_file('txt','All_Pass.xlsx')
});


it.skip("TC30 - Template Version Dropdown Selection", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
},()=>{
uploadfile.access_token_storage()
uploadfile.version_dropdown_validation(config,'Laptop')
});


it.skip("TC31 - Uploading a File and checking the backend", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
},()=>{
uploadfile.access_token_storage()
uploadfile.external_fail_scenario_version('CSV','Sample_fail.csv',config,'Laptop')
uploadfile.Checking_backend(config,'Laptop')
});

it.skip("TC31 - Uploading a File and checking the backend for differnt version", {
  retries: {
    runMode: 1,
    openMode: 1,
  },
},()=>{
uploadfile.access_token_storage()
uploadfile.external_fail_scenario_version('CSV','Sample_fail.csv',config,'Salesout')
uploadfile.Checking_backend(config,'Salesout')
});


});
