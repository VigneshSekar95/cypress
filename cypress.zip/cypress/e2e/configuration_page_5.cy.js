// ************************ Configuration page - File Metadata Tables Check***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Metadata tables in the UI Configuration page
// 
// In this spec file, we are checking the below tables in the FileMeta section:
// 1.Application Type
// 2.Connection Parameter
// 3.Database Type
// 4.External Application
// 5.External Object Type
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Adding a Record and checking the record is available in the grid
// 2.Search for a Record in the Grid
// 3.Edit a  Record and Check the edited data is available in Grid
// 4.Pagination
// 5.Grid Data Validation
// 6.Is_active button functionality
// 7.Uniqueness Violation Check
// 8.Cheking the Maxallowed character for the input fields
// 9.Checking in the backend whether the new entries are created.



let envi = Cypress.env('ENV')
import config_page from '../functions/config_page';
let excel_data = require("../fixtures/output.json");
let character_50 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
let character_255 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';

describe("Configuration Page - V", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    before(() => {
      cy.viewport(1400, 1000);
    });
  
    beforeEach(() => {
      cy.viewport(1400, 1000);
    });

    afterEach(function(){
    if(this.currentTest.state === 'failed'){
      cy.reload()
      cy.wait(10000)
    
     }


     

    })

    it.only('Launching Consumer Data',()=>{

      dup.launching_consumer_data()
       cy.wait(10000)
     })
 
     
 it.only("Changing th role to Intel bizops", () => {
   dup.role_change(config,'3');
   dup.launching_consumer_data()
 });


  it.only("Going to Configuration page", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.config_page('Configuration', 'Configure Tables')
    
  });

 

  it.only("Going to External Call page", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.config_page('Configuration', 'Configure Tables')
    config_page.externalcall()
    
  });

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application_Type"
    ) {
      it.only("TC181 - Add a new Application Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('1','External')
        config_page.add_new_record('1',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Application Type',
          'Application Type Name',
          'Application Type Description',
          'External'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application_Type"
    ) {
      it.only("TC182 - Search for a Record in the Application Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('1','External')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Application_Type"
    ) {
      it.only("TC183 - Edit a  Application Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('1','External')
        config_page.edit('1',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Application Type',
          'Application Type Name',
          'Application Type Description',
          'External'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application_Type"
    ) {
      it.only("TC184 - Application Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('1','External')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application_Type"
    ) {
      it.only("TC185 - Application Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('1','External')
        config_page.griddata('select app_type_cd,app_type_dsc from cdm_extrnl_calls.app_type_lkup order by cre_dtm desc',
        config,
        ['app_type_cd','app_type_dsc','Application Type Name','Application Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application_Type"
    ) {
      it.only("TC186 - Application Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('1','External')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application_Type"
    ) {
      it.only("TC187 - Application Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_extrnl_calls.app_type_lkup where cre_dtm <> chg_dtm and app_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application_Type"
    ) {
      it.only("TC188 - Application Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('1','External')
        config_page.error_check('1',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application_Type"
    ) {
      it.only("TC189 - Application Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('1','External')
           config_page.add_new_record('1',
            character_50,
          character_255,
        'Add a new Application Type',
        'Application Type Name',
        'Application Type Description',
        'External'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Application_Type"
    ) {
      it.only("TC190 - Deleting Dummy Record for Application Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_extrnl_calls.app_type_lkup where app_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_extrnl_calls.app_type_lkup where app_type_cd='",character_50.substring(0,47),config);
      });
    }
  }

for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Connection_Parameter"
    ) {
      it.only("TC191 - Add a new Connection Parameter and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('2','External')
        config_page.add_new_record('2',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Connection Parameter',
          'Connection Parameter Name',
          'Connection Parameter Description',
          'External'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Connection_Parameter"
    ) {
      it.only("TC192 - Search for a Record in the Connection Parameter Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('2','External')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Connection_Parameter"
    ) {
      it.only("TC193 - Edit a  Connection Parameter and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('2','External')
        config_page.edit('2',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Connection Parameter',
          'Connection Parameter Name',
          'Connection Parameter Description',
          'External'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Connection_Parameter"
    ) {
      it.only("TC194 - Connection Parameter pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('2','External')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Connection_Parameter"
    ) {
      it.only("TC195 - Connection Parameter Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('2','External')
        config_page.griddata('select cnnct_parm_cd,cnnct_parm_dsc from cdm_extrnl_calls.cnnct_parm_lkup order by cre_dtm desc',
        config,
        ['cnnct_parm_cd','cnnct_parm_dsc','Connection Parameter Name','Connection Parameter Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Connection_Parameter"
    ) {
      it.only("TC196 - Connection Parameter Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('2','External')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Connection_Parameter"
    ) {
      it.only("TC197 - Connection Parameter Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_extrnl_calls.cnnct_parm_lkup where cre_dtm <> chg_dtm and cnnct_parm_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Connection_Parameter"
    ) {
      
      it.only("TC198 - Connection Parameter Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('2','External')
        config_page.error_check('2',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Connection_Parameter"
    ) {
      it.only("TC199 - Connection Parameter MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('2','External')
           config_page.add_new_record('2',
            character_50,
          character_255,
        'Add a new Connection Parameter',
        'Connection Parameter Name',
        'Connection Parameter Description',
        'External'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Connection_Parameter"
    ) {
      it.only("TC200 - Deleting Dummy Record for Connection Parameter", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_extrnl_calls.cnnct_parm_lkup where cnnct_parm_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_extrnl_calls.cnnct_parm_lkup where cnnct_parm_cd='",character_50.substring(0,47),config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Database_Type"
    ) {
      it.only("TC201 - Add a new Database Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('3','External')
        config_page.add_new_record('3',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new Database Type',
          'Database Type Name',
          'Database Type Description',
          'External'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Database_Type"
    ) {
      it.only("TC202 - Search for a Record in the Database Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('3','External')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_Database_Type"
    ) {
      it.only("TC203 - Edit a  Database Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('3','External')
        config_page.edit('3',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit Database Type',
          'Database Type Name',
          'Database Type Description',
          'External'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Database_Type"
    ) {
      it.only("TC204 - Database Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('3','External')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Database_Type"
    ) {
      it.only("TC205 - Database Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('3','External')
        config_page.griddata('select db_type_cd,db_type_dsc from cdm_extrnl_calls.db_type_lkup order by cre_dtm desc',
        config,
        ['db_type_cd','db_type_dsc','Database Type Name','Database Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Database_Type"
    ) {
      it.only("TC206 - Database Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('3','External')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Database_Type"
    ) {
      it.only("TC207 - Database Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_extrnl_calls.db_type_lkup where cre_dtm <> chg_dtm and db_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Database_Type"
    ) {
      it.only("TC208 - Database Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('3','External')
        config_page.error_check('3',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Database_Type"
    ) {
      it.only("TC209 - Database Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('3','External')
           config_page.add_new_record('3',
            character_50,
          character_255,
        'Add a new Database Type',
        'Database Type Name',
        'Database Type Description',
        'External'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_Database_Type"
    ) {
      it.only("TC210 - Deleting Dummy Record for Database Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_extrnl_calls.db_type_lkup where db_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_extrnl_calls.db_type_lkup where db_type_cd='",character_50.substring(0,47),config);
      });
    }
  }
  
  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Object_Type"
    ) {
      it.only("TC211 - Add a new External Object Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('5','External')
        config_page.add_new_record('5',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Add a new External Object Type',
          'External Object Type Name',
          'External Object Type Description',
          'External'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Object_Type"
    ) {
      it.only("TC212 - Search for a Record in the External Object Type Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('5','External')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_External_Object_Type"
    ) {
      it.only("TC213 - Edit a  External Object Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('5','External')
        config_page.edit('5',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Edit External Object Type',
          'External Object Type Name',
          'External Object Type Description',
          'External'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Object_Type"
    ) {
      it.only("TC214 - External Object Type pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('5','External')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Object_Type"
    ) {
      it.only("TC215 - External Object Type Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('5','External')
        config_page.griddata('select obj_type_cd,obj_type_dsc from cdm_extrnl_calls.extrnl_obj_type_lkup order by cre_dtm desc',
        config,
        ['obj_type_cd','obj_type_dsc','External Object Type Name','External Object Type Description'],
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Object_Type"
    ) {
      it.only("TC216 - External Object Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('5','External')
        config_page.is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Object_Type"
    ) {
      it.only("TC217 - External Object Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('5','External')
        config_page.backend_entry("select count(*) as cnt from cdm_extrnl_calls.extrnl_obj_type_lkup where cre_dtm <> chg_dtm and obj_type_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Object_Type"
    ) {
      it.only("TC218 - External Object Type Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('5','External')
        config_page.error_check('5',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Object_Type"
    ) {
      it.only("TC219 - External Object Type MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('5','External')
           config_page.add_new_record('5',
            character_50,
          character_255,
        'Add a new External Object Type',
        'External Object Type Name',
        'External Object Type Description',
        'External'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Object_Type"
    ) {
      it.only("TC220 - Deleting Dummy Record for External Object Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_extrnl_calls.extrnl_obj_type_lkup where obj_type_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_extrnl_calls.extrnl_obj_type_lkup where obj_type_cd='",character_50.substring(0,47),config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Application"
    ) {
      it.only("TC221 - Add a new External Object Type and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('4','External')
        config_page.external_new_record('4',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Input_Parameter_Value_3,
          excel_data[i].Input_Parameter_Value_4,
          'Add a new External Application',
          'External Application Name',
          'External Application Description',
          'External Database Type Name',
          'External Application Type Name',
          'External'
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Application"
    ) {
      it.only("TC222 - Search for a Record in the External Application Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('4','External')
        config_page.search(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Table_Name
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Edit_External_Application"
    ) {
      it.only("TC223 - Edit a  External application and Check the data is available in Grid", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('4','External')
        config_page.external_edit_record('4',
        excel_data[i].Input_Parameter_Value_1,
        excel_data[i].Input_Parameter_Value_2,
        excel_data[i].Input_Parameter_Value_3,
        excel_data[i].Input_Parameter_Value_4,
          'Edit External Application',
          'External Application Name',
          'External Application Description',
          'External Database Type Name',
          'External Application Type Name',
          'External'
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Application"
    ) {
      it.only("TC224 - External Application pagination", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('4','External')
        config_page.action_pagination();
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Application"
    ) {
      it.only("TC225 - External Application Grid Data Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('4','External')
        config_page.external_griddata('select app_cd,db_type_cd,app_type_cd,app_dsc  from cdm_extrnl_calls.extrnl_app_lkup order by cre_dtm desc',
        config,
        ['app_cd','db_type_cd','app_type_cd','app_dsc','External Application Name','External Application Description','External Database Type Name','External Application Type Name'],
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Application"
    ) {
      it.only("TC226 - External Object Type Is_Active_Button Validation", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('4','External')
        config_page.external_is_active(excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Application"
    ) {
      it.only("TC227 - External Object Type Checking the Backend Entry ", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
        config_page.backend_entry("select count(*) as cnt from cdm_extrnl_calls.extrnl_app_lkup where cre_dtm <> chg_dtm and app_cd='",
        config,
        excel_data[i].Input_Parameter_Value_1)
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Application"
    ) {
      it.only("TC228 - External Application Uniqueness Error Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('4','External')
        config_page.external_error_check('4',
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Input_Parameter_Value_3,
          excel_data[i].Input_Parameter_Value_4
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Application"
    ) {
      
      it.only("TC229 - External Application MaxCharacter Allowed Check", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
    config_page.externalcall()
    config_page.going_to_table('4','External')
           config_page.external_new_record('4',
            character_50,
          character_255,
          'Hive',
          'DBMS',
          'Add a new External Application',
          'External Application Name',
          'External Application Description',
          'External Database Type Name',
          'External Application Type Name',
          'External'
      );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "Metadata_Tables" &&
      excel_data[i].Test_Case_Name == "Add_External_Application"
    ) {
      it.only("TC230 - Deleting Dummy Record for External Object Type", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=> {
           config_page.delete_the_record("delete from cdm_extrnl_calls.extrnl_app_lkup where app_cd='",excel_data[i].Input_Parameter_Value_1,config);
           config_page.delete_the_record("delete from cdm_extrnl_calls.extrnl_app_lkup where app_cd='",character_50.substring(0,47),config);
      });
    }
  }



 

  

})