// ************************ Duplicate Tab - Historical Data Section***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Duplicate tab of the Historical Data section
// 
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking the Title and Description of the Duplicate tab
// 2.Verifying the column level filter is working for all the columns in the grid
// 3.Sorting the grid using uploaded date
// 4.Pagination
// 5.Grid Data Validation
// 6.Accept and Reject Functionality
// 7.Role based check for the Grid data and buttons in the duplicate grid



import dup from '../functions/duplicate';
let envi = Cypress.env('ENV'); 
const env_var = require('../support/environment')
const { encrypt, decrypt } = require('./crypto');
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));


describe("Duplicate Tab", () => {
  
  beforeEach(function()  {
    
    cy.viewport(2400, 1500);

  });
  
  afterEach(function(){
    if(this.currentTest.state === 'failed'){
      cy.reload()
     // dup.launching_consumer_data()
      cy.wait(10000)
    
      
     }

    })


it.only('Launching Consumer Data App',()=>{

   dup.launching_consumer_data()
   cy.wait(10000)
})

it.only("Changing th role to Intel bizops", () => {
  dup.role_change(config,'3');
  dup.launching_consumer_data()
  cy.wait(20000)
});

it.only('TC01 - Going to Duplicate Tab section',()=>{
    dup.duplicate_tab_section_1()
  
  })


it.only('TC02 - Heading and Subheading Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.heading_subheading()
})


it.only('TC03 - Grid Columns Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.grid_columns_Validation([
        "","","File Reference Id",
        "Partner",
        "Dataset",
        "File Name",
        "Uploaded Date (UTC)",
        "Uploaded By",
        "Upload Mode",
        "Duplicate Row Count",
        "Validation Report"
      ])
})

it.only('TC19 - file_ref_id Filter Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.filter_allcolumns(
        dup.filter_all["file_ref_id"],
        "3",
        `
        select count(*) as cnt
                from 
                   cdm_core.file_onbord_instc fil
                     inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                            inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                            inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
                            inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
                      left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
                      left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
                      and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
                     left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
                     left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
                      
                where fil.latst_onbord_sts_cd  in ('CDM_Duplicate') and cast(fil.file_ref_id as varchar(100)) like '%3%'`,
        config
      );
})


it.only('TC04 - Partner Filter Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.filter_allcolumns(
        dup.filter_all["partner"],
        "Ar",
        `select count(*) as cnt
        from 
           cdm_core.file_onbord_instc fil
             inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
                    inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
              left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
              left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
              and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
             left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
             left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
              
        where fil.latst_onbord_sts_cd  in ('CDM_Duplicate') and org1.org_nm like '%Ar%'`,
        config
      );
})

it.only('TC05 - Dataset Filter Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.filter_allcolumns(
        dup.filter_all["dataset"],
        "-",
        `select count(*) as cnt
        from 
           cdm_core.file_onbord_instc fil
             inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
              left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
              inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
              left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
              and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
             left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
             left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
              
        where fil.latst_onbord_sts_cd  in ('CDM_Duplicate') and fil.dset_cd like '%-%' `,
        config
      );
})

it.only('TC06 - FileName Filter Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.filter_allcolumns(
        dup.filter_all["filename"],
        "CDM",
        `select count(*) as cnt
        from 
           cdm_core.file_onbord_instc fil
             inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
              left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
              inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
              left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
              and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
             left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
             left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
              
        where fil.latst_onbord_sts_cd  in ('CDM_Duplicate') and substr(fil.file_land_full_pth,length(fil.file_land_full_pth) - position('/' in reverse(fil.file_land_full_pth)) + 2,
        length(fil.file_land_full_pth)) like '%CDM%' `,
        config
      );
})


it.only('TC07 - Uploaded Date Filter Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.filter_allcolumns(
        dup.filter_all["uploaded_date"],
        "12",
        `select count(*) as cnt
        from 
           cdm_core.file_onbord_instc fil
             inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
              left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
              inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
              left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
              and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
             left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
             left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
              
        where fil.latst_onbord_sts_cd  in ('CDM_Duplicate') and to_char(fil.file_land_dtm at time zone 'UTC','Mon DD')||', ' 
        ||to_char(fil.file_land_dtm at time zone 'UTC','YYYY')||' '||to_char( fil.file_land_dtm at time zone 'UTC', 'HH12:MI PM' ) like '%12%' `,
        config
      );
})


it.only('TC08 - Uploaded by Filter Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.filter_allcolumns(
        dup.filter_all["uploaded_by"],
        "v",
        `select count(*) as cnt
        from 
           cdm_core.file_onbord_instc fil
             inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
              left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
              inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
              left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
              and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
             left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
             left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
              
        where fil.latst_onbord_sts_cd  in ('CDM_Duplicate') and usr.usr_nm like '%V%' `,
        config
      );
})

it.only('TC09 - Upload Mode Filter Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.filter_allcolumns(
        dup.filter_all["upload_mode"],
        "ff",
        `select count(*) as cnt
        from 
           cdm_core.file_onbord_instc fil
             inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
              left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
              inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
              left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
              and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
             left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
             left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
              
        where fil.latst_onbord_sts_cd  in ('CDM_Duplicate') and (case when us.use_case_type_cd ='OL' then 'Online' else 'Offline' end ) like '%ff%' `,
        config
      );
})


it.only('TC10 - Duplicate row Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.filter_allcolumns(
        dup.filter_all["duplicate_row_count"],
        "10",
        `select count(*) as cnt
        from 
           cdm_core.file_onbord_instc fil
             inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
              left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
              inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
              left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
              and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
             left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
             left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
              
        where fil.latst_onbord_sts_cd  in ('CDM_Duplicate') and (cast(sub.intrnl_fllt_rec_cnt as varchar(100)) like '%10%' or cast(sub.rec_cnt as varchar(100)) like '%10%') `,
        config
      );
})


it.only('TC11 - Validation Report Validation',()=>{
  dup.duplicate_tab_section_1()
    dup.filter_allcolumns(
        dup.filter_all["validation_report"],
        "19",
        `select count(*) as cnt
        from 
           cdm_core.file_onbord_instc fil
             inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
              left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
              inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
              left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
              and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
             left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
             left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
              
        where fil.latst_onbord_sts_cd  in ('CDM_Duplicate') and  case when (sub.intrnl_vld_rpt_full_pth is null or sub.intrnl_vld_rpt_full_pth ='') then 'NA' else substr(sub.intrnl_vld_rpt_full_pth,length(sub.intrnl_vld_rpt_full_pth) - position('/' in reverse(sub.intrnl_vld_rpt_full_pth)) + 2,
        length(sub.intrnl_vld_rpt_full_pth)) end like '%19%' `,
        config
      );
})

it.only('TC12 - Pagination',()=>{
  dup.duplicate_tab_section_1()
    dup.action_pagination()
})


it.only('TC13 - Grid Data Validation',()=>{
  dup.duplicate_tab_section_1()
  dup.griddata(`select 
  file_ref_id,partner,dataset,substr(File_name_1,0,position('.' in File_name_1)-20)||substr(File_name_1,position('.' in File_name_1),length(File_name_1)) as file_name,
  uploaded_date,uploaded_by,upload_mode,duplicate_row_count,validation_report from (
  
  SELECT fil.file_ref_id,
    org1.org_nm as Partner,
    fil.dset_cd as dataset,
  
    substr(fil.file_land_full_pth,length(fil.file_land_full_pth) - position('/' in reverse(fil.file_land_full_pth)) + 2,
                length(fil.file_land_full_pth)) as File_name_1,
  
    to_char(fil.file_land_dtm at time zone 'UTC','Mon DD')||', ' 
                ||to_char(fil.file_land_dtm at time zone 'UTC','YYYY')||' '||to_char( fil.file_land_dtm at time zone 'UTC', 'HH12:MI PM' ) as Uploaded_Date,
    usr.usr_nm as Uploaded_by,
    case when us.use_case_type_cd ='OL' then 'Online' else 'Offline' end as Upload_Mode,
    sub.intrnl_fllt_rec_cnt||' of '||fil.rec  as duplicate_row_count,
     case when (sub.intrnl_vld_rpt_full_pth is null or sub.intrnl_vld_rpt_full_pth ='') then 'NA' 
     when sub.intrnl_vld_rpt_full_pth='path' then 'path'
     else substr(sub.intrnl_vld_rpt_full_pth,length(sub.intrnl_vld_rpt_full_pth) - position('/' in reverse(sub.intrnl_vld_rpt_full_pth)) + 2,
                length(sub.intrnl_vld_rpt_full_pth)) end as Validation_Report      
    from 
       cdm_core.file_onbord_instc fil
         inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
                inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
          left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
          left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
          and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
         left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
         left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
          
    where fil.latst_onbord_sts_cd  in ('CDM_Duplicate')
    order by fil.chg_dtm desc
  )a`,config)
})


it.only('TC14 - Sorting the Uploaded Date in Ascending order',()=>{
  dup.duplicate_tab_section_1()
  dup.sorting(config,`
  select substr(File_name_1,0,position('.' in File_name_1)-20)||substr(File_name_1,position('.' in File_name_1),length(File_name_1)) as file_name from (
  select substr(a.file_land_full_pth,length(a.file_land_full_pth) - position('/' in reverse(a.file_land_full_pth)) + 2, length(a.file_land_full_pth)) as File_name_1
  from cdm_core.file_onbord_instc a where a.latst_onbord_sts_cd in ('CDM_Duplicate') and a.file_land_dtm >= (now() - interval '12 month') order by a.file_land_dtm asc
  )a`,'ascending')
})


it.only('TC15 - Sorting the Uploaded Date in Descending order',()=>{
  dup.duplicate_tab_section_1()
  dup.sorting(config,`
  select substr(File_name_1,0,position('.' in File_name_1)-20)||substr(File_name_1,position('.' in File_name_1),length(File_name_1)) as file_name from (
  select substr(a.file_land_full_pth,length(a.file_land_full_pth) - position('/' in reverse(a.file_land_full_pth)) + 2, length(a.file_land_full_pth)) as File_name_1
  from cdm_core.file_onbord_instc a where a.latst_onbord_sts_cd in ('CDM_Duplicate') and a.file_land_dtm >= (now() - interval '12 month') order by a.file_land_dtm desc
  )a`,'descending')
})


it.only('TC16 - Validation Report Hyperlink Valdiation',()=>{
  dup.duplicate_tab_section_1()
  dup.validation_report("./cypress/downloads")
})

it.only('TC17 - Report Icon Validation',()=>{
  dup.duplicate_tab_section_1()
  dup.report_icon()
})

it.only('TC18 - Reject',()=>{
  dup.duplicate_tab_section_1()
  dup.reject(config)
})


it.only('TC19 - Accept',()=>{
  dup.duplicate_tab_section_1()
  dup.accept(config)
})




it.only("Changing th role to WW Program Manager", () => {
  dup.role_change(config,'1');
  dup.launching_consumer_data()
  cy.wait(20000)
});

it.only("Going to Duplicate tab",{}, () => {
      dup.duplicate_tab_section_1()
      cy.wait(5000)
    });



it.only('TC20 - WW Program Manger - Checking all data is loaded',()=>{
  dup.data_count(config)
})

it.only('TC21 - WW Program Manger - Checking all buttons are visible',()=>{
  dup.buttons_visible()
})



it.only("Changing th role to Account Manager", () => {
  dup.role_change(config,'2');
  dup.launching_consumer_data()
  cy.wait(20000)
});

it.only("Going to Duplicate section",{}, () => {
      dup.duplicate_tab_section()
      cy.wait(5000)
    });



it.only('TC22 - Account Manger - Checking only org data is loaded',()=>{
  dup.grid_count_org(config)
})

it.only('TC23 - Account Manager - Checking all buttons are visible',()=>{
  dup.buttons_visible()
})



it.only("Changing th role to Intel bizops", () => {
  dup.role_change(config,'3');
  dup.launching_consumer_data()
  cy.wait(20000)
});

it.only("Going to Duplicate section",{}, () => {
      dup.duplicate_tab_section_1()
      cy.wait(5000)
    });



it.only('TC24 - Intel bizops - Checking all data is loaded',()=>{
  dup.data_count(config)
})

it.only('TC25 - Intel bizops - Checking all buttons are visible',()=>{
  dup.buttons_visible()
})



it.only("Changing th role to Third party Data submitter", () => {
  dup.role_change(config,'5');
  dup.launching_consumer_data()
  cy.wait(20000)
});

it.only("Going to Duplicate section",{}, () => {
      dup.duplicate_tab_section()
      cy.wait(5000)
    });



it.only('TC26 - Third party Data submitter - Checking org data is loaded',()=>{
  dup.grid_count_org(config)
})

it.only('TC27 - Third party Data submitter - Checking no buttons are visible',()=>{
  dup.buttons_not_visible()
})




it.only("Changing th role to Partner Data submitter", () => {
  dup.role_change(config,'6');
  dup.launching_consumer_data()
  cy.wait(20000)
});

it.only("Going to Duplicate section",{}, () => {
      dup.duplicate_tab_section()
      cy.wait(5000)
    });



it.only('TC28 - Partner Data submitter - Checking org data is loaded',()=>{
  dup.grid_count_org(config)
})

it.only('TC29 - Partner Data submitter - Checking no buttons are visible',()=>{
  dup.buttons_not_visible()
})

})
