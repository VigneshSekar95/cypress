// ************************ New Template Creation ***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the New Template Creation
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking whether the user can able to add new platform, program area, subject area, dataset by clicking the (+) icon
// 2.Checking whether the select the newly created values from the dropdown
// 3.Verify whether the user can able to add new fields for the new template that is being created
// 4.Verifying the error messages when adding fields for the template
// 5.Creaate new switch
// 6.Create a new template
// 7.Checking the error message in case the user is trying to create a existing template

let envi = Cypress.env('ENV')
import config_new_temp from "../functions/new_temp";
let excel_data = require("../fixtures/output.json");
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';



describe("New_Template_Creation", function () {
  before(() => {
    cy.viewport(1400, 1000);
  });

  beforeEach(() => {
    cy.viewport(1400, 1000);
  });

  afterEach(function () {
    

     if(this.currentTest.title == 'TC30 - Template Duplication'){
      config_new_temp.deleting_dummy_entries_delim_templt_fld_def(config)
      config_new_temp.deleting_dummy_entries_templt_switc(config)
      config_new_temp.deleting_dummy_entries_tmplt(config)
      config_new_temp.deleting_dummy_entries_dset_lkup(config)
      config_new_temp.deleting_dummy_entries_tier2_3_hier(config)
      config_new_temp.deleting_dummy_entries_class_hier_lkup_tier2(config)
      config_new_temp.deleting_dummy_entries_class_hier_lkup_tier3(config)
      config_new_temp.deleting_dummy_entries_pltfrm_lkup(config)
     }


     if(this.currentTest.title == 'TC28 - Add a new switch and selecting it from the dropdown'){
      config_new_temp.deleting_dummy_switch_entries(config)
     }
   if(this.currentTest.state === 'failed'){
    cy.reload()
    cy.wait(5000)
   }
  
  });
  

  it.only('Launching Consumer Data',()=>{

    dup.launching_consumer_data()
     cy.wait(10000)
   })

   
it.only("Changing th role to Intel bizops", () => {
 dup.role_change(config,'3');
 dup.launching_consumer_data()
});

  it.only("TC01 - Checking the Title and Description",  {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  }, ()=> {
    cy.wait(3000)
    config_new_temp.config_page('Configuration', 'Configure Tables');
    config_new_temp.checking_heading_subheading();
  });

  it.only("TC02 - Checking the Dropdown Header", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  }, ()=> {
    cy.wait(3000)
    config_new_temp.checking_dropdown_header([
      "Platform*:",
      "Program/Subject Area*:",
      "Process Area*:",
      "Dataset*:",
    ]);
  });



  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Platform"
    ) {
      it.only("TC03 - Add a New Platform and checking for uniqueness",{
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        cy.wait(3000)
        config_new_temp.add_new_platform(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Other'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Platform"
    ) {
      it.only("TC04 - Check for the use of allowed characters for Platform", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.add_new_platform(
          'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Ae',
          'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec.',
          'Other'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Platform"
    ) {
      it.only("TC05-Checking the New Platform is created in Backend tables", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        cy.wait(3000)
        config_new_temp.check_platform_backend(excel_data[i].Input_Parameter_Value_1,config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Platform"
    ) {
      it.only("TC06-Checking the New Platform is created in Backend tables with allowed character", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.check_platform_backend_character_exceeding('Lorem ipsum dolor sit amet, consectetuer adipis','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium qu',config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Subject Area"
    ) {
      it.only("TC07- Add a New Subject Area and Selecting it from Dropdown  and checking for uniqueness", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.add_subject_area(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Other'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Subject Area"
    ) {
      it.only("TC08- Enter more than allowed character and check that only allowed character is used", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.add_subject_area(
          'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Ae',
          'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec.',
          'Other'
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Subject Area"
    ) {
      it.only("TC09 - Checking the New Subject Area is created in Backend tables", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.check_subject_backend(excel_data[i].Input_Parameter_Value_1,config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Subject Area"
    ) {
      it.only("TC10-Checking the New Subject Area is created in Backend tables  with allowed character", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.check_subject_backend_character_exceeding('Lorem ipsum dolor sit amet, consectetuer adipis','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium qu',config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Process"
    ) {
      it.only("TC11 - Add a New Process  and Selecting it from Dropdown  and checking for uniqueness", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.add_process_area(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          'Other'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Process"
    ) {
      it.skip("TC12 - Enter more than allowed character and check that skip allowed character is used", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.add_process_area(
          'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Ae',
          'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec.',
          'Other'
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Process"
    ) {
      it.only("TC13 - Checking the New Process is created in Backend tables", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.check_subject_backend(excel_data[i].Input_Parameter_Value_1,config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Process"
    ) {
      it.skip("TC14-Checking the New process is created in Backend tables  with allowed character", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.check_subject_backend_character_exceeding('Lorem ipsum dolor sit amet, consectetuer adipis','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium qu',config);
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Dataset"
    ) {
      it.only("TC15 - Add a New Dataset  and Selecting it from Dropdown  and checking for uniqueness", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.add_dataset(
          excel_data[i].Input_Parameter_Value_1,
          excel_data[i].Input_Parameter_Value_2,
          excel_data[i].Input_Parameter_Value_3,
          excel_data[i].Input_Parameter_Value_4,
          excel_data[i].Input_Parameter_Value_5,
          'Other'
        );
      });
    }
  }

  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Dataset"
    ) {
      it.only("TC16 - Enter more than allowed character and check that skip allowed character is used", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.add_dataset(
          'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Ae',
          'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec.',
          excel_data[i].Input_Parameter_Value_3,
          excel_data[i].Input_Parameter_Value_4,
          excel_data[i].Input_Parameter_Value_5,'Other'
        );
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Dataset"
    ) {
      it.only("TC17 - Checking the New Dataset is created in Backend tables", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.check_dataset_backend(excel_data[i].Input_Parameter_Value_1,config);
      });
    }
  }


  for (let i = 0; i < excel_data.length; i++) {
    if (
      excel_data[i].Run == "Y" &&
      excel_data[i].Test_Suite_name == "New_Template_Creation" &&
      excel_data[i].Test_Case_Name == "Add a New Dataset"
    ) {
      it.only("TC18 - Checking the New dataset is created in Backend tables  with allowed character", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.check_dataset_backend_character_exceeding('Lorem ipsum dolor sit amet, consectetuer adipis','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium qu',config);
      });
    }
  }



  it.only("TC31 - Checking Template Version Input box", {
    retries: {
      runMode: 2,
      openMode: 2,
    },
  }, ()=> {
    config_new_temp.config_page('Configuration', 'Configure Tables')
    config_new_temp.template_version_check()
    
   
  })





 


  
      it.only("TC19 - Create_Field_Addition_template - Empty Record", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.empty()
        
       
      })


      it.only("TC20 - Create_Field_Addition_template - Blank and Space Record", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.blank_spaces()
        
       
      })


      it.only("TC21 - Create_Field_Addition_template - Above Max allowed limit", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.max_allowed_limit()
        
       
      })

      it.only("TC22 - Create_Field_Addition_template - start date < end date", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.startdate_less_than_end_date()
        
       
      })


      it.only("TC23 - Create_Field_Addition_template - Blank Start date", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.blank_start_date()
        
       
      })

      it.only("TC24 - Create_Field_Addition_template - Entering Blank End Date", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.blank_end_date()
        
       
      })


      it.only("TC25 - Create_Field_Addition_template - Duplicate entry", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.duplicate_entry()
        
       
      })

      
      it.only("TC26 - Create_Field_Addition_template - Special Character", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.special_character()
        
       
      })




      it.only("TC27 - Create_Field_Addition_template - Delete button", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.Delete_button()
        
       
      })


      it.only("TC28 - Add a new switch and selecting it from the dropdown", {
        retries: {
          runMode: 2,
          openMode: 2,
        },
      }, ()=> {
        config_new_temp.config_page('Configuration', 'Configure Tables')
        config_new_temp.add_switch()
        
       
      })


      for (let i = 0; i < excel_data.length; i++) {
        if (
          excel_data[i].Run == "Y" &&
          excel_data[i].Test_Suite_name == "New_Template_Creation" &&
          excel_data[i].Test_Case_Name == "Create_Field_Addition_Template"
        ) {
          it.only("TC29 - Create_Field_Addition_template", {
            retries: {
              runMode: 2,
              openMode: 2,
            },
          }, ()=> {
            config_new_temp.config_page('Configuration', 'Configure Tables')
            config_new_temp.create_Field_Addition_template(excel_data[i].Input_Parameter_Value_1,excel_data[i].Input_Parameter_Value_2,excel_data[i].Input_Parameter_Value_3,excel_data[i].Input_Parameter_Value_4,config,'Desktop');
            config_new_temp.checking_tier2_3_tables(config)
            config_new_temp.checking_tmplt_switch(config)
            config_new_temp.checking_tmplt_table(config)
            config_new_temp.checking_delim_templt_fld_def(excel_data[i].Input_Parameter_Value_1,excel_data[i].Input_Parameter_Value_2,excel_data[i].Input_Parameter_Value_3,excel_data[i].Input_Parameter_Value_4,config)
          });
        }
      }


      for (let i = 0; i < excel_data.length; i++) {
        if (
          excel_data[i].Run == "Y" &&
          excel_data[i].Test_Suite_name == "New_Template_Creation" &&
          excel_data[i].Test_Case_Name == "Create_Field_Addition_Template"
        ) {
          it.only("TC30 - Template Duplication", {
            retries: {
              runMode: 2,
              openMode: 2,
            },
          }, ()=> {
            config_new_temp.config_page('Configuration', 'Configure Tables')
            config_new_temp.create_Field_Addition_template(excel_data[i].Input_Parameter_Value_1,excel_data[i].Input_Parameter_Value_2,excel_data[i].Input_Parameter_Value_3,excel_data[i].Input_Parameter_Value_4,config,'desktop','Duplicate');
          });
        }
      }


























});

