// ************************ Modify Template by Partner Screen ***********************************
// Created by Vignesh Sekar
// 
// This file contains all the functions used for testing the Modify Template by Partner screen
// 
//
//
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking the dropdown values of all the dropdowns in the Choose Partner and Template section
// 2.Checking the prepopulation of values in the Choose Partner and related Attributes , Override Template Field Names, Modify/Add Template Switch section
// 3.Checking the input boxes of Retention and Others section
// 4.Modifying the template value based on template version and checking whether the edited values is updated
// 5.Checking the error messages in case if we add Retention and Restatement values above the allowed max limit
// 6.Inactivate and Activate a Template for a particular template version


import tmpltprt from '../functions/modify_template_by_partner'
let envi = Cypress.env('ENV')
const { encrypt, decrypt } = require('./crypto');
const env_var = require('../support/environment')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));
import dup from '../functions/duplicate';

describe("Modify Template by Partner", function () {
  beforeEach(() => {
    cy.viewport(1400, 1000);
  });

  afterEach(function () {
    if(this.currentTest.title === 'TC20 - Checking the edited the values in all three sections'){
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `update 
        cdm_core.org_allw_templt 
        Set restate_allw_day=20, reten_befr_archv=20, reten_befr_prg=20, elig_for_wf_area_ind='Y', file_splt_thrhld_dnmntr_rtio=20, org_templt_pri=1
        where org_templt_id =(
        select t.org_templt_id 
        from  cdm_core.org_allw_templt t
       inner join cdm_accs_enttl.org o on t.org_id = o.org_id 
       inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd
       inner join cdm_core.org_allw_templt_ingest_mode i on i.dset_cd = t.dset_cd and i.tier2_3_hier_id = t.tier2_3_hier_id and i.org_id=t.org_id and i.pltfrm_cd = t.pltfrm_cd and i.templt_ver_nbr = t.templt_ver_nbr
       where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and tm.templt_ver_nm='Tablet')
        `
      }).then((result) => {
        
      })

      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `update cdm_core.org_allw_templt_ingest_mode  Set data_ingest_mode_cd='FTP' where org_allw_templt_ingest_mode_id = (
          Select org_allw_templt_ingest_mode_id 
          from cdm_core.org_allw_templt_ingest_mode i
          inner join cdm_core.org_allw_templt t on i.dset_cd = t.dset_cd and i.tier2_3_hier_id = t.tier2_3_hier_id and i.org_id=t.org_id and i.pltfrm_cd = t.pltfrm_cd and i.templt_ver_nbr = t.templt_ver_nbr
         inner join cdm_accs_enttl.org o on t.org_id = o.org_id 
         inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd
         where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and tm.templt_ver_nm='Tablet')
        `
      }).then((result) => {
        
      })


      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `update cdm_core.org_delim_templt_fld_ovrrd set new_fld_nm='Override_Field1' where org_templt_ovrrd_fld_id =(
          Select fld.org_templt_ovrrd_fld_id from cdm_core.org_allw_templt t
          inner join cdm_accs_enttl.org o on t.org_id = o.org_id
          inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd
          inner join cdm_core.org_delim_templt_fld_ovrrd fld on fld.dset_cd = t.dset_cd and fld.tier2_3_hier_id = t.tier2_3_hier_id and  fld.pltfrm_cd = t.pltfrm_cd 
          and fld.templt_ver_nbr = t.templt_ver_nbr and fld.org_id=t.org_id
          where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and tm.templt_ver_nm='Tablet'
          )`
      }).then((result) => {
        
      })


      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `update cdm_core.org_allw_templt_switc set switc_val='Y' where org_templt_switc_id =(
          Select sw.org_templt_switc_id from cdm_core.org_allw_templt t
          inner join cdm_accs_enttl.org o on t.org_id = o.org_id
          inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd
          inner join cdm_core.org_allw_templt_switc sw on t.org_templt_id = sw.org_templt_id
          where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and tm.templt_ver_nm='Tablet')`
      }).then((result) => {
        
      })


     }

     if(this.currentTest.title === 'TC23 - Checking the Added Override Field and Switch'){
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `Delete from cdm_core.org_delim_templt_fld_ovrrd where org_templt_ovrrd_fld_id in (
          Select fld.org_templt_ovrrd_fld_id from cdm_core.org_allw_templt t
          inner join cdm_accs_enttl.org o on t.org_id = o.org_id
          inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd
          inner join cdm_core.org_delim_templt_fld_ovrrd fld on fld.dset_cd = t.dset_cd and fld.tier2_3_hier_id = t.tier2_3_hier_id and  fld.pltfrm_cd = t.pltfrm_cd 
          and fld.templt_ver_nbr = t.templt_ver_nbr and fld.org_id=t.org_id
          where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and tm.templt_ver_nm='Desktop')`
      }).then((result) => {
        
      })

      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `Delete from  cdm_core.org_allw_templt_switc  where org_templt_switc_id  in (
          Select sw.org_templt_switc_id from cdm_core.org_allw_templt t
          inner join cdm_accs_enttl.org o on t.org_id = o.org_id
          inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd
          inner join cdm_core.org_allw_templt_switc sw on t.org_templt_id = sw.org_templt_id
          where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and tm.templt_ver_nm='Desktop')`
      }).then((result) => {
        
      })

      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `Delete from cdm_core.switc_lkup where switc_cd='Partner_Switch_1'`
      }).then((result) => {
        
      })


     }

     if(this.currentTest.state === 'failed'){
      cy.reload()
      cy.wait(10000)
      
     }
  })

 


  it.only('Launching Consumer Data',()=>{

    dup.launching_consumer_data()
     cy.wait(10000)
   })

   
it.only("Changing th role to Intel bizops", () => {
 dup.role_change(config,'3');
 dup.launching_consumer_data()
});

  it.only('TC01 - Going to Modify Template by partner',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.modify_template_partner_page()
  })


  it.only('TC02 - Page Title and Description',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.title_and_description()
  })

  it.only('TC03 - Partner Dropdown Validation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.partner_dropdown_selection(config)
  })


  it.only('TC04 - Platform Dropdown Validation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.platform_dropdown_selection(config)
  })


  it.only('TC05 - Subject Area Dropdown Validation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.subject_area_dropdown_selection(config)
  })


  it.only('TC06 - Process Area Dropdown Validation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.process_area_dropdown_selection(config)
  })


  it.only('TC07 - Dataset Dropdown Validation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.dataset_dropdown_selection(config)
  })

  it.only('TC08 - Version Dropdown Validation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.version_dropdown_selection(config)
  })


  it.only('TC09 - Choose Partner Prepopulation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.choose_partner_prepopulation(config)
  })


  it.only('TC10 - Override Fields Prepopulation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.Override_Fields_prepopulation(config)
  })


  it.only('TC11 - Switch Prepopulation',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.switch_prepopulation(config)
  })


  it.only('TC12 - Checking retention before archival',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.retention_before_archival(config)
  })


  it.only('TC13 - Checking retention before purge',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.retention_before_purge(config)
  })


  it.only('TC14 - Checking Restatement allowed days',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.restatement_allowed_days(config)
  })


  it.only('TC15 - Checking Collab Ind',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.collab_indicator(config)
  })


  it.only('TC16 - Checking File Split Ratio',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.file_split_ratio(config)
  })


  it.only('TC17 - Checking org_tmplt_priority',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.org_tmplt_priority(config)
  })



  it.only('TC18 - Checking Max Allowed character override field name',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.greater_override_field(config)
  })



  it.only('TC19 - Editing the values in all three sections',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.editing_values(config)
  })


  it.only('TC20 - Checking the edited the values in all three sections',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.checking_editing_values(config)
  })


  it.only('TC21 - Adding new Override Fields',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.adding_new_override_field()
  })


  it.only('TC22 - Adding new Switch',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.adding_new_switch()
  })


  it.only('TC23 - Checking the Added Override Field and Switch',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.Checking_new_override_fields_switch()
  })


  it.only('TC24 - Greater Integer_Value Retention Archival',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.greater_interger_Value('Arch')
  })


  it.only('TC25 - Greater Integer_Value Retention Purge',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.greater_interger_Value('Purge')
  })


  it.only('TC26 - Greater Integer_Value Restatement Days',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.greater_interger_Value('Days')
  })


  it.only('TC27 - Greater Numeric Value File Split Ratio',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.greater_numeric_Value()
  })


  it.only('TC28 - Inactivate Template for a Particular Partner',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.Inactivate_Template()
  })

  it.only('TC29 - Checking whether Other versions are activated',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.Activate_other_Template()
  })


  it.only('TC30 - Template is activated for other partners',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.Activate_other_partner()
  })





  it.only('TC31 - Activate Template for a Particular Partner',{
    retries: {
      runMode: 2,
      openMode: 2,
    },
  },()=>{
        tmpltprt.Activate_Template()
  })















  




});



