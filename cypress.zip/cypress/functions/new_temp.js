
class confignewtemp{


    get configuration_button() {
      return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/a[1]')
      }

    get operations_button(){
        return cy.get('.mt-4>div>div>div:nth-of-type(2)>input')
    }

    get operations_button_label(){
        return cy.get('.mt-4>div>div>div:nth-of-type(2)>label')
    }

    get new_template_button(){
        return cy.get('.main-content>main>div>div:nth-of-type(2)>div:nth-of-type(1)>div>div:nth-of-type(3)>button')
    }

    get heading(){
        return cy.get('.main-content>main>div>h2')
    }

    get sub_heading(){
        return cy.get('.main-content>main>div>div:nth-of-type(1)')
    }

    get new_platform_button(){
        return cy.get('.main-content>main>div>div:nth-of-type(2)>div:nth-of-type(2)>p>div:nth-of-type(2)>div>div>button')
    }

    get subject_area_button(){
        return cy.get('.main-content>main>div>div:nth-of-type(2)>div:nth-of-type(2)>p>div:nth-of-type(4)>div>div>button')
    }

    get process_button(){
        return cy.get('.main-content>main>div>div:nth-of-type(2)>div:nth-of-type(2)>p>div:nth-of-type(6)>div>div>button')
    }

    get dataset_button(){
        return cy.get('.main-content>main>div>div:nth-of-type(2)>div:nth-of-type(2)>p>div:nth-of-type(8)>div>div>button')
    }

    get modal_title(){
        return cy.get('.modal-title')
    }

    get btn_close(){
        return cy.get('.btn-close')
    }

    get cancel_button(){
        return cy.get('.modal-footer>button:nth-of-type(1)')
    }

    get add_button(){
        return cy.get('.modal-footer>button:nth-of-type(2)')
    }


    get modal_body_label_1(){
        return cy.get('.mb-3:nth-of-type(1)>label')
    }

    get modal_body_label_2(){
        return cy.get('.mb-3:nth-of-type(2)>label')
    }

    get dataset_modal_body_2(){
        return cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(1)')
    }

    get dataset_modal_body_3(){
        return cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(2)')
    }

    get dataset_modal_body_4(){
        return cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(3)')
    }

    get dataset_modal_body_5(){
        return cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(4)')
    }
    


    get modal_body_input_1(){
        return cy.get('.mb-3:nth-of-type(1)>input')
    }

    get dataset_input_2(){
        return cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(1)')
    }

    get dataset_input_3(){
        return cy.get('.modal-body>div:nth-of-type(2)>select:nth-of-type(1)')
    }

    get dataset_input_4(){
        return cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(2)')
    }

    get dataset_input_5(){
        return cy.get('.modal-body>div:nth-of-type(2)>select:nth-of-type(2)')
    }

    get modal_body_input_2(){
        return cy.get('.mb-3:nth-of-type(2)>input')
    }

    get platfrom_dropdown(){
        return cy.xpath('//*[@id="platform"]')
    }

    get subject_area_dropdown(){
        return cy.xpath('//*[@id="tier2Name"]')
    }

    get process_area_dropdown(){
        return cy.xpath('//*[@id="tier3Name"]')
    }

    get dataset_dropdown(){
        return cy.xpath('//*[@id="dataset"]')
    }

    get template_version(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[9]/div/input')
    }

    get error_message(){
        return cy.get('.invalid-feedback')
    }

    get jsonSchema(){
        return cy.get('textarea[name=jsonSchema]')
    }

    get xmlSchema(){
        return cy.get('textarea[name=xmlSchema]')
    }



    get fieldName(){
        return  cy.get('input[name=fieldName]')
    }

    get startDate(){
        return cy.get('input[name=startDate]')
    }

    get endDate(){
       return  cy.get('input[name=endDate]')
    }

    get mandatory(){
        return cy.get('select[name=mandatory]')
    }

    get field_add_button(){
        return cy.get('.ag-cell .btn-primary')
    }

    get create_template_button(){
        return cy.get('.mt-3.btn-group>button:nth-of-type(2)')
    }

    get error_message_template(){
        return cy.get('.main-content>main>div>div:nth-of-type(3)>div:nth-of-type(2)>p>p')
    }

    get delete_button_1(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/div/form/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[2]/div[6]/i')
    }


    get delete_button_2(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/div/form/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[3]/div[6]/i')
    }


    get delete_button_3(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/div/form/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[4]/div[6]/i')
    }

    get grid_data(){
      return cy.get('.ag-root-wrapper')
    }

    get new_switch_button(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[2]/p/div/div[1]/div/div/button/i')

                      
    }

    get add_another_switch(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[1]/button')
    }

    get switch_dropdown_1(){
      return cy.xpath('//*[@id="switchCode0"]')
    }

    get switch_value_1(){
      return cy.xpath('//*[@id="switchValue"]')
    }

    get switch_dropdown_2(){
      return cy.xpath('//*[@id="switchCode1"]')
    }


    get switch_value_2(){
      return cy.xpath('//*[@id="switchValue"]')
    }


    get new_switch_button_after(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[5]/div[2]/p/div/div[1]/div/div/button/i')
                      
    }

    get add_another_switch_after(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[5]/div[1]/button')
                      
    }

   

    get template_version(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[9]/div/input')
    }

    get success_message(){
      return cy.xpath('/html/body/div[6]/div/div/div[2]/p')
    }

    get ok_button(){
      return cy.xpath('/html/body/div[6]/div/div/div[3]/button')
    }


    testing_graphql(){
      cy.request({method: 'POST',
    url: 'https://login.microsoftonline.com/46c98d88-e344-4ed4-8496-4ed7712e255d/oauth2/token', // baseUrl is prepend to URL
    form: true, // indicates the body should be form urlencoded and sets Content-Type: application/x-www-form-urlencoded headers
    body: {
        client_id: "c6c423fb-935a-4eba-8032-9af931e8d21f",
        client_secret: "daW8Q~UDTUDMITt2VuOCG~QIIyo2AYzwqZdUecjO",
        grant_type: "client_credentials",
        scope:'c6c423fb-935a-4eba-8032-9af931e8d21f/.default',
        resource:"00000002-0000-0000-c000-000000000000"
       
    },
  }).then(
  (response) => {
   
    console.log(decode(response.body.access_token))

    cy.request({method: 'POST',
    url: 'http://127.0.0.1:8000', // baseUrl is prepend to URL
   // form: true, // indicates the body should be form urlencoded and sets Content-Type: application/x-www-form-urlencoded headers
    //json:true,
    body: json_body,
      
       
    
    // headers:{
    // Authorization:`Bearer `+response.body.access_token}
  }).then((out)=>{
      console.log(out)
     // expect(out.body.data.cdm_core_file_onbord_instc.length).to.eq(18)
  })

  

  })
    }





    config_page(title,button){
        cy.on("uncaught:exception", (err, runnable) => {
          return false;
        });
          this.configuration_button.should('have.text',title)
          this.configuration_button.click()
          this.operations_button_label.should('have.text','Operations')
          cy.wait(1000)
          this.operations_button.click()
          cy.wait(1000)
          this.new_template_button.should('have.text','Create new Template')
          this.new_template_button.click()
          
      }


      checking_heading_subheading(){
       /// cy.wait(1000)
        this.heading.should('have.text','Create New Template')
        this.sub_heading.should('have.text','Create a new template for uploading files.')

      }


      checking_dropdown_header(text){
        let j=0;
        for (let i=2;i<10;i++){
            cy.get('.main-content>main>div>div:nth-of-type(2)>div:nth-of-type(2)>p>div:nth-of-type('+i+')>label').should('have.text',text[j])
            j++;
            i++;
        }
  }


  add_new_platform(code,desc,type){
    this.new_platform_button.click()
    this.btn_close.click()
    this.new_platform_button.click()
    this.cancel_button.click()
    this.new_platform_button.click()
    this.add_button.should('be.disabled')
    this.modal_title.should('have.text','Add a new Platform')
    this.modal_body_label_1.should('have.text','Platform Name:')
    this.modal_body_label_2.should('have.text','Platform Description:')
    this.modal_body_input_1.clear()
    //cy.wait(2000)
    this.modal_body_input_1.type('   '+code+'   ')
    this.modal_body_input_2.clear()
    this.modal_body_input_2.type('   '+desc+'   ')
    this.add_button.click()
    cy.wait(2000)
    this.platfrom_dropdown.select(code.substring(0,47))
    if(type=='Other'){
    //this.reload()
    this.new_platform_button.click()
    this.modal_body_input_1.clear()
    this.modal_body_input_1.type('   '+code+'   ')
    this.modal_body_input_2.clear()
    this.modal_body_input_2.type('   '+desc+'   ')
    this.add_button.click()
    this.error_message.should('have.text','Uniqueness violation. Please try with a different value')
    this.cancel_button.click()
    }
    cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });

  }




  add_subject_area(code,desc,type){
    this.subject_area_button.click()
    this.btn_close.click()
    this.subject_area_button.click()
    this.cancel_button.click()
    this.subject_area_button.click()
    this.add_button.should('be.disabled')
    this.modal_title.should('have.text','Add a new Program/Subject Area')
    this.modal_body_label_1.should('have.text','Program/Subject Area Name:')
    this.modal_body_label_2.should('have.text','Program/Subject Area Description:')
    this.modal_body_input_1.clear()
    //cy.wait(2000)
    this.modal_body_input_1.type('   '+code+'   ')
    this.modal_body_input_2.clear()
    this.modal_body_input_2.type('   '+desc+'   ')
    this.add_button.click()
    cy.wait(2000)
   this.subject_area_dropdown.select(code.substring(0,47))
    if(type=='Other'){
    //this.reload()
    this.subject_area_button.click()
    this.modal_body_input_1.clear()
    this.modal_body_input_1.type('   '+code+'   ')
    this.modal_body_input_2.clear()
    this.modal_body_input_2.type('   '+desc+'   ')
    this.add_button.click()
    this.error_message.should('have.text','Uniqueness violation. Please try with a different value')
    this.cancel_button.click()
    }
    cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });


  }


  add_process_area(code,desc,type){
    this.process_button.click()
    this.btn_close.click()
    this.process_button.click()
    this.cancel_button.click()
    this.process_button.click()
    this.add_button.should('be.disabled')
    this.modal_title.should('have.text','Add a new Process Area')
    this.modal_body_label_1.should('have.text','Process Area Name:')
    this.modal_body_label_2.should('have.text','Process Area Description:')
    this.modal_body_input_1.clear()
   // cy.wait(2000)
    this.modal_body_input_1.type('   '+code+'   ')
    this.modal_body_input_2.clear()
    this.modal_body_input_2.type('   '+desc+'   ')
    this.add_button.click()
    cy.wait(2000)
    this.process_area_dropdown.select(code.substring(0,47))
    cy.wait(2000)
    if(type=='Other'){
    //this.reload()
    this.process_button.click()
    this.modal_body_input_1.clear()
    this.modal_body_input_1.type('   '+code+'   ')
    this.modal_body_input_2.clear()
    this.modal_body_input_2.type('   '+desc+'   ')
    this.add_button.click()
    this.error_message.should('have.text','Uniqueness violation. Please try with a different value')
    this.cancel_button.click()
    }
    cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });

  }

  add_dataset(code,desc,type,delim,header,method){
    cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });
    this.dataset_button.click()
    this.btn_close.click()
    this.dataset_button.click()
    this.cancel_button.click()
    this.dataset_button.click()
    this.add_button.should('be.disabled')
    this.modal_title.should('have.text','Add a new Dataset')
    this.modal_body_label_1.should('have.text','Dataset Name:')
    this.dataset_modal_body_2.should('have.text','Dataset Description:')
    this.dataset_modal_body_3.should('have.text','File Type:')
    this.dataset_modal_body_4.should('have.text','File Delimiter:')
    this.dataset_modal_body_5.should('have.text','Header Indicator:')
    this.modal_body_input_1.clear()
    //cy.wait(2000)
    this.modal_body_input_1.type('   '+code+'   ')
    this.dataset_input_2.clear()
    this.dataset_input_2.type('   '+desc+'   ')
    this.dataset_input_3.select(type)
    this.dataset_input_4.clear()
    this.dataset_input_4.type(delim)
    this.dataset_input_5.select(header)
     this.add_button.click()
     cy.wait(2000)
     this.dataset_dropdown.select(code.substring(0,47))
     if(method=='Other'){
    //  this.reload()
     this.dataset_button.click()
     this.modal_body_input_1.clear()
     //cy.wait(2000)
     this.modal_body_input_1.type('   '+code+'   ')
     this.dataset_input_2.clear()
     this.dataset_input_2.type('   '+desc+'   ')
     this.dataset_input_3.select(type)
     this.dataset_input_4.clear()
     this.dataset_input_4.type(delim)
     this.dataset_input_5.select(header)
      this.add_button.click()
    this.error_message.should('have.text','Uniqueness violation. Please try with a different value')
    this.cancel_button.click()
     }
    // cy.on("uncaught:exception", (err, runnable) => {
    //     return false;
    //   });

  }


  create_Field_Addition_template(fieldName,eff_start_date,eff_end_date,mandatory,config,version,type){
    this.create_template_button.should('be.disabled')
    // var date = new Date();
    // var year = date.getFullYear();
    // var month = String(date.getMonth()+1).padStart(2,'0');
    // var todayDate = String(date.getDate()).padStart(2,'0')
    // var datePattern = year +'-'+month+'-'+todayDate
   
    if(type!='Duplicate'){
      this.add_new_platform('Vignesh_Random_name_1','psodjiof','Template')
      this.add_subject_area('Vignesh_Random_name_Tier2','sdfsdfsdfsdf','Template')
      this.add_process_area('Vignesh_Random_name_Tier3','sdfsdf','Template')
    this.add_dataset('Vignesh_Random_name_dataset','sdfsdf','Delimited',',','Y','Template')
    }

  // cy.reload()
  // cy.wait(5000)
    this.platfrom_dropdown.select('Vignesh_Random_name_1')
   this.subject_area_dropdown.select('Vignesh_Random_name_Tier2')
  this.process_area_dropdown.select('Vignesh_Random_name_Tier3')
   this.dataset_dropdown.select('Vignesh_Random_name_dataset')
   this.template_version.type(version)
  
   cy.wait(1000)

    for(let i=0;i<fieldName.split('|').length;i++){
        console.log(fieldName.split('|')[i])
        this.fieldName.clear()
        this.fieldName.type('   '+fieldName.split('|')[i]+'   ') 
        this.startDate.type(eff_start_date.split('|')[i])
       this.endDate.type(eff_end_date.split('|')[i])
       this.mandatory.select(mandatory.split('|')[i])
        this.field_add_button.click()

    }


    this.create_template_button.should('be.enabled')
    if(type!='Duplicate'){
      this.new_switch_button_after.click()
      this.modal_body_input_1.type('switch_test1')
      this.modal_body_input_2.type('description')
      this.add_button.click()
    }
    
    this.switch_dropdown_1.select('switch_test1')
    this.switch_value_1.first().select('Y')
    this.add_another_switch_after.click()

    if(type!='Duplicate'){
      this.new_switch_button_after.first().click()
      this.modal_body_input_1.type('switch_test2')
      this.modal_body_input_2.type('description')
      this.add_button.click()
    }
    
    this.switch_dropdown_2.select('switch_test2')
    this.switch_value_2.last().select('N')
   this.create_template_button.click()
   cy.wait(3000)
   if(type=='Duplicate'){
    this.success_message.should('have.text',' Uniqueness violation. Combination of Platform, Subject/Program Area, Process Area, Dataset and Template Version Name already exists.') 
   }
   else{
    this.success_message.should('have.text','Template created successfully.')
   }
    
    this.ok_button.click()

    

    



    
  }




  basic_dropdown_selection(){
    cy.wait(1000)
    this.platfrom_dropdown.select('dummy1_plt')
    cy.wait(1000)
    this.subject_area_dropdown.select('dummy2_sub')
    cy.wait(1000)
   this.process_area_dropdown.select('dummy3_proce')
   cy.wait(1000)
    this.dataset_dropdown.select('dummy4_dataset')
    cy.wait(1000)
  }

  empty(){
   this.basic_dropdown_selection()
    this.fieldName.clear()
    this.field_add_button.click()
    this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq('Blank and spaces not allowed')})
    this.startDate.invoke('attr', 'title').then(title=>{expect(title).to.eq('Required')})
    this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
    this.startDate.should('have.css','border-color','rgb(255, 0, 0)')
    this.endDate.should('have.css','border-color','rgb(151, 151, 151)')
  }



  template_version_check(){
    this.basic_dropdown_selection()
      this.template_version.clear()
      this.template_version.type('   ')
      this.template_version.should('have.value','')
      this.template_version.clear()
      this.template_version.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
      this.template_version.should('have.value','')
      this.template_version.clear()
      this.template_version.type("1234567890")
      this.template_version.should('have.value','')
      this.template_version.clear()
      this.template_version.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
      this.template_version.should('have.value','ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
      this.template_version.clear()
      this.template_version.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
      this.template_version.should('have.value','ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstu')


  }


  blank_spaces(){
  this.basic_dropdown_selection()
    this.fieldName.clear()
    this.startDate.type('2022-09-09')
    this.endDate.type('2022-09-09')
    this.field_add_button.click()
    this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq('Blank and spaces not allowed')})
    this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
    this.fieldName.clear()
    this.fieldName.type('       ')
    this.startDate.type('2022-09-09')
    this.endDate.type('2022-09-09')
    this.field_add_button.click()
    this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq('Blank and spaces not allowed')})
    this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
  
  }


  max_allowed_limit(){
    this.basic_dropdown_selection()
    this.fieldName.clear()
    this.fieldName.type('Lorem ipsum dolor sit amet consectetuer adipisLorem ipsum dolor sit amet consectetuer adipiscing elit Aenean commodo ligula eget dolor Aenean massa Cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus mus Donec quam felis ultricies nec pellentesque eu pretium qu')
    this.startDate.type('2022-09-09')
    this.endDate.type('2022-09-09')
    this.field_add_button.click()

    this.grid_data.getAgGridData().then((actualTableData)=>{

      cy.log(actualTableData)

      for(let i=1;i<actualTableData.length;i++){
       // cy.log(actualTableData[i]['SN'])
       // expect(actualTableData[i]['SN'])
      //  if(i>=2){
      //   expect(actualTableData[i]['Attribute Name*']).to.eq('Field'+(i+1))
      //  }
      //  else{
      //   expect(actualTableData[i]['Attribute Name*']).to.eq('Field'+i)
      //  }
       expect(actualTableData[i]['Attribute Name*']).to.eq('Lorem ipsum dolor sit amet consectetuer adipisLorem ipsum dolor sit amet consectetuer adipiscing elit Aenean commodo ligula eget dolor Aenean massa Cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus mus Donec quam felis ultric')
      }

    })

  }


  startdate_less_than_end_date(){
    this.basic_dropdown_selection()
    this.fieldName.clear()
    this.fieldName.type('Field1')
    this.startDate.type('2022-09-09')
    this.endDate.type('2022-09-08')
    this.field_add_button.click()
    this.startDate.invoke('attr', 'title').then(title=>{expect(title).to.eq('Start date should be less than End date')})
    this.startDate.should('have.css','border-color','rgb(255, 0, 0)')
    this.endDate.invoke('attr', 'title').then(title=>{expect(title).to.eq('Start date should be less than End date')})
    this.endDate.should('have.css','border-color','rgb(255, 0, 0)')
  }


  blank_start_date(){
    this.basic_dropdown_selection()
    this.fieldName.clear()
    this.startDate.clear()
    this.endDate.clear()
    this.fieldName.type('Field1')
    this.endDate.type('2022-09-08')
    this.field_add_button.click()
    this.startDate.invoke('attr', 'title').then(title=>{expect(title).to.eq('Required')})
    this.startDate.should('have.css','border-color','rgb(255, 0, 0)')
  }

  


  duplicate_entry(){
    this.basic_dropdown_selection()
    this.fieldName.clear()
    this.fieldName.type('Field1')
    this.startDate.type('2022-09-08')
    this.endDate.type('2022-09-09')
    this.field_add_button.click()
    this.fieldName.clear()
    this.fieldName.type('Field1')
    this.startDate.type('2022-12-31')
    this.endDate.type('2022-12-31')
    this.field_add_button.click()
    this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq('Duplicate Entry')})
    this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
  }


  special_character(){
    this.basic_dropdown_selection()
    this.fieldName.clear()
    this.startDate.clear()
    this.endDate.clear()
    this.fieldName.type(`,for`)
    this.startDate.type('2022-12-31')
    this.endDate.type('2022-12-31')
    this.field_add_button.click()
    this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
    this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
    this.fieldName.clear()
    this.fieldName.type(`{for`)
    this.startDate.type('2022-12-31')
    this.endDate.type('2022-12-31')
    this.field_add_button.click()
    this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
    this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
    this.fieldName.clear()
    this.fieldName.type(`for}`)
    this.startDate.type('2022-12-31')
    this.endDate.type('2022-12-31')
    this.field_add_button.click()
    this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
    this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
    this.fieldName.clear()
    this.fieldName.type(`()for`)
    this.startDate.type('2022-12-31')
    this.endDate.type('2022-12-31')
    this.field_add_button.click()
    this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
    this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
    this.fieldName.clear()
    this.fieldName.type(`=for`)
    this.startDate.type('2022-12-31')
    this.endDate.type('2022-12-31')
    this.field_add_button.click()
    this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
    this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
  }


  blank_end_date(){
    var month = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ]
    this.basic_dropdown_selection()
    this.fieldName.clear()
    this.startDate.clear()
    this.endDate.clear()
    this.fieldName.type(`First`)
    this.startDate.type('2022-12-31')
    //this.startDate.type({backspace})
    this.field_add_button.click()
    this.grid_data.getAgGridData().then((actualTableData)=>{

      cy.log(actualTableData)

      for(let i=1;i<actualTableData.length;i++){
       // cy.log(actualTableData[i]['SN'])
       // expect(actualTableData[i]['SN'])
      //  if(i>=2){
      //   expect(actualTableData[i]['Attribute Name*']).to.eq('Field'+(i+1))
      //  }
      //  else{
      //   expect(actualTableData[i]['Attribute Name*']).to.eq('Field'+i)
      //  }
       expect(actualTableData[i]['Attribute Name*']).to.eq('First')
       expect(actualTableData[i]['Ineffective Date']).to.eq('')
        expect(actualTableData[i]['Mandatory*']).to.eq('Y')
          expect(actualTableData[i]['Effective Date*']).to.eq(month['2022-12-31'.substring(5,7)*1 -1] +" "+'2022-12-31'.substring(8,10)+", " +'2022-12-31'.substring(0,4))
      }

    })
  }

  Delete_button(){
    var month = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ]
    this.basic_dropdown_selection()
    this.fieldName.clear()
    this.startDate.clear()
    this.endDate.clear()
    for(let i=1;i<=3;i++){
      this.fieldName.type('Field'+i)
      this.startDate.type('2022-12-31')
      this.endDate.type('2023-12-31')
      this.field_add_button.click()
    }
    this.delete_button_2.click()
    this.fieldName.type('Field4')
    this.startDate.type('2022-12-31')
    this.endDate.type('2023-12-31')
    this.field_add_button.click()

    this.grid_data.getAgGridData().then((actualTableData)=>{

      cy.log(actualTableData)

      for(let i=1;i<actualTableData.length;i++){
       cy.log(actualTableData[i]['SN'])
       expect(actualTableData[i]['SN'])
       if(i>=2){
        expect(actualTableData[i]['Attribute Name*']).to.eq('Field'+(i+1))
       }
       else{
        expect(actualTableData[i]['Attribute Name*']).to.eq('Field'+i)
       }
       //expect(actualTableData[i]['Attribute Name*']).to.eq('Field'+i)
       expect(actualTableData[i]['Effective Date*']).to.eq(month['2022-12-31'.substring(5,7)*1 -1] +" "+'2022-12-31'.substring(8,10)+", " +'2022-12-31'.substring(0,4))
       expect(actualTableData[i]['Ineffective Date']).to.eq(month['2023-12-31'.substring(5,7)*1 -1] +" "+'2023-12-31'.substring(8,10)+", " +'2023-12-31'.substring(0,4))
       expect(actualTableData[i]['Mandatory*']).to.eq('Y')
       expect(actualTableData[i]['SN']).to.eq(i.toString())
      }

    })

  }

  add_switch(){
    cy.wait(2000)
    this.new_switch_button.click()
    this.modal_body_input_1.type('switch_test1')
    this.modal_body_input_2.type('description')
    this.add_button.click()
   // cy.reload()
    //cy.wait(5000)
   this.switch_dropdown_1.select('switch_test1')
   this.switch_value_1.first().select('Y')
    this.add_another_switch.click()
    this.new_switch_button.first().click()
    this.modal_body_input_1.type('switch_test2')
    this.modal_body_input_2.type('description')
    this.add_button.click()
   // cy.reload()
   // cy.wait(5000)
    this.switch_dropdown_1.select('switch_test1')
    this.switch_value_1.first().select('Y')
   // this.add_another_switch.click()
    this.switch_dropdown_2.select('switch_test2')
    this.switch_value_2.last().select('N')
    
  }


  Create_JSON_Template(fieldName){
    // var date = new Date();
    // var year = date.getFullYear();
    // var month = String(date.getMonth()+1).padStart(2,'0');
    // var todayDate = String(date.getDate()).padStart(2,'0')
    // var datePattern = year +'-'+month+'-'+todayDate
   // this.platfrom_dropdown.select('Testing_purpose1')
     this.add_new_platform('Vignesh_Random_name_1','psodjiof','Template')
     this.add_subject_area('Vignesh_Random_name_Tier2','sdfsdfsdfsdf','Template')
     this.add_process_area('Vignesh_Random_name_Tier3','sdfsdf','Template')
   this.add_dataset('Vignesh_Random_name_dataset','sdfsdf','json',',','Y','Template')
  // this.subject_area_dropdown.select('Test2')
  // this.process_area_dropdown.select('Test3')
   // this.dataset_dropdown.select('Co-Sell')
    this.jsonSchema.clear()
    this.jsonSchema.type(fieldName)

  


    this.create_template_button.click()


    



    
  }


  Create_XML_Template(fieldName){
    // var date = new Date();
    // var year = date.getFullYear();
    // var month = String(date.getMonth()+1).padStart(2,'0');
    // var todayDate = String(date.getDate()).padStart(2,'0')
    // var datePattern = year +'-'+month+'-'+todayDate
   // this.platfrom_dropdown.select('Testing_purpose1')
     this.add_new_platform('Vignesh_Random_name_1','psodjiof','Template')
     this.add_subject_area('Vignesh_Random_name_Tier2','sdfsdfsdfsdf','Template')
     this.add_process_area('Vignesh_Random_name_Tier3','sdfsdf','Template')
   this.add_dataset('Vignesh_Random_name_dataset','sdfsdf','xml',',','Y','Template')
  // this.subject_area_dropdown.select('Test2')
  // this.process_area_dropdown.select('Test3')
   // this.dataset_dropdown.select('Co-Sell')
    this.xmlSchema.clear()
    this.xmlSchema.type(fieldName)

  


    this.create_template_button.click()


    



    
  }


  template_duplication(){
    this.platfrom_dropdown.select('Vignesh_Random_name_1')
    this.subject_area_dropdown.select('Vignesh_Random_name_Tier2')
   this.process_area_dropdown.select('Vignesh_Random_name_Tier3')
    this.dataset_dropdown.select('Vignesh_Random_name_dataset')
    this.template_version.select()
    this.xmlSchema.clear()
    this.xmlSchema.type('Sample')
    this.create_template_button.click()
    this.error_message_template.should('have.text','Uniqueness violation. Template already exists.')
  }



  checking_backend_entry_Field_Addition(config){
    checking_tier2_3_tables(config)
  }

  deleting_dummy_switch_entries(config){
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: "delete from cdm_core.switc_lkup where switc_cd ='switch_test1'"
    }).then((result) => {
     // expect(result.rows[0].cnt).to.eq('1')
    })

    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: "delete from cdm_core.switc_lkup where switc_cd ='switch_test2'"
    }).then((result) => {
     // expect(result.rows[0].cnt).to.eq('1')
    })
  }

  checking_tier2_3_tables(config){
    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: "select count(*) as cnt from cdm_core.tier2_3_hier where tier2_hier_nm='Vignesh_Random_name_Tier2' and tier3_hier_nm='Vignesh_Random_name_Tier3'"
      }).then((result) => {
        expect(result.rows[0].cnt).to.eq('1')
      })

    }


    checking_tmplt_table(config){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `select count(*) as cnt from  cdm_core.templt t where tier2_3_hier_id = (select tier2_3_hier_id from cdm_core.tier2_3_hier where tier2_hier_nm='Vignesh_Random_name_Tier2' and tier3_hier_nm='Vignesh_Random_name_Tier3')
            and dset_cd='Vignesh_Random_name_dataset' and pltfrm_cd='Vignesh_Random_name_1' and t.json_schma is null and t.xml_schma is null`
          }).then((result) => {
            expect(result.rows[0].cnt).to.eq('1')
          })
    
          
        }


        checking_tmplt_switch(config){
          cy.task("DATABASE", {
              dbConfig: Cypress.env(config),
              sql: `select count(*) as cnt from  cdm_core.templt_switc t where templt_id = (select templt_id from cdm_core.templt where dset_cd='Vignesh_Random_name_dataset' and pltfrm_cd='Vignesh_Random_name_1')
              and switc_cd='switch_test1'`
            }).then((result) => {
              expect(result.rows[0].cnt).to.eq('1')
            })


            cy.task("DATABASE", {
              dbConfig: Cypress.env(config),
              sql: `select count(*) as cnt from  cdm_core.templt_switc t where templt_id = (select templt_id from cdm_core.templt where dset_cd='Vignesh_Random_name_dataset' and pltfrm_cd='Vignesh_Random_name_1')
              and switc_cd='switch_test2'`
            }).then((result) => {
              expect(result.rows[0].cnt).to.eq('1')
            })
      
            
          }


        checking_tmplt_table_jsonschema(code,config){
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select count(*) as cnt from  cdm_core.templt t where tier2_3_hier_id = (select tier2_3_hier_id from cdm_core.tier2_3_hier where tier2_hier_nm='Vignesh_Random_name_Tier2' and tier3_hier_nm='Vignesh_Random_name_Tier3')
                and dset_cd='Vignesh_Random_name_dataset' and pltfrm_cd='Vignesh_Random_name_1' and t.json_schma = '`+code+`'`
              }).then((result) => {
                expect(result.rows[0].cnt).to.eq('1')
              })
        
              
            }


            
        checking_tmplt_table_xmlschema(code,config){
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select count(*) as cnt from  cdm_core.templt t where tier2_3_hier_id = (select tier2_3_hier_id from cdm_core.tier2_3_hier where tier2_hier_nm='Vignesh_Random_name_Tier2' and tier3_hier_nm='Vignesh_Random_name_Tier3')
                and dset_cd='Vignesh_Random_name_dataset' and pltfrm_cd='Vignesh_Random_name_1' and t.xml_schma = '`+code+`'`
              }).then((result) => {
                expect(result.rows[0].cnt).to.eq('1')
              })
        
              
            }

         onlyUnique(value, index, self) {
            return self.indexOf(value) === index;
          }

        checking_delim_templt_fld_def(fieldName,eff_start_date,eff_end_date,mandatory,config){
            let field=[];
            
            for(let i=0; i<fieldName.split('|').length;i++){
                console.log(eff_start_date.split("|")[i])
                console.log(eff_end_date.split("|")[i])
                if(new Date(eff_start_date.split("|")[i])<=new Date(eff_end_date.split("|")[i])){
                        field.push(fieldName.split("|")[i])
                }
            }
            cy.log(field)
            console.log(field)
            var unique = field.filter(this.onlyUnique);
            console.log(unique)
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select count(*) as cnt from cdm_core.delim_templt_fld_def where tier2_3_hier_id = (select tier2_3_hier_id from cdm_core.tier2_3_hier where tier2_hier_nm='Vignesh_Random_name_Tier2' and tier3_hier_nm='Vignesh_Random_name_Tier3')
                and dset_cd='Vignesh_Random_name_dataset' and pltfrm_cd='Vignesh_Random_name_1'`
              }).then((result) => {
                expect(result.rows[0].cnt).to.eq(unique.length.toString())
              })
        
            }



  check_platform_backend(code,config){
    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `select count(*) as cnt from cdm_core.pltfrm_lkup where pltfrm_lkup.pltfrm_cd ='`+code+`'`

        
      }).then((result) => {
        console.log(result)
        expect(result.rows[0].cnt).to.eq('1')
      })

      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: "delete from cdm_core.pltfrm_lkup where pltfrm_lkup.pltfrm_cd ='"+code+"'"
      }).then((result) => {
       
      })

    }

    check_platform_backend_character_exceeding(code,desc,config){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: "select count(*) as cnt from cdm_core.pltfrm_lkup where pltfrm_lkup.pltfrm_cd ='"+code+"' and pltfrm_lkup.pltfrm_dsc='"+desc+"'" 
          }).then((result) => {
            expect(result.rows[0].cnt).to.eq('1')
          })

          cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: "delete from cdm_core.pltfrm_lkup where pltfrm_lkup.pltfrm_cd ='"+code+"' and pltfrm_lkup.pltfrm_dsc='"+desc+"'" 
          }).then((result) => {
           // expect(result.rows[0].cnt).to.eq('1')
          })
    
        }


        


    
  check_subject_backend(code,config){
    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: "select count(*) as cnt from cdm_core.class_hier_lkup where hier_cd ='"+code+"'"
      }).then((result) => {
        expect(result.rows[0].cnt).to.eq('1')
      })

      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: "delete from cdm_core.class_hier_lkup where hier_cd ='"+code+"'"
      }).then((result) => {
       
      })

    }


    check_subject_backend_character_exceeding(code,desc,config){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: "select count(*) as cnt from cdm_core.class_hier_lkup where hier_cd ='"+code+"' and hier_dsc='"+desc+"'" 
          }).then((result) => {
            expect(result.rows[0].cnt).to.eq('1')
          })

          cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: "delete from cdm_core.class_hier_lkup where hier_cd ='"+code+"' and hier_dsc='"+desc+"'" 
          }).then((result) => {
           // expect(result.rows[0].cnt).to.eq('1')
          })
    
        }


    
    check_dataset_backend(code,config){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: "select count(*) as cnt from cdm_core.dset_lkup where dset_cd ='"+code+"'"
          }).then((result) => {
            expect(result.rows[0].cnt).to.eq('1')
          })


          cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: "delete from cdm_core.dset_lkup where dset_cd ='"+code+"'"
          }).then((result) => {
            
          })
    
        }


        check_dataset_backend_character_exceeding(code,desc,config){
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: "select count(*) as cnt from cdm_core.dset_lkup where dset_cd ='"+code+"' and dset_dsc='"+desc+"'" 
              }).then((result) => {
                expect(result.rows[0].cnt).to.eq('1')
              })
    
              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: "delete from cdm_core.dset_lkup where dset_cd ='"+code+"' and dset_dsc='"+desc+"'" 
              }).then((result) => {
               // expect(result.rows[0].cnt).to.eq('1')
              })
        
            }



        deleting_dummy_entries_delim_templt_fld_def(config){
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `DELETE FROM cdm_core.delim_templt_fld_def where tier2_3_hier_id=(select tier2_3_hier_id from cdm_core.tier2_3_hier 
                    where tier2_hier_nm='Vignesh_Random_name_Tier2' and tier3_hier_nm='Vignesh_Random_name_Tier3')`
              }).then((result) => {
              })
        
            }



            deleting_dummy_entries_templt_switc(config){
              cy.task("DATABASE", {
                  dbConfig: Cypress.env(config),
                  sql: `DELETE FROM cdm_core.templt_switc where switc_cd='switch_test1'`
                }).then((result) => {
                })


                cy.task("DATABASE", {
                  dbConfig: Cypress.env(config),
                  sql: `DELETE FROM cdm_core.templt_switc where switc_cd='switch_test2'`
                }).then((result) => {
                })


                cy.task("DATABASE", {
                  dbConfig: Cypress.env(config),
                  sql: `DELETE FROM cdm_core.switc_lkup where switc_cd='switch_test2'`
                }).then((result) => {
                })


                cy.task("DATABASE", {
                  dbConfig: Cypress.env(config),
                  sql: `DELETE FROM cdm_core.switc_lkup where switc_cd='switch_test1'`
                }).then((result) => {
                })
          
              }


            


            deleting_dummy_entries_tmplt(config){
                cy.task("DATABASE", {
                    dbConfig: Cypress.env(config),
                    sql: `delete from cdm_core.templt where tier2_3_hier_id=(select tier2_3_hier_id from cdm_core.tier2_3_hier 
                        where tier2_hier_nm='Vignesh_Random_name_Tier2' and tier3_hier_nm='Vignesh_Random_name_Tier3')`
                  }).then((result) => {
                  })
            
                }


                deleting_dummy_entries_dset_lkup(config){
                    cy.task("DATABASE", {
                        dbConfig: Cypress.env(config),
                        sql: `delete from cdm_core.dset_lkup where dset_cd='Vignesh_Random_name_dataset'`
                      }).then((result) => {
                      })
                
                    }

                    deleting_dummy_entries_tier2_3_hier(config){
                        cy.task("DATABASE", {
                            dbConfig: Cypress.env(config),
                            sql: `delete from cdm_core.tier2_3_hier where tier2_3_hier_id=(select tier2_3_hier_id from cdm_core.tier2_3_hier 
                                where tier2_hier_nm='Vignesh_Random_name_Tier2' and tier3_hier_nm='Vignesh_Random_name_Tier3')`
                          }).then((result) => {
                          })
                    
                        }
    
                        deleting_dummy_entries_class_hier_lkup_tier2(config){
                            cy.task("DATABASE", {
                                dbConfig: Cypress.env(config),
                                sql: `delete from cdm_core.class_hier_lkup where hier_cd='Vignesh_Random_name_Tier2'`
                              }).then((result) => {
                              })
                        
                            }

                            deleting_dummy_entries_class_hier_lkup_tier3(config){
                                cy.task("DATABASE", {
                                    dbConfig: Cypress.env(config),
                                    sql: `delete from cdm_core.class_hier_lkup where hier_cd='Vignesh_Random_name_Tier3'`
                                  }).then((result) => {
                                  })
                            
                                }


                                deleting_dummy_entries_pltfrm_lkup(config){
                                    cy.task("DATABASE", {
                                        dbConfig: Cypress.env(config),
                                        sql: `delete from cdm_core.pltfrm_lkup where pltfrm_lkup.pltfrm_cd='Vignesh_Random_name_1'`
                                      }).then((result) => {
                                      })
                                
                                    }


}


export default new confignewtemp()