// ************************ Home page Function definitions***********************************
// This file contains all the function definitions and css selectors used for testing the Home page
// Created by Vignesh Sekar
// 
// Css Selectors - CSS selectors is used for locating the elements in UI screen
//
// Below are the Scenarios Covered for testing Home page:
// 1.Checking the Title of the Homepage
// 2.Verifying the Navbar Menu in the Home page
// 3.Verifying all the submenu under the Navbar Menu
// 4.Carousel Check
// 5.Links in the Home page is working as expected


class home_page {
   
    get title(){
        return cy.xpath('//*[@id="root"]/div[1]/nav/div/a')
    }

    get dataset_menu(){
        return cy.xpath('//*[@id="datasetDropdown"]')
    }

    get configuration_menu(){
        return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/a[1]')
    }

    get report_menu(){
        return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/a[2]')
    }

    get support_menu(){
        return cy.xpath('//*[@id="basic-navbar-nav"]/div[2]/a')
    }


    get language_menu(){
        return cy.xpath('//*[@id="LanguageDropdown"]')
    }

    get user_name(){
        return cy.xpath('//*[@id="userSignOutDropdown"]/div')
    }


    get banner_text(){
        return cy.xpath('//*[@id="root"]/div[2]/div/div[1]/h1')
    }

    get upload_file_menu(){
        return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[1]')
    }

    get historical_data_menu(){
        return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[2]')
    }

    get workflow_area_menu(){
        return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[3]')
    }

    get language_submenu_1(){
        return cy.xpath('//*[@id="basic-navbar-nav"]/div[2]/div[1]/div/a[1]')
    }

    get language_submenu_2(){
        return cy.xpath('//*[@id="basic-navbar-nav"]/div[2]/div[1]/div/a[2]')
    }

    get upload_file_title(){
        return cy.xpath('//*[@id="root"]/div[2]/main/h3')
    }

    get historical_data_title(){
        return cy.xpath('//*[@id="root"]/div[2]/main/h3')
    }

    get workflow_area_title(){
        return cy.xpath('//*[@id="root"]/div[2]/main/h3')
    }

    get configuration_page_title(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/h2')
    }

    get next_arrow(){
        return cy.xpath('//*[@id="root"]/div[2]/div/div[2]/div/div/a[2]/span[1]')
    }

    get prev_arrow(){
        return cy.xpath('//*[@id="root"]/div[2]/div/div[2]/div/div/a[1]/span[1]')
    }

    get slide1(){
        return cy.xpath('//*[@id="root"]/div[2]/div/div[2]/div/div/div[1]/button[1]')
    }

    get slide2(){
        return cy.xpath('//*[@id="root"]/div[2]/div/div[2]/div/div/div[1]/button[2]')
    }

    get card2_text(){
        return cy.xpath('//*[@id="root"]/div[2]/div/div[2]/div/div/div[2]/div[1]/div/div/div[2]/div/div/div')
    }

    get card2_text_slide2(){
        return cy.xpath('//*[@id="root"]/div[2]/div/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div/div/div')
    }

    get upload_file_hyperlink(){
        return cy.xpath('//*[@id="root"]/div[2]/div/div[2]/div/div/div[2]/div/div/div/div[2]/div/div/p/a[1]')
    }

    get historical_data_hyperlink(){
        return cy.xpath('//*[@id="root"]/div[2]/div/div[2]/div/div/div[2]/div/div/div/div[2]/div/div/p/a[2]')
    }

  



    title_validation(){
        this.title.should('have.text','Consumption Data Management')
    }


    navbar_menu_validation(){
        this.dataset_menu.should('have.text','Dataset')
        this.configuration_menu.should('have.text','Configuration')
        this.report_menu.should('have.text','Reports')
        this.support_menu.should('have.text','Support')
        this.language_menu.should('have.text','Language')
        this.user_name.should('have.text',' System User')
    }


    banner_text_validation(){
        this.banner_text.should('have.text','Consumption Data Management')
    }

    dataset_submenu_validation(){
        this.dataset_menu.click()
        this.upload_file_menu.should('have.text','Upload File')
        this.historical_data_menu.should('have.text','Historical Data')
        this.workflow_area_menu.should('have.text','Workflow Area')
        this.dataset_menu.click()


    }

    language_submenu_validation(){
        this.language_menu.click()
        this.language_submenu_1.should('have.text','English-US')
        this.language_submenu_2.should('have.text','English-UK')
        this.language_menu.click()
    }

    upload_file(){
        this.dataset_menu.click()
        this.upload_file_menu.click()
        this.upload_file_title.should('have.text','Upload New File')

    }

    historical_data(){
        this.dataset_menu.click()
        this.historical_data_menu.click()
        this.historical_data_title.should('have.text','Historical Data')

    }

    workflow_area(){
        this.dataset_menu.click()
        this.workflow_area_menu.click()
        this.workflow_area_title.should('have.text','Workflow Area')
    }

    configuration_page(){
        this.configuration_menu.click()
        this.configuration_page_title.should('have.text','Configure Tables')
        cy.go('back')

    }

    homepage_click(){
        this.title.click()
        cy.wait(5000)
        this.banner_text.should('have.text','Consumption Data Management')
    }

    carousel_check(){
        this.card2_text.should('have.text','Useful Links')
        this.slide1.should('have.css','opacity','1')
        this.slide2.should('have.css','opacity','0.5')
        this.next_arrow.click()
        cy.wait(1000)
        this.card2_text_slide2.should('have.text','Test')
        this.slide1.should('have.css','opacity','0.5')
        this.slide2.should('have.css','opacity','1')
        this.prev_arrow.click()
        cy.wait(1000)
        this.card2_text.should('have.text','Useful Links')
        this.slide1.should('have.css','opacity','1')
        this.slide2.should('have.css','opacity','0.5')
    }

    upload_file_link(){
        this.upload_file_hyperlink.click()
        cy.wait(5000)
        this.upload_file_title.should('have.text','Upload New File')

    }

    historical_data_link(){
        this.title.click()
        cy.wait(5000)
        //this.historical_data_hyperlink.click()
        this.dataset_menu.click()
        this.historical_data_menu.click()
        cy.wait(5000)
        this.historical_data_title.should('have.text','Historical Data')

    }


  }




export default new home_page();
