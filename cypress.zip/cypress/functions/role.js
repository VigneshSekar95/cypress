
class rolefunc {

  get dataset_menu(){
    return cy.xpath('//*[@id="datasetDropdown"]')
  }

  get historical_data() {
    return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[1]')
  }

  get historical_data_1() {
    return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[2]')
  }

  get pagecount_button(){
    return cy.get('.ag-paging-panel>span>span:nth-of-type(5)')
}
  
  get ag_grid(){
    return  cy.get('#uncontrolled-tab-example-tabpane-History')

}
    
  get show_filter_button(){

    return cy.get('.d-flex.justify-content-end.mt-3 > div > button:nth-of-type(1)')

  }

  get submission_period(){
    return cy.get('.rmdp-input')
  }

  get submission_month(){
    return ['.rmdp-month-picker>div:nth-of-type(1)>div:nth-of-type(1)>span',
    '.rmdp-month-picker>div:nth-of-type(1)>div:nth-of-type(2)>span',
    '.rmdp-month-picker>div:nth-of-type(1)>div:nth-of-type(3)>span',
    '.rmdp-month-picker>div:nth-of-type(2)>div:nth-of-type(1)>span',
    '.rmdp-month-picker>div:nth-of-type(2)>div:nth-of-type(2)>span',
    '.rmdp-month-picker>div:nth-of-type(2)>div:nth-of-type(3)>span',
    '.rmdp-month-picker>div:nth-of-type(3)>div:nth-of-type(1)>span',
    '.rmdp-month-picker>div:nth-of-type(3)>div:nth-of-type(2)>span',
    '.rmdp-month-picker>div:nth-of-type(3)>div:nth-of-type(3)>span',
    '.rmdp-month-picker>div:nth-of-type(4)>div:nth-of-type(1)>span',
    '.rmdp-month-picker>div:nth-of-type(4)>div:nth-of-type(2)>span',
    '.rmdp-month-picker>div:nth-of-type(4)>div:nth-of-type(3)>span']
    
  }

  get submission_period_value(){
    return cy.get('.rmdp-input')
  }

  get HistoryTab(){
    return cy.get('#uncontrolled-tab-example-tab-History')
}

get partner_filter(){
  return cy.xpath('//*[@id="filter"]/div[1]/div[1]/div[2]')
}

get save_filter_button(){
  return cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(3)>div>div>button:nth-of-type(2)')
}

get save_filter_filter_after_selection(){
  return cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(4)>div>div>button:nth-of-type(2)')
}


get saved_filters_tab(){
  return cy.get('#uncontrolled-tab-example-tab-SavedFilters')
}

get make_as_default(){
  return cy.get('#uncontrolled-tab-example-tabpane-SavedFilters>div>div:nth-of-type(2)>div>div>button:nth-of-type(1)')
}

get saved_filters_apply_button(){
  return cy.get('#uncontrolled-tab-example-tabpane-SavedFilters>div>div:nth-of-type(2)>div>div>button:nth-of-type(2)')
}


get user_profile(){
  return cy.xpath('//*[@id="nav-dropdown-light-example"]')
}

get email_addr(){
  return cy.xpath('//*[@id="navbar-light-example"]/div/div/div/span[2]')
}


get user_nm(){
  return cy.xpath('//*[@id="userSignOutDropdown"]/div')
}


get pagecount_button(){
  return cy.get('#uncontrolled-tab-example-tabpane-History>div>div>div>div>div:nth-of-type(2)>span>span:nth-of-type(5)')
}





uploadHistoryButton_click() {
  this.dataset_menu.click()
  this.historical_data.should('have.text','Historical Data')
  this.historical_data.click()
}


uploadHistoryButton_click_1() {
  this.dataset_menu.click()
  this.historical_data_1.should('have.text','Historical Data')
  this.historical_data_1.click()
}

    make_dflt_ind(config){

      this.user_nm.then(($el)=>{
        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: `update cdm_ui_cntnt.ui_sav_srch_nm set make_dflt_ind='N'
          where sav_by_usr_prncpl_id=(  select prncpl_id from cdm_accs_enttl.usr usr where usr_nm='`+$el.text().trim()+`')`
        }).then((result) => {
            
  
        })
      })
        
  
      }


      grid_count_org(config){
          
        this.pagecount_button.first().then(($el) => {
          const overall_count = $el.text()

          this.user_nm.then(($us)=>{
            cy.task("DATABASE", {
              dbConfig: Cypress.env(config),
              sql: `select count(*) as cnt
              from 
                 cdm_core.file_onbord_instc fil
                   inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                          inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                          inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id  
              where fil.latst_onbord_sts_cd  in ('CDM_Duplicate_Confirmed','CDM_Published','CDM_Processing_Success','CDM_Inactive')
              and fil.file_land_dtm >= (now() - interval '12 month')
              and org1.org_nm = (  select org.org_nm from cdm_accs_enttl.usr usr 
                          inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                          inner join cdm_accs_enttl.org org on org.org_id=pl.org_id where usr_nm='`+$us.text().trim()+`')`
            }).then((result) => {
              expect(result.rows[0].cnt).to.eq(overall_count)
            })
          })
       

      })
      }


      data_count(config){

          cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql:`
            select count(*) as cnt
            from 
               cdm_core.file_onbord_instc fil
                 inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                        inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                        inner join cdm_accs_enttl.org org on org.org_id=pl.org_id  
            where fil.latst_onbord_sts_cd  in ('CDM_Duplicate_Confirmed','CDM_Published','CDM_Processing_Success','CDM_Inactive')
            and fil.file_land_dtm >= (now() - interval '12 month')`
      
          }).then((result) => {
            this.pagecount_button.first().then(($el) => {
                const overall_count = $el.text()

            expect(result.rows[0].cnt).to.eq(overall_count)

            })
  
        })
        



        
  
      }


      columns_validaiton(columns){
        for(let i=1; i<columns.length;i++){
          let j=i+1;
            cy.get('.ag-header-row>.ag-header-cell:nth-of-type('+j+')>div:nth-of-type(3)>div>span:nth-of-type(1)').eq(0).should('have.text',columns[i])
          }


          this.ag_grid.getAgGridData().then((actualTableData)=>{
                
            console.log(actualTableData)
            expect(Object.keys(actualTableData[0]).length).to.eq(columns.length)
            
          })

    }

   

    grid_count_all(config){
      
      this.pagecount_button.last().then(($el) => {
        const overall_count = $el.text()

      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `select count(*) as cnt
        from 
           cdm_core.file_onbord_instc fil
             inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id  
        where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',
        
                'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
        `
      }).then((result) => {
        expect(result.rows[0].cnt).to.eq(overall_count)
      })

    })
    }


    columns_validaition_min(columns){
      for(let i=0; i<11;i++){
          let j=i+1
          cy.get('.ag-header-row>.ag-header-cell:nth-of-type('+j+')>div:nth-of-type(3)>div>span:nth-of-type(1)').eq(0).should('have.text',columns[i])
        }

  }


    five_buttons_visible(buttons){
        for(let i=1;i<=5;i++){
            cy.get('.d-flex.justify-content-end.mt-3 > div > button:nth-of-type('+i+')').first().should('be.visible')
            cy.get('.d-flex.justify-content-end.mt-3 > div > button:nth-of-type('+i+')').first().should('have.text',buttons[i-1])
        }
        
    }


    all_buttons_visible(buttons){
      for(let i=1;i<=6;i++){
          cy.get('.d-flex.justify-content-end.mt-3 > div > button:nth-of-type('+i+')').first().should('be.visible')
          cy.get('.d-flex.justify-content-end.mt-3 > div > button:nth-of-type('+i+')').first().should('have.text',buttons[i-1])
      }
      
  }


    only_four_buttons_visible(buttons){
      for(let i=1;i<=4;i++){
        cy.get('.d-flex.justify-content-end.mt-3 > div > button:nth-of-type('+i+')').first().should('be.visible')
        cy.get('.d-flex.justify-content-end.mt-3 > div > button:nth-of-type('+i+')').first().should('have.text',buttons[i-1])
      }
      
  }

    all_partners_available(End_Month,query,config){
      const d = new Date();
      let end_month_added;
      let i=0;
      this.show_filter_button.first().click()
      this.submission_period.click()
      if((End_Month+1)<10){end_month_added='0'+(End_Month+1)}else{end_month_added=(End_Month+1)}
      cy.get(this.submission_month[End_Month]).click()
      cy.get(this.submission_month[End_Month]).click()
      this.submission_period_value.should('have.value',end_month_added+'/'+(d.getFullYear())+' ~ '+end_month_added+'/'+(d.getFullYear()))
      this.HistoryTab.click()
      this.partner_filter.click()
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: query
      }).then((result) => {
          cy.log(result)
          cy.log(result.rowCount)
          cy.log(result.rows[i].org_nm)
          for(i=0;i<result.rowCount;i++){
            cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(2)>div:nth-of-type(2)>div>div:nth-of-type(2)').contains(result.rows[i].org_nm).click()
            
          }

          cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(2)>div:nth-of-type(2)>div>div:nth-of-type(2)>div').find('div').should('have.length',(result.rowCount+1)*2)
        })
       // this.save_filter_button.click()
       // if(type=='program_manager'){cy.get('#formBasicEmail').type('All_partners_ww_program_manager')}
       // if(type=="intel_bizops"){cy.get('#formBasicEmail').type('All_partners_Intel_bizops')}
        
       // this.save_filter_filter_after_selection.click()
    }

    particular_partner_available(config){
      this.show_filter_button.first().click()
      this.partner_filter.click()



      this.user_nm.then(($us)=>{
        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: `select org.org_nm from cdm_accs_enttl.usr usr 
          inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
          inner join cdm_accs_enttl.org org on org.org_id=pl.org_id where usr_nm='`+$us.text().trim()+`'`
        }).then((result) => {
          //expect(result.rows[0].cnt).to.eq(overall_count)
          cy.log(result)
          cy.log(result.rowCount)
          //cy.log(result.rows[i].org_nm)
          for(let i=0;i<result.rowCount;i++){
            cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(2)>div:nth-of-type(2)>div>div:nth-of-type(2)').contains(result.rows[i].org_nm).click()
          }
          cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(2)>div:nth-of-type(2)>div>div:nth-of-type(2)>div').find('div').should('have.length',4)

        })

       

      })




    }


    make_as_default_check(query,config){
        this.saved_filters_tab.click()
        cy.get('#savedFilters').select('All_partners_ww_program_manager')
        this.make_as_default.click()
        cy.wait(3000)
        this.saved_filters_apply_button.click()
        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: query
        }).then((result) => {
            
          this.pagecount_button.first().then(($el) => {
            let gridData=[];
            const overall_count = $el.text()

        expect(result.rows[0].cnt).to.eq(overall_count)

        })
            

          })



    }


    make_as_default_check_intel_bizops(query,config){
      this.saved_filters_tab.click()
      cy.get('#savedFilters').select('All_partners_Intel_bizops')
      this.make_as_default.click()
      cy.wait(3000)
      this.saved_filters_apply_button.click()
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: query
      }).then((result) => {
          
        this.pagecount_button.first().then(($el) => {
          let gridData=[];
          const overall_count = $el.text()

      expect(result.rows[0].cnt).to.eq(overall_count)

      })
          

        })



  }


  role_change(config,role_id){
    this.user_nm.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql:` update cdm_accs_enttl.prncpl_role_asgn set role_id=`+role_id+` where prncpl_id = (select prncpl_id from cdm_accs_enttl.usr where usr_nm='`+$el.text().trim()+`')`
  
      })
    })
    
  
  }


  }
  
  export default new rolefunc();
  