class ModifyTemplate {
    get configuration_button(){
      return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/a[1]')
    }

    get operation_button(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[1]/div[1]/div/div[2]/input')
        
    }

    get modify_template_button(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[3]/div/div[3]/button')

        
    }

    get heading(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/h2')
    }

    get subheading(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[1]')
    }

    get platform_header(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[1]/label')
    }

    get subject_header(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[2]/label')
    }

    get process_header(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[3]/label')
    }

    get dataset_header(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[4]/label')
    }

    get version_header(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[5]/label')
    }

    get platform_dropdown(){
        return cy.xpath('//*[@id="platform"]')
    }

    get subject_dropdown(){
        return cy.xpath('//*[@id="tier2Name"]')
    }

    get process_dropdown(){
        return cy.xpath('//*[@id="tier3Name"]')
    }

    get dataset_dropdown(){
        return cy.xpath('//*[@id="dataset"]')
    }

    get version_dropdown(){
        return cy.xpath('//*[@id="version"]')
    }

    get grid_data(){
        return cy.get('.ag-root-wrapper')
      }


      get fieldName(){
        return  cy.get('input[name=fieldName]')
    }

    get startDate(){
        return cy.get('input[name=startDate]')
    }

    get endDate(){
       return  cy.get('input[name=endDate]')
    }

    get mandatory(){
        return cy.get('select[name=mandatory]')
    }

    get field_add_button(){
        return cy.get('.ag-cell .btn-primary')
    }

    get edit_button(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/div/form/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[4]/div[7]/i')
    }


    get edit_button_2(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/div/form/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[3]/div[7]/i')
  }

    get edit_button_version(){
      return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/div/form/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[2]/div[7]/i')
    }

    get update_button(){
        return cy.xpath('/html/body/div[6]/div/div/div[3]/button[2]')
    }


  

    get close_button(){
        return cy.xpath('/html/body/div[6]/div/div/div[3]/button[1]')
    }

    get effective_date(){
        return cy.xpath('/html/body/div[6]/div/div/div[2]/div[2]/input')
    }

    get ineffective_date(){
        return cy.xpath('/html/body/div[6]/div/div/div[2]/div[3]/input')
    }

    get mandatory(){
        return cy.xpath('/html/body/div[6]/div/div/div[2]/div[4]/select')
    }

    get effective_date_error(){
        return cy.xpath('/html/body/div[6]/div/div/div[2]/div[2]/div')
    }

    


    get ineffective_date_error(){
        return cy.xpath('/html/body/div[6]/div/div/div[2]/div[3]/div')
    }

    get switch_name(){
        return cy.xpath('//*[@id="switchCode0"]')
    }


    get switch_name_1(){
        return cy.xpath('//*[@id="switchCode1"]')
    }

    get switch_value(){
        return cy.xpath('//*[@id="switchValue"]')
    }

    get add_new_switch(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[2]/div[1]/button')
    }

    get new_switch(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[2]/div[2]/div[3]/div[1]/div/div/div/button/i')
    }

    get modal_body_input_1(){
        return cy.get('.mb-3:nth-of-type(1)>input')
    }

    get modal_body_input_2(){
        return cy.get('.mb-3:nth-of-type(2)>input')
    }


    get cancel_button(){
        return cy.get('.modal-footer>button:nth-of-type(1)')
    }

    get add_button(){
        return cy.get('.modal-footer>button:nth-of-type(2)')
    }


    get error_message(){
        return cy.get('.invalid-feedback')
    }


    get modal_header(){
        return cy.xpath('/html/body/div[6]/div/div/div[1]')
      }
    
      get modal_body(){
        return cy.xpath('/html/body/div[6]/div/div/div[2]/p')
      }
    
      get modal_button(){
        return cy.xpath('/html/body/div[6]/div/div/div[3]/button')
      }

      get modal_cancel_button(){
        return cy.xpath('/html/body/div[6]/div/div/div[3]/button[1]')
      }

      get update_template_version(){
        return cy.xpath('//*[@id="btn"]')

        //*[@id="btn"]
      }

      get json_text_area(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/textarea')
      }


      get active_button(){
        return cy.get('.ag-center-cols-container>div:nth-of-type(4)>div:nth-of-type(6)>span>div>input')
      }

      get active_button_1(){
        return cy.get('.ag-center-cols-container>div:nth-of-type(2)>div:nth-of-type(6)>span>div>input')
      }

      get active_button_2(){
        return cy.get('.ag-center-cols-container>div:nth-of-type(3)>div:nth-of-type(6)>span>div>input')
      }

      get active_button_4(){
        return cy.get('.ag-center-cols-container>div:nth-of-type(5)>div:nth-of-type(6)>span>div>input')
      }

      get template_isinactive(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[1]')
      }

      get template_isinactive_2(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[1]')
      }

      get fields_section(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[1]')
      }


      get switch_section(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[1]')
      }

      get ineffective_date_first_row(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/div/form/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[2]/div[4]')
      }


      get ineffective_date_last_row(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/div/form/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[5]/div[4]')
      }

      



    modify_template_page(){
        this.configuration_button.click()
        cy.wait(1000)
        this.operation_button.click()
        cy.wait(1000)
        this.modify_template_button.should('have.text','Modify existing template version')
        this.modify_template_button.click()

    }


    heading_subheading(){
       this.heading.should('have.text','Modify Template Version')
       this.subheading.should('have.text','Update an existing template by changing template attributes or template switches across organizations.')

    }

    dropdown_header(){
            this.platform_header.should('have.text','Platform*:')
            this.subject_header.should('have.text','Program/Subject Area*:')
            this.process_header.should('have.text','Process Area*:')
            this.dataset_header.should('have.text','Dataset*:')
            this.version_header.should('have.text','Template Version*:')
            
    }


    version_dropdown_validation(config,version){
      this.platform_dropdown_selection(config)
      this.subject_area_dropdown_selection(config)
      this.process_area_dropdown_selection(config)
      this.dataset_dropdown_selection(config)
      this.version_dropdown_selection(config,version)
    }


    platform_dropdown_selection(config){

      cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: `Select distinct t.pltfrm_cd from cdm_core.templt t`,
        }).then((result) => {
          for(let i=0;i<result.rows.length;i++){
              this.platform_dropdown.select(result.rows[i].pltfrm_cd)
          }
  
          this.platform_dropdown.find('option').should('have.length',result.rows.length+1)
          this.platform_dropdown.select('dummy1_plt')
        })
  
  }
  
  subject_area_dropdown_selection(config){
  
    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `Select distinct t1.tier2_hier_nm from cdm_core.templt t
        inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
        where  t.pltfrm_cd='dummy1_plt'`,
      }).then((result) => {
        for(let i=0;i<result.rows.length;i++){
            this.subject_dropdown.select(result.rows[i].tier2_hier_nm)
        }
  
        this.subject_dropdown.find('option').should('have.length',result.rows.length+1)
        this.subject_dropdown.select('dummy2_sub')
      })
  
  }
  
  process_area_dropdown_selection(config){
  
    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `Select distinct t1.tier3_hier_nm from cdm_core.templt t
        inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
        where  t.pltfrm_cd='dummy1_plt'`,
      }).then((result) => {
        for(let i=0;i<result.rows.length;i++){
            this.process_dropdown.select(result.rows[i].tier3_hier_nm)
        }
  
        this.process_dropdown.find('option').should('have.length',result.rows.length+1)
        this.process_dropdown.select('dummy3_proce')
      })
  
  }
  
  
  dataset_dropdown_selection(config){
  
    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `Select distinct t.dset_cd from cdm_core.templt t
        inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
        where  t.pltfrm_cd='dummy1_plt' and t1.tier3_hier_nm='dummy3_proce' and t1.tier2_hier_nm = 'dummy2_sub'`,
      }).then((result) => {
        for(let i=0;i<result.rows.length;i++){
            this.dataset_dropdown.select(result.rows[i].dset_cd)
        }
  
        this.dataset_dropdown.find('option').should('have.length',result.rows.length+1)
        this.dataset_dropdown.select('dummy4_dataset')
      })
  
  }
  
  
  version_dropdown_selection(config,version){
  
    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `   Select  distinct t.templt_ver_nm
        from cdm_core.templt t
        inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
   where t.pltfrm_cd='dummy1_plt' and t1.tier3_hier_nm='dummy3_proce' and t1.tier2_hier_nm = 'dummy2_sub' and t.dset_cd='dummy4_dataset' `,
      }).then((result) => {
        for(let i=0;i<result.rows.length;i++){
            this.version_dropdown.select(result.rows[i].templt_ver_nm)
        }
  
        this.version_dropdown.find('option').should('have.length',result.rows.length+1)
       
      })
  
      this.version_dropdown.select(version)
  
  }


    selecting_template(version){
        this.platform_dropdown.select('dummy1_plt')
        this.subject_dropdown.select('dummy2_sub')
        this.process_dropdown.select('dummy3_proce')
        this.dataset_dropdown.select('dummy4_dataset')
        this.version_dropdown.select(version)
    }

    backend_data_checking(config,version){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `
            select fld_nm,to_char(fld_eff_dtm,'Mon DD, YYYY') as fld_eff_dtm,
            case when fld_expr_dtm='3000-01-01T00:00:00+00:00' then '' else  to_char(fld_expr_dtm,'Mon DD, YYYY')end as fld_expr_dtm 
        from cdm_core.templt t
        inner join cdm_core.delim_templt_fld_def fl on fl.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = fl.pltfrm_cd 
        and t.dset_cd = fl.dset_cd and fl.tier2_3_hier_id = t.tier2_3_hier_id
        inner join cdm_core.tier2_3_hier ti on fl.tier2_3_hier_id = ti.tier2_3_hier_id
        where fl.dset_cd='dummy4_dataset' and fl.pltfrm_cd='dummy1_plt' and t.templt_ver_nm='`+version+`' and ti.tier2_hier_nm='dummy2_sub'
         order by fld_ui_dsply_pstn asc`
          }).then((result) => {

            cy.log(result)

            this.grid_data.getAgGridData().then((actualTableData)=>{
                cy.log(actualTableData)

                for(let i=0;i<result.rows.length;i++){
                expect(actualTableData[i+1]['Attribute Name*']).to.eq(result.rows[i]['fld_nm'])
                expect(actualTableData[i+1]['Effective Date*']).to.eq(result.rows[i]['fld_eff_dtm'])
                expect(actualTableData[i+1]['Ineffective Date']).to.eq(result.rows[i]['fld_expr_dtm'])
                }
            })

          })
      
    }



    empty_record(){
        //this.basic_dropdown_selection()
         this.fieldName.clear()
         this.field_add_button.click()
         this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq('Blank and spaces not allowed')})
         this.startDate.invoke('attr', 'title').then(title=>{expect(title).to.eq('Required')})
         this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
         this.startDate.should('have.css','border-color','rgb(255, 0, 0)')
         this.endDate.should('have.css','border-color','rgb(151, 151, 151)')
       }


       blank_spaces(){
       // this.basic_dropdown_selection()
          this.fieldName.clear()
          this.startDate.type('2022-09-09')
          this.endDate.type('2022-09-09')
          this.field_add_button.click()
          this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq('Blank and spaces not allowed')})
          this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
          this.fieldName.clear()
          this.fieldName.type('       ')
          this.startDate.type('2022-09-09')
          this.endDate.type('2022-09-09')
          this.field_add_button.click()
          this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq('Blank and spaces not allowed')})
          this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
        
        }


        max_allowed_limit(){
            this.fieldName.clear()
            this.fieldName.type('Lorem ipsum dolor sit amet consectetuer adipisLorem ipsum dolor sit amet consectetuer adipiscing elit Aenean commodo ligula eget dolor Aenean massa Cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus mus Donec quam felis ultricies nec pellentesque eu pretium qu')
            this.startDate.type('2022-09-09')
            this.endDate.type('2022-09-09')
            this.field_add_button.click()
        
            this.grid_data.getAgGridData().then((actualTableData)=>{
        
              cy.log(actualTableData)
        
            
               expect(actualTableData[4]['Attribute Name*']).to.eq('Lorem ipsum dolor sit amet consectetuer adipisLorem ipsum dolor sit amet consectetuer adipiscing elit Aenean commodo ligula eget dolor Aenean massa Cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus mus Donec quam felis ultric')
              
        
            })
        
          }


          startdate_less_than_end_date(){
            this.fieldName.clear()
            this.fieldName.type('Field5')
            this.startDate.type('2022-09-09')
            this.endDate.type('2022-09-08')
            this.field_add_button.click()
            this.startDate.invoke('attr', 'title').then(title=>{expect(title).to.eq('Start date should be less than End date')})
            this.startDate.should('have.css','border-color','rgb(255, 0, 0)')
            this.endDate.invoke('attr', 'title').then(title=>{expect(title).to.eq('Start date should be less than End date')})
            this.endDate.should('have.css','border-color','rgb(255, 0, 0)')
          }


          blank_start_date(){
            
            this.fieldName.clear()
            this.startDate.clear()
            this.endDate.clear()
            this.fieldName.type('Field5')
            this.endDate.type('2022-09-08')
            this.field_add_button.click()
            this.startDate.invoke('attr', 'title').then(title=>{expect(title).to.eq('Required')})
            this.startDate.should('have.css','border-color','rgb(255, 0, 0)')
          }


          duplicate_entry(){
            this.fieldName.clear()
            this.fieldName.type('Field1')
            this.startDate.type('2022-09-08')
            this.endDate.type('2022-09-09')
            this.field_add_button.click()
            this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq('Duplicate Entry')})
            this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
          }


          special_character(){
           
            this.fieldName.clear()
            this.startDate.clear()
            this.endDate.clear()
            this.fieldName.type(`,for`)
            this.startDate.type('2022-12-31')
            this.endDate.type('2022-12-31')
            this.field_add_button.click()
            this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
            this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
            this.fieldName.clear()
            this.fieldName.type(`{for`)
            this.startDate.type('2022-12-31')
            this.endDate.type('2022-12-31')
            this.field_add_button.click()
            this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
            this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
            this.fieldName.clear()
            this.fieldName.type(`for}`)
            this.startDate.type('2022-12-31')
            this.endDate.type('2022-12-31')
            this.field_add_button.click()
            this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
            this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
            this.fieldName.clear()
            this.fieldName.type(`()for`)
            this.startDate.type('2022-12-31')
            this.endDate.type('2022-12-31')
            this.field_add_button.click()
            this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
            this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
            this.fieldName.clear()
            this.fieldName.type(`=for`)
            this.startDate.type('2022-12-31')
            this.endDate.type('2022-12-31')
            this.field_add_button.click()
            this.fieldName.invoke('attr', 'title').then(title=>{expect(title).to.eq(',;{}()= tabs and new lines are not allowed')})
            this.fieldName.should('have.css','border-color','rgb(255, 0, 0)')
            this.fieldName.clear()
            this.startDate.clear()
            this.endDate.clear()
          }


          update_button_disabled(){
                this.edit_button.click()
                this.close_button.click()
                this.edit_button.click()
                this.effective_date.type('2030-09-09')
            this.ineffective_date.type('2033-09-09')
            this.mandatory.select('N')
                this.update_button.should('be.disabled')
                this.ineffective_date.click()
                this.update_button.should('be.disabled')
                this.close_button.click()


          }

          update_start_date_higher_than_end_date(){
            this.edit_button.click()
            this.effective_date.type('2050-09-20')
            this.ineffective_date.type('2040-09-20')
            this.mandatory.select('N')
            this.update_button.click()
            this.effective_date_error.should('have.text','Effective date should be less than or equal to Ineffective date')
            this.ineffective_date_error.should('have.text','Ineffective date should be greater than or equal to Effective date')
            this.close_button.click()
            this.edit_button.click()
            this.effective_date.clear()
            this.update_button.click()
            this.effective_date_error.should('have.text','Required Field')
            this.close_button.click()
          }


          updating_a_record(config){
            var month = [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec",
              ]
              cy.wait(2000)
            this.edit_button.click()
            this.effective_date.type('2040-09-20')
            this.ineffective_date.type('2050-09-20')
            this.mandatory.select('N')
            this.update_button.click()
            cy.wait(2000)

            this.grid_data.getAgGridData().then((actualTableData)=>{
        
                cy.log(actualTableData)
          
              
                 
                 
                 expect(actualTableData[3]['Effective Date*']).to.eq(month['2040-09-20'.substring(5,7)*1 -1] +" "+'2040-09-20'.substring(8,10)+", " +'2040-09-20'.substring(0,4))
                 expect(actualTableData[3]['Ineffective Date']).to.eq(month['2050-09-20'.substring(5,7)*1 -1] +" "+'2050-09-20'.substring(8,10)+", " +'2050-09-20'.substring(0,4))
                 expect(actualTableData[3]['Mandatory*']).to.eq('N')
          
              })

              


          }



          updating_a_record_version(config){
            var month = [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec",
              ]
              cy.wait(2000)
            this.edit_button_version.click()
            this.effective_date.type('2040-09-20')
            this.ineffective_date.type('2050-09-20')
            this.mandatory.select('N')
            this.update_button.click()
            cy.wait(2000)

            this.grid_data.getAgGridData().then((actualTableData)=>{
        
                cy.log(actualTableData)
          
              
                 
                 
                 expect(actualTableData[1]['Effective Date*']).to.eq(month['2040-09-20'.substring(5,7)*1 -1] +" "+'2040-09-20'.substring(8,10)+", " +'2040-09-20'.substring(0,4))
                 expect(actualTableData[1]['Ineffective Date']).to.eq(month['2050-09-20'.substring(5,7)*1 -1] +" "+'2050-09-20'.substring(8,10)+", " +'2050-09-20'.substring(0,4))
                 expect(actualTableData[1]['Mandatory*']).to.eq('N')
          
              })

              


          }



          switch_check(config,version){
            cy.wait(2000)
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select * from  cdm_core.templt_switc t where templt_id in (
                  select templt_id from cdm_core.templt t
                  inner join cdm_core.tier2_3_hier ti on ti.tier2_3_hier_id = ti.tier2_3_hier_id
                  where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt' and  t.templt_ver_nm='`+version+`' and ti.tier2_hier_nm='dummy2_sub'  )`
              }).then((result) => {
                
               // cy.log(result.rows[0].switc_cd)
                //cy.log(result.rows[0].switc_val)

                this.switch_name.should('have.value',result.rows[0].switc_cd)
                this.switch_value.should('have.value',result.rows[0].switc_val)



                
              })




             

           

                
          }


          Adding_new_record_switch(){
            cy.wait(3000)
            this.fieldName.clear()
            this.fieldName.type(`Field4`)
            this.startDate.type('2022-12-31')
            this.endDate.type('2023-12-31')
            this.field_add_button.click()
            this.fieldName.clear()
            this.fieldName.type(`Field5`)
            this.startDate.type('2022-12-31')
            this.field_add_button.click()
            this.add_new_switch.click()
            this.new_switch.click()
            this.modal_body_input_1.type('switch_test1')
            this.modal_body_input_2.type('description')
            this.add_button.click()
            cy.wait(2000)
            this.switch_value.first().select('N')
            this.switch_name_1.select('switch_test1')
            this.switch_value.last().select('Y')
            this.update_template_version.first().click()
            cy.wait(1000)
            this.modal_header.should('have.text','Modify Template Version')
            this.modal_body.should('have.text','Template version updated successfully.')
            this.modal_button.click()
            cy.wait(1000)

        }


        checking_backend_entry(config,version){
            var month = [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec",
              ]
            // cy.task("DATABASE", {
            //     dbConfig: Cypress.env(config),
            //     sql: `select t.switc_cd,t.switc_val from  cdm_core.templt_switc t 
            //     where templt_id = (select templt_id from cdm_core.templt where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt')
            //     order by t.switc_cd`
            //   }).then((result) => {
                
            //    // cy.log(result.rows[0].switc_cd)
            //     //cy.log(result.rows[0].switc_val)

            //    expect(result.rows[0].switc_val).to.eq('N')
            //    expect(result.rows[1].switc_cd).to.eq('switch_test1')
            //    expect(result.rows[1].switc_val).to.eq('Y')



                
            //   })


              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `               Select  fld_nm,to_char(fld_eff_dtm,'Mon DD, YYYY') as fld_eff_dtm,case when fld_expr_dtm='3000-01-01T00:00:00+00:00' then '' else  to_char(fld_expr_dtm,'Mon DD, YYYY')  end as fld_expr_dtm    from cdm_core.templt t
                inner join cdm_core.delim_templt_fld_def fl on fl.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = fl.pltfrm_cd 
                and t.dset_cd = fl.dset_cd and fl.tier2_3_hier_id = t.tier2_3_hier_id
                inner join cdm_core.tier2_3_hier ti on fl.tier2_3_hier_id = ti.tier2_3_hier_id
        where fl.dset_cd='dummy4_dataset' and fl.pltfrm_cd='dummy1_plt' and t.templt_ver_nm='`+version+`' and ti.tier2_hier_nm='dummy2_sub' and fl.fld_nm='Field4'`
              }).then((result) => {
                
               // cy.log(result.rows[0].switc_cd)
                //cy.log(result.rows[0].switc_val)

               expect(result.rows[0].fld_nm).to.eq('Field4')
               expect(result.rows[0].fld_eff_dtm).to.eq(month['2022-12-31'.substring(5,7)*1 -1] +" "+'2022-12-31'.substring(8,10)+", " +'2022-12-31'.substring(0,4))
               expect(result.rows[0].fld_expr_dtm).to.eq(month['2023-12-31'.substring(5,7)*1 -1] +" "+'2023-12-31'.substring(8,10)+", " +'2023-12-31'.substring(0,4))



                
              })


              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: ` Select  fld_nm,to_char(fld_eff_dtm,'Mon DD, YYYY') as fld_eff_dtm,case when fld_expr_dtm='3000-01-01T00:00:00+00:00' then '' else  to_char(fld_expr_dtm,'Mon DD, YYYY')  end as fld_expr_dtm    from cdm_core.templt t
                inner join cdm_core.delim_templt_fld_def fl on fl.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = fl.pltfrm_cd 
                and t.dset_cd = fl.dset_cd and fl.tier2_3_hier_id = t.tier2_3_hier_id
                inner join cdm_core.tier2_3_hier ti on fl.tier2_3_hier_id = ti.tier2_3_hier_id
        where fl.dset_cd='dummy4_dataset' and fl.pltfrm_cd='dummy1_plt' and t.templt_ver_nm='`+version+`' and ti.tier2_hier_nm='dummy2_sub' and fl.fld_nm='Field5'`
              }).then((result) => {
                
               // cy.log(result.rows[0].switc_cd)
                //cy.log(result.rows[0].switc_val)

               expect(result.rows[0].fld_nm).to.eq('Field5')
               expect(result.rows[0].fld_eff_dtm).to.eq(month['2022-12-31'.substring(5,7)*1 -1] +" "+'2022-12-31'.substring(8,10)+", " +'2022-12-31'.substring(0,4))
               expect(result.rows[0].fld_expr_dtm).to.eq('')



                
              })

            
        }



        json_schema_existing(config){
            this.platform_dropdown.select('json_plt')
            this.subject_dropdown.select('json_sub')
            this.process_dropdown.select('json_process')
            this.dataset_dropdown.select('json based dataset')
            this.version_dropdown.select('Laptop')


            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select templt.json_schma from  cdm_core.templt where dset_cd='json based dataset' and pltfrm_cd='json_plt'`
              }).then((result) => {


                this.json_text_area.last().then(($el) => {
                    const text = $el.text()
                    expect(text).to.eq(result.rows[0].json_schma)
                })
                
              })



              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select * from  cdm_core.templt_switc t where templt_id = (select templt_id from cdm_core.templt where dset_cd='json based dataset' and pltfrm_cd='json_plt')`
              }).then((result) => {
                
               // cy.log(result.rows[0].switc_cd)
                //cy.log(result.rows[0].switc_val)

                this.switch_name.should('have.value',result.rows[0].switc_cd)
                this.switch_value.should('have.value',result.rows[0].switc_val)



                
              })

            
        }


        xml_schema_existing(config){
            this.platform_dropdown.select('xml_plt')
            this.subject_dropdown.select('xml_sub')
            this.process_dropdown.select('xml_process')
            this.dataset_dropdown.select('xml_dataset')
            this.version_dropdown.select('Laptop')


            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select templt.xml_schma from  cdm_core.templt where dset_cd='xml_dataset' and pltfrm_cd='xml_plt'`
              }).then((result) => {


                this.json_text_area.last().then(($el) => {
                    const text = $el.text()
                    expect(text).to.eq(result.rows[0].xml_schma)
                })
                
              })



              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select * from  cdm_core.templt_switc t where templt_id = (select templt_id from cdm_core.templt where dset_cd='xml_dataset' and pltfrm_cd='xml_plt')`
              }).then((result) => {
                
               // cy.log(result.rows[0].switc_cd)
                //cy.log(result.rows[0].switc_val)

                this.switch_name.should('have.value',result.rows[0].switc_cd)
                this.switch_value.should('have.value',result.rows[0].switc_val)



                
              })

            
        }
        updating_json_schema(config){
            this.platform_dropdown.select('json_plt')
            this.subject_dropdown.select('json_sub')
            this.process_dropdown.select('json_process')
            this.dataset_dropdown.select('json based dataset')
            this.version_dropdown.select('Laptop')
            this.json_text_area.clear()
            this.json_text_area.type('Updated json')
            this.add_new_switch.click()
            this.new_switch.click()
            this.modal_body_input_1.type('switch_test1')
            this.modal_body_input_2.type('description')
            this.add_button.click()
            this.switch_value.first().select('N')
            this.switch_name_1.select('switch_test1')
            this.switch_value.last().select('Y')
            this.update_template_version.first().click()
            cy.wait(1000)
            this.modal_header.should('have.text','Modify Template Version')
            this.modal_body.should('have.text','Template version updated successfully.')
            this.modal_button.click()
            cy.wait(1000)


            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select t.switc_cd,t.switc_val from  cdm_core.templt_switc t 
                where templt_id = (select templt_id from cdm_core.templt where dset_cd='json based dataset' and pltfrm_cd='json_plt')
                order by t.switc_cd`
              }).then((result) => {
                
               // cy.log(result.rows[0].switc_cd)
                //cy.log(result.rows[0].switc_val)

               expect(result.rows[0].switc_val).to.eq('N')
               expect(result.rows[1].switc_cd).to.eq('switch_test1')
               expect(result.rows[1].switc_val).to.eq('Y')



                
              })


              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select templt.json_schma from  cdm_core.templt where dset_cd='json based dataset' and pltfrm_cd='json_plt'`
              }).then((result) => {
                
               // cy.log(result.rows[0].switc_cd)
                //cy.log(result.rows[0].switc_val)

               expect(result.rows[0].json_schma).to.eq('Updated json')



                
              })


        }


        updating_xml_schema(config){
            this.platform_dropdown.select('xml_plt')
            this.subject_dropdown.select('xml_sub')
            this.process_dropdown.select('xml_process')
            this.dataset_dropdown.select('xml_dataset')
            this.version_dropdown.select('Laptop')
            this.json_text_area.clear()
            this.json_text_area.type('Updated xml json')
            this.add_new_switch.click()
            this.new_switch.click()
            this.modal_body_input_1.type('switch_test1')
            this.modal_body_input_2.type('description')
            this.add_button.click()
            this.switch_value.first().select('N')
            this.switch_name_1.select('switch_test1')
            this.switch_value.last().select('Y')
            this.update_template_version.first().click()
            cy.wait(1000)
            this.modal_header.should('have.text','Modify Template Version')
            this.modal_body.should('have.text','Template version updated successfully.')
            this.modal_button.click()
            cy.wait(1000)


            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select t.switc_cd,t.switc_val from  cdm_core.templt_switc t 
                where templt_id = (select templt_id from cdm_core.templt where dset_cd='xml_dataset' and pltfrm_cd='xml_plt')
                order by t.switc_cd`
              }).then((result) => {
                
               // cy.log(result.rows[0].switc_cd)
                //cy.log(result.rows[0].switc_val)

               expect(result.rows[0].switc_val).to.eq('N')
               expect(result.rows[1].switc_cd).to.eq('switch_test1')
               expect(result.rows[1].switc_val).to.eq('Y')



                
              })


              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select templt.xml_schma from  cdm_core.templt where dset_cd='xml_dataset' and pltfrm_cd='xml_plt'`
              }).then((result) => {
                
               // cy.log(result.rows[0].switc_cd)
                //cy.log(result.rows[0].switc_val)

               expect(result.rows[0].xml_schma).to.eq('Updated xml json')



                
              })


        }


       


        checking_inactive_button(config){
          cy.wait(2000)
          this.active_button.last().should('have.css', 'background-color', 'rgb(255, 255, 255)')
          
           this.active_button.last().click()
          // this.active_button.should('have.css', 'background-color', 'rgb(255, 255, 255)')
          cy.wait(1000)
          cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `select count(*) as cnt from cdm_core.delim_templt_fld_def where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt'
            and fld_nm='Field3' and actv_ind='Y'`
          }).then((result) => {
           expect(result.rows[0].cnt).to.eq('1')
          })
          cy.wait(1000)
          this.active_button.last().should('have.css', 'background-color', 'rgb(0, 104, 181)')
          cy.wait(1000)
          this.active_button.last().click()

        }


        Inactivate_template(config){

          this.update_template_version.last().should('have.text','Inactivate')
          this.update_template_version.last().click()
          this.modal_cancel_button.click()
          this.update_template_version.last().click()
          this.modal_header.should('have.text','Confirm Inactivation')
          this.modal_body.should('have.text','Clicking on Inactivate button will make the Template Version inactive. To make the Template Version Active, please go to the "Modify Template" screen, select the Template and click on Activate button')
          this.modal_button.last().should('have.text','Inactivate')
          this.modal_button.last().click()
          // cy.task("DATABASE", {
          //   dbConfig: Cypress.env(config),
          //   sql: `select count(*) as cnt from cdm_core.templt where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt' and actv_ind='N'`
          // }).then((result) => {
          //  expect(result.rows[0].cnt).to.eq('1')
          // })

         // this.template_isinactive.should('have.text','Template is Inactive')
         // this.template_isinactive_2.should('have.text','Template is Inactive')
       //  this.field_add_button.should('be.disabled')
        // this.add_new_switch.should('be.disabled')
         this.update_template_version.first().should('be.disabled')
         this.fields_section.should('have.css', 'background-color', 'rgba(250, 250, 250, 0.52)')
        this.switch_section.should('have.css', 'background-color', 'rgba(250, 250, 250, 0.52)')

        }


        activate_template(config){
          //this.template_isinactive.should('have.text','Template is Inactive')
         // this.template_isinactive_2.should('have.text','Template is Inactive')
        // this.field_add_button.should('be.disabled')
        // this.add_new_switch.should('be.disabled')
          this.update_template_version.last().should('have.text','Activate')
          this.update_template_version.last().click()
          this.modal_cancel_button.click()
          this.update_template_version.last().click()
          this.modal_header.should('have.text','Confirm Activation')
          this.modal_body.should('have.text','Clicking on Activate button will make the Template Version active. To make the Template Version Inactive, please go to the "Modify Template" screen, select the Template and click on Inactivate button.')
          this.modal_button.last().should('have.text','Activate')
          this.modal_button.last().click()
          // cy.task("DATABASE", {
          //   dbConfig: Cypress.env(config),
          //   sql: `select count(*) as cnt from cdm_core.templt where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt' and actv_ind='Y'`
          // }).then((result) => {
          //  expect(result.rows[0].cnt).to.eq('1')
          // })

          this.add_new_switch.should('have.css', 'background-color', 'rgb(0, 104, 181)')

        }


        activate_template_version(){
          this.add_new_switch.should('have.css', 'background-color', 'rgb(0, 104, 181)')
        }

        localisation_test(config){
          cy.wait(2000)
          this.fieldName.clear()
            this.fieldName.type(`維涅什`)
            this.startDate.type('2022-12-31')
            this.field_add_button.click()
            this.fieldName.type(`виньеш`)
            this.startDate.type('2022-12-31')
            this.field_add_button.click()
            this.update_template_version.first().click()
            cy.wait(1000)
            this.modal_header.should('have.text','Modify Template Version')
            this.modal_body.should('have.text','Template version updated successfully.')
            this.modal_button.click()
            cy.wait(1000)

            cy.task("DATABASE", {
              dbConfig: Cypress.env(config),
              sql: `select count(*) as cnt from cdm_core.delim_templt_fld_def where dset_cd='dummy4_dataset' and pltfrm_cd='dummy1_plt' and fld_nm in ('維涅什','виньеш')`
            }).then((result) => {
             expect(result.rows[0].cnt).to.eq('2')
            })



            
        }

        is_active_todays_date(){
          var month = [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
          ]

          let d = new Date()
          let mon = d.getMonth()
          this.active_button_1.click()

          cy.wait(3000)
          this.ineffective_date_first_row.first().then(($el) => {
              let latest_date = $el.text()

            //  console.log(month[mon]+' '+d.getDate()+', '+d.getFullYear())
             // console.log(latest_date)

              expect(latest_date).to.eq(month[mon]+' '+String(d.getDate()).padStart(2,'0')+', '+d.getFullYear())
          })



          this.active_button_1.click()

          cy.wait(3000)

          this.ineffective_date_first_row.first().then(($el) => {
            let latest_date = $el.text()

          //  console.log(month[mon]+' '+d.getDate()+', '+d.getFullYear())
           // console.log(latest_date)

            expect(latest_date).to.eq('')


            this.active_button_1.click()
        })

        
        }

        inactive_button_future_date(){

          let d = new Date()
          let mon = d.getMonth()

          this.active_button_2.click()
          cy.wait(3000)
          this.edit_button_2.click()
          this.ineffective_date.type((d.getFullYear()+1)+'-10-20')

          this.update_button.click()

          this.active_button_2.should('have.css', 'background-color', 'rgb(0, 104, 181)')
        }


        new_record_past_ineffective_date(){
          let d = new Date()
          let mon = d.getMonth()
          cy.wait(2000)
          this.fieldName.clear()
            this.fieldName.type(`Field100`)
            this.startDate.type((d.getFullYear()-1)+'-10-20')
            this.endDate.type(String(d.getFullYear())+'-'+String(d.getMonth()-1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'))
            this.field_add_button.click()

            this.active_button_4.should('have.css', 'background-color', 'rgb(255, 255, 255)')

            this.active_button_4.click()

            cy.wait(3000)


        this.ineffective_date_last_row.first().then(($el) => {
            let latest_date = $el.text()

          //  console.log(month[mon]+' '+d.getDate()+', '+d.getFullYear())
           // console.log(latest_date)

            expect(latest_date).to.eq('')


          //  this.active_button_1.click()
        })

        }


  }
  
  export default new ModifyTemplate();
  