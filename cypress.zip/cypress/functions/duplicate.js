// ************************ Duplicate Tab Function definitions***********************************
// This file contains all the function definitions and css selectors used for testing the Duplicate tab
// Created by Vignesh Sekar
// 
// Css Selectors - CSS selectors is used for locating the elements in UI screen
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking the Title and Description of the Duplicate tab
// 2.Verifying the column level filter is working for all the columns in the grid
// 3.Sorting the grid using uploaded date
// 4.Pagination
// 5.Grid Data Validation
// 6.Accept and Reject Functionality
// 7.Role based check for the Grid data and buttons in the duplicate grid


const now = Math.floor(Date.now() / 1000);
import { decode } from "jsonwebtoken";

let envi = Cypress.env('ENV');
console.log(envi)
const env_var = require('../support/environment')

const url = env_var.getBaseUrl(envi);
const tenant_id = env_var.getTenantID(envi);
const client_id = env_var.getClientID(envi);
const client_secret = env_var.getClientSecret(envi);
const scope = env_var.getScope(envi);
const resource = env_var.getResource(envi);
const sessionStorage_1_key = env_var.getSessionStorage_1_key(envi);
const sessionStorage_1_value1 = env_var.getSessionStorage_1_value1(envi);
const sessionStorage_1_value2 = env_var.getSessionStorage_1_value2(envi);
const sessionStorage_2_key = env_var.getSessionStorage_2_key(envi);
const sessionStorage_2_value = env_var.getSessionStorage_2_value(envi);

const { encrypt, decrypt } = require('../e2e/crypto')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));

console.log(decrypt(tenant_id))

class duplicate{


  get dataset_menu(){
    return cy.xpath('//*[@id="datasetDropdown"]')
}



  get historical_data(){
    return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[2]')
  }

  get historical_data_1(){
    return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[1]')
  }

  get duplicate_tab(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tab-Duplicate"]')
  }

  get heading(){
    return cy.xpath('//*[@id="root"]/div[2]/main/h3')
  }

  get subheading(){
    return cy.xpath('//*[@id="root"]/div[2]/main/span')
  }


  get filter_all(){
    return {
      file_ref_id:'#uncontrolled-tab-example-tabpane-Duplicate>div:nth-of-type(2)>div>div>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>.ag-header-cell:nth-of-type(3)>div:nth-of-type(3)>.ag-header-icon',
      partner:'#uncontrolled-tab-example-tabpane-Duplicate>div:nth-of-type(2)>div>div>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>.ag-header-cell:nth-of-type(4)>div:nth-of-type(3)>.ag-header-icon',
        dataset:'#uncontrolled-tab-example-tabpane-Duplicate>div:nth-of-type(2)>div>div>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>.ag-header-cell:nth-of-type(5)>div:nth-of-type(3)>.ag-header-icon',
    filename:'#uncontrolled-tab-example-tabpane-Duplicate>div:nth-of-type(2)>div>div>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>.ag-header-cell:nth-of-type(6)>div:nth-of-type(3)>.ag-header-icon',
    uploaded_date:'#uncontrolled-tab-example-tabpane-Duplicate>div:nth-of-type(2)>div>div>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>.ag-header-cell:nth-of-type(7)>div:nth-of-type(3)>.ag-header-icon',
    uploaded_by:'#uncontrolled-tab-example-tabpane-Duplicate>div:nth-of-type(2)>div>div>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>.ag-header-cell:nth-of-type(8)>div:nth-of-type(3)>.ag-header-icon',
    
    upload_mode:'#uncontrolled-tab-example-tabpane-Duplicate>div:nth-of-type(2)>div>div>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>.ag-header-cell:nth-of-type(9)>div:nth-of-type(3)>.ag-header-icon',
    duplicate_row_count:'#uncontrolled-tab-example-tabpane-Duplicate>div:nth-of-type(2)>div>div>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>.ag-header-cell:nth-of-type(10)>div:nth-of-type(3)>.ag-header-icon',
    validation_report:'#uncontrolled-tab-example-tabpane-Duplicate>div:nth-of-type(2)>div>div>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>.ag-header-cell:nth-of-type(11)>div:nth-of-type(3)>.ag-header-icon'
  }
  }


  get filter_body(){
    return cy.get('.ag-filter-body>div>div>.ag-input-field-input.ag-text-field-input')
}


get pagecount_button(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>div>div>div>div:nth-of-type(2)>span>span:nth-of-type(5)')
}

get page_number(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>span>span:nth-of-type(2)')
  }

  get total_page(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>span>span:nth-of-type(4)')
  }

  get lastpage(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>div:nth-of-type(4)')
}

get firstpage(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>div:nth-of-type(1)')
}

get nextpage(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>div:nth-of-type(3)')
}

get prevpage(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>div:nth-of-type(2)')
}

get firstrow_on_page(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(1)>span:nth-of-type(1)')
  }

  get lastrow_on_page(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(1)>span:nth-of-type(3)')
  }

  get page_size(){
    return cy.get('#uncontrolled-tab-example-tabpane-Duplicate>div>span>#page-size')
  }


  get ag_grid(){
    return  cy.get('#uncontrolled-tab-example-tabpane-Duplicate')

}

get uploadedDate_header(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-Duplicate"]/div[2]/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div/div[7]/div[3]/div')
}


get file_link(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-Duplicate"]/div[2]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[1]/div[11]/span')
}


get duplicate_row_count(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-Duplicate"]/div[2]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[1]/div[10]')
}


get file_ref_id (){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-Duplicate"]/div[2]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[1]/div[3]')
}


get check_box_1(){
return cy.get('#uncontrolled-tab-example-tabpane-Duplicate .ag-center-cols-clipper .ag-row-even:nth-of-type(1) input')
}
get check_box_2(){
return cy.get('#uncontrolled-tab-example-tabpane-Duplicate .ag-center-cols-clipper .ag-row-even:nth-of-type(3) input')
}

get reject_button(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-Duplicate"]/div[1]/div/button[2]')
}


get accept_button(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-Duplicate"]/div[1]/div/button[1]')
}

get History_Tab(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tab-History"]')
}


get filter_body(){
  return cy.get('.ag-filter-body>div>div>.ag-input-field-input.ag-text-field-input')
}

get file_status(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-History"]/div[3]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[1]/div[12]')
}

get duplicate_ind(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-History"]/div[3]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div/div[10]')
}

get modal_header(){
  return cy.xpath('/html/body/div[7]/div/div/div[2]/div/h5')
}

get cancel_button(){
  return cy.xpath('/html/body/div[7]/div/div/div[3]/button[1]')
}

get confirm_button(){
  return cy.xpath('//*[@id="btn"]')
}

get close_button(){
  return cy.xpath('/html/body/div[7]/div/div/div[1]/button')
}


get textarea(){
  return cy.xpath('//*[@id="formBasicEmail"]')
}

get processing_grid_first_row(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-Processing"]/div/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[1]/div[1]')
}

get processing_tab(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tab-Processing"]')
}

get user_nm(){
  return cy.xpath('//*[@id="userSignOutDropdown"]/div')
}




/// ************** Methods  **********************//


launching_consumer_data() {
  //console.log(tenant_id)
  
  //console.log(decrypt(tenant_id))
  

  cy.request({method: 'POST',
  url: 'https://login.microsoftonline.com/'+decrypt(tenant_id)+'/oauth2/token', 
  form: true, 
  body: {
      client_id: decrypt(client_id),
      client_secret: decrypt(client_secret),
      grant_type: "client_credentials",
      scope:decrypt(scope),
      resource:decrypt(resource)
     
  },
}).then(
(response) => {
  console.log(response.body.access_token)
  console.log(now.toString())
  console.log((now + Number(response.body.expires_in)).toString())
  console.log(decode(response.body.access_token))
sessionStorage.setItem(decrypt(sessionStorage_1_key),decrypt(sessionStorage_1_value1)+response.body.access_token +'","cachedAt":"'+now.toString()+'","expiresOn":"'+((now + Number(response.body.expires_in)).toString())+'","extendedExpiresOn":"'+((now + Number(response.body.expires_in)).toString())+decrypt(sessionStorage_1_value2))
sessionStorage.setItem(decrypt(sessionStorage_2_key),decrypt(sessionStorage_2_value));




})

cy.visit(url);
cy.wait(10000)

}

  duplicate_tab_section(){
    this.dataset_menu.click()
    this.historical_data.should('have.text','Historical Data')
    this.historical_data.click()
    cy.wait(3000)
    this.duplicate_tab.should('have.text','Duplicate')
    this.duplicate_tab.click()

}


duplicate_tab_section_1(){
  this.dataset_menu.click()
  this.historical_data_1.should('have.text','Historical Data')
  this.historical_data_1.click()
  cy.wait(3000)
  this.duplicate_tab.should('have.text','Duplicate')
  this.duplicate_tab.click()

}


heading_subheading(){
    this.heading.should('have.text','Historical Data')
    this.subheading.should('have.text','All duplicate files will be available in the Duplicate section.')
}

grid_columns_Validation(columns){
    cy.wait(2000)
    for (let i = 0; i < 10; i++) {
        let j = i + 1;
        cy.get(
          ".ag-header-row>.ag-header-cell:nth-of-type(" +
            j +
            ")>div:nth-of-type(3)>div>span:nth-of-type(1)"
        )
          .last()
          .should("have.text", columns[i]);
      }
}


filter_allcolumns(getvalues,filter,query,config){
    cy.get(getvalues).last().click()
    this.filter_body.eq(0).type(filter)
    this.duplicate_tab.click()
    cy.task("DATABASE", {
        dbConfig: config,
        sql: query
      }).then((result) => {
          this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)

      })
      cy.get(getvalues).first().click()
    this.filter_body.eq(0).clear()
    this.duplicate_tab.click()

    
}

action_pagination(){
    cy.wait(3000)
    this.pagecount_button.last().then(($el) => {
        const overall_count = $el.text()

        cy.log(overall_count)

        if(overall_count<=5){
            this.page_number.contains('1')
            this.total_page.contains('1')
           // this.prevpage.should('be.disabled')
            //this.firstpage.should('be.disabled')
            //this.nextpage.should('be.disabled')
            //this.lastpage.should('be.disabled')

            this.ag_grid.getAgGridData().then((actualTableData)=>{
          
                this.firstrow_on_page.last().contains('1')
                this.lastrow_on_page.last().contains(actualTableData.length)
                
              })

        }

        else {

            if(overall_count>5 && overall_count<=10){
                this.pagination(5)

            }

            if(overall_count>10 && overall_count<= 15){
                this.pagination(5)
                this.pagination(10)
                
            }

            if(overall_count>15 && overall_count <=20){
                this.pagination(5)
                this.pagination(10)
                this.pagination(15)
            }

            if(overall_count>20){
                this.pagination(5)
                this.pagination(10)
                this.pagination(15)
                this.pagination(20)

            }

        }
    })
}


pagination(pagesize){
  if(pagesize==10){
    this.page_size.last().select('10')
  }
  else if(pagesize==5){
    this.page_size.last().select('5')
  }
  else if(pagesize==15){
    this.page_size.last().select('15')
  }
  else if(pagesize=20){
    this.page_size.last().select('20')
  }
  this.pagecount_button.last().then(($el) => {
    let gridData=[];
    const overall_count = $el.text()
    
    let page_count=Math.floor((overall_count)/pagesize)
    let remainder = overall_count%pagesize
    
   
    if(remainder>0){
      page_count=page_count+1
    }

    if(remainder==0){remainder=pagesize}else{remainder=remainder}
    

    console.log(page_count)
    let j=1;
    

    for(let i=0;i<page_count;i++){
      cy.wait(1000)
      this.ag_grid.getAgGridData().then((actualTableData)=>{
        
        gridData=gridData.concat(actualTableData)
        console.log(gridData)
        
      })

      
      
      this.page_number.last().contains(i+1)
      this.total_page.last().contains(page_count)
      this.firstrow_on_page.last().contains(j)
      if(i==page_count-1){
        this.lastrow_on_page.last().contains(overall_count)
        this.ag_grid.getAgGridData().then((actualTableData)=>{
          //console.log(actualTableData)
          //console.log(remainder)
          expect(actualTableData.length).to.eq(remainder)
          expect(gridData.length).to.eq(parseInt(overall_count))
        })
      }
      else{
        
        this.lastrow_on_page.last().contains((i+1)*pagesize)
        this.ag_grid.getAgGridData().then((actualTableData)=>{
          expect(actualTableData.length).to.eq(pagesize)
        })
      }
      
      this.pagecount_button.last().contains(overall_count)
      this.nextpage.last().click()
      j+=pagesize

      
      


    }




    

    

  })

 this.firstpage.last().click()
 this.page_size.last().select('10')
}


griddata(query,config){

  cy.wait(3000)

  this.total_page.last().then(($el) => {
    let gridData=[];

    const page_count = $el.text()

    for(let i=0;i<page_count;i++){

      this.ag_grid.getAgGridData().then((actualTableData)=>{
        
        gridData=gridData.concat(actualTableData)
        

        if(i==page_count-1){
          console.log(gridData)
          cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: query
          }).then((result) => {

            console.log(result.rows)

            expect(result.rows.length).to.eq(gridData.length)
           

            for(let i=0;i<result.rows.length;i++){
              expect(result.rows[i]["partner"]).to.eq(gridData[i]["Partner"])
              expect(result.rows[i]["dataset"]).to.eq(gridData[i]["Dataset"])
              expect(result.rows[i]["file_name"]).to.eq(gridData[i]["File Name"])
              expect(result.rows[i]["uploaded_date"]).to.eq(gridData[i]["Uploaded Date (UTC)"])
              expect(result.rows[i]["uploaded_by"]).to.eq(gridData[i]["Uploaded By"])
              expect(result.rows[i]["upload_mode"]).to.eq(gridData[i]["Upload Mode"])
              expect(result.rows[i]["duplicate_row_count"]).to.eq((gridData[i]["Duplicate Row Count"]))
              expect(result.rows[i]["validation_report"]).to.eq((gridData[i]["Validation Report"]))

            }

          })
        }
        
      })

      this.nextpage.last().click()

    }

    

  })

  this.firstpage.last().click()
  

}


sorting(config,query,sort_order){
      
  if(sort_order=='ascending'){
    this.uploadedDate_header.click()
    cy.wait(1000)
  }


  if(sort_order=='descending'){
    this.uploadedDate_header.click()
    this.uploadedDate_header.click()
    cy.wait(1000)
  }
    


  
  
  cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: query
    }).then((result) => {
      
      const db_uploaded_date_first = result.rows[0]
      const db_uploaded_date_last = result.rows[result.rows.length-1]
      

      this.ag_grid.getAgGridData().then((actualTableData)=>{
          const grid_uploaded_date_first = actualTableData[0]
          expect(grid_uploaded_date_first['File Name']).to.eq(db_uploaded_date_first.file_name)
          //expect(grid_uploaded_date_first['File Reference Id']).to.eq(db_uploaded_date_first.file_ref_id)
      })

      this.lastpage.click()

      this.ag_grid.getAgGridData().then((lastpagedata)=>{
          const grid_uploaded_date_last = lastpagedata[lastpagedata.length-1]
          expect(grid_uploaded_date_last['File Name']).to.eq(db_uploaded_date_last.file_name)
         // expect(grid_uploaded_date_last['File Reference Id']).to.eq(db_uploaded_date_last.file_ref_id)

      })

      this.firstpage.click()

    })


    if(sort_order=='ascending'){
      this.uploadedDate_header.click()
      this.uploadedDate_header.click()
      cy.wait(1000)
    }
  
  
    if(sort_order=='descending'){
      this.uploadedDate_header.click()
      cy.wait(1000)
    }

}






read_csv(filePath){
  cy.wait(6000)
  
  this.file_link.then(($el) => {
    const file_name = $el.text()
    const regex =/:/g
    const newFileName = file_name.replaceAll(regex,"_")
    const excelFilePath=filePath+newFileName

    
  cy.task("readCSVfile_export",excelFilePath).then((result)=>{

    this.duplicate_row_count.then(($el)=>{
      const rows = $el.text()
      const rowsloaded = (rows.substring(0,rows.indexOf('o')))
      expect(parseInt(rowsloaded)).to.eq(result)
    })
    
  })
  
  

  })
  
  
}


validation_report(deletefilepath){
  cy.task("deletefile", deletefilepath, (result) => {
    cy.log(result);
  });


  //cy.wait(3000)
  this.file_link.click()

  //this.validation_report_link.click()

  //this.read_csv('')

  cy.wait(5000)

  this.file_link.then(($el)=>{
    const report_name = $el.text()

    this.read_csv("./cypress/downloads/")

  })


}

report_icon(){


  this.lastrow_on_page.then(($el)=>{
    for (let i=1;i<=$el.text();i++){
      cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-Duplicate"]/div[2]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div['+i+']/div[2]/i').should('be.visible')
    }
  })
  
}


reject(config){
  cy.on("uncaught:exception", (err, runnable) => {
    return false;
  });
  cy.wait(1000)
  this.check_box_1.click()
  this.check_box_1.should('be.checked')
  this.check_box_2.click()
  this.check_box_1.should('not.be.checked')
  this.check_box_2.should('be.checked')
  this.check_box_1.click()
  cy.wait(1000)
this.reject_button.should('be.enabled')
this.reject_button.should('have.text','Reject')
this.accept_button.should('be.enabled')
this.accept_button.should('have.text','Accept')


    this.file_ref_id.then(($el)=>{
      this.reject_button.click()
      cy.wait(2000)
      //cy.visit('https://customerdata-dev.intel.com/')
      this.launching_consumer_data()

     // cy.wait(10000)
      this.duplicate_tab_section_1()
      this.History_Tab.click()
      
        cy.get('.ag-header-cell:nth-of-type(2)>div:nth-of-type(3)>.ag-header-icon').first().click()
        this.filter_body.eq(0).type($el.text())
        this.History_Tab.click()


        this.file_status.should('have.text','Confirmed Duplicate')

        this.duplicate_ind.should('have.text','Y')
        // this.file_status.then(($vl)=>{
        //   this.file
        // })

        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: `update cdm_core.file_onbord_instc set latst_onbord_sts_cd ='CDM_Duplicate' where file_ref_id like '%`+$el.text()+`%'`
        }).then((result) => {

        })


        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: `update cdm_core.file_onbord_sub_instc set latst_onbord_sts_cd ='CDM_Duplicate' where file_instc_id = (select file_instc_id from cdm_core.file_onbord_instc where file_ref_id like '%`+$el.text()+`%')`
        }).then((result) => {

        })



    })


    cy.get('.ag-header-cell:nth-of-type(2)>div:nth-of-type(3)>.ag-header-icon').first().click()
        this.filter_body.eq(0).clear()
}


accept(config){
  cy.wait(1000)
  this.check_box_1.click()
  this.check_box_1.should('be.checked')
  this.check_box_2.click()
  this.check_box_1.should('not.be.checked')
  this.check_box_2.should('be.checked')
  this.check_box_1.click()
  cy.wait(1000)
this.reject_button.should('be.enabled')
this.reject_button.should('have.text','Reject')
this.accept_button.should('be.enabled')
this.accept_button.should('have.text','Accept')

this.file_ref_id.then(($el)=>{
    
      this.accept_button.click()
      cy.wait(2000)

      this.cancel_button.should('have.text','Cancel')
      this.confirm_button.should('have.text','Confirm')
      this.confirm_button.should('be.disabled')
      this.cancel_button.click()
      this.accept_button.click()
      this.close_button.click()
      this.accept_button.click()
      this.textarea.type('Duplicate')
      this.confirm_button.should('be.enabled')

      this.confirm_button.click()

      cy.wait(10000)
      
      //this.launching_consumer_data()

      //this.duplicate_tab_section()

      this.processing_tab.click()

      cy.wait(5000)

      this.processing_grid_first_row.should('have.text',$el.text())

      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `update cdm_core.file_onbord_instc set latst_onbord_sts_cd ='CDM_Duplicate' where file_ref_id like '%`+$el.text()+`%'`
      }).then((result) => {

      })


      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `update cdm_core.file_onbord_sub_instc set latst_onbord_sts_cd ='CDM_Duplicate' where file_instc_id = (select file_instc_id from cdm_core.file_onbord_instc where file_ref_id like '%`+$el.text()+`%')`
      }).then((result) => {

      })

})
}


role_change(config,role_id){
  this.user_nm.first().then(($el) => {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql:` update cdm_accs_enttl.prncpl_role_asgn set role_id=`+role_id+` where prncpl_id = (select prncpl_id from cdm_accs_enttl.usr where usr_nm='`+$el.text().trim()+`')`

    })
  })
  

}


data_count(config){

  cy.task("DATABASE", {
    dbConfig: Cypress.env(config),
    sql:`
    select count(*) as cnt
    from 
       cdm_core.file_onbord_instc fil
         inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                inner join cdm_accs_enttl.org org on org.org_id=pl.org_id  
    where fil.latst_onbord_sts_cd  in ('CDM_Duplicate')`

  }).then((result) => {
    this.pagecount_button.first().then(($el) => {
        const overall_count = $el.text()

    expect(result.rows[0].cnt).to.eq(overall_count)

    })

})

}

buttons_visible(){
  this.reject_button.should('be.visible')
  this.accept_button.should('be.visible')
}

buttons_not_visible(){
  this.reject_button.should('not.exist');
  this.accept_button.should('not.exist');
}


grid_count_org(config){
          
  this.pagecount_button.first().then(($el) => {
    const overall_count = $el.text()

    this.user_nm.then(($us)=>{
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `select count(*) as cnt
        from cdm_core.file_onbord_instc fil 
inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
where fil.latst_onbord_sts_cd in ('CDM_Duplicate')
 and org.org_nm = ( select org.org_nm from cdm_accs_enttl.usr usr 
 inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id inner join cdm_accs_enttl.org org on org.org_id=pl.org_id where usr_nm='`+$us.text().trim()+`')`
      }).then((result) => {
        expect(result.rows[0].cnt).to.eq(overall_count)
      })
    })
 

})
}




}





export default new duplicate()