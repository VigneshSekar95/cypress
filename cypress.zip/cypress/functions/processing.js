

class processing{

  get dataset_menu(){
    return cy.xpath('//*[@id="datasetDropdown"]')
  }

  get historical_data() {
    return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[1]')
  }

  get historical_data_1() {
    return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[2]')
  }


    get InprocessTab(){
        return cy.get('#uncontrolled-tab-example-tab-Processing')
    }

    get subdescription(){
        return cy.xpath('//*[@id="root"]/div[2]/main/span')
    }


    get ag_grid(){
        return  cy.get('#uncontrolled-tab-example-tabpane-Processing')

    }

    
    get pagecount_button(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>div>div>div>div>div:nth-of-type(2)>span>span:nth-of-type(5)')
    }

    get page_number(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>span>span:nth-of-type(2)')
      }
  
      get total_page(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>span>span:nth-of-type(4)')
      }

      get lastpage(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>div:nth-of-type(4)')
    }

    get firstpage(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>div:nth-of-type(1)')
    }

    get nextpage(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>div:nth-of-type(3)')
    }

    get prevpage(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(2)>div:nth-of-type(2)')
    }

    get firstrow_on_page(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(1)>span:nth-of-type(1)')
      }
  
      get lastrow_on_page(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>div>div>div>div>div:nth-of-type(2)>span:nth-of-type(1)>span:nth-of-type(3)')
      }

      get page_size(){
        return cy.get('#uncontrolled-tab-example-tabpane-Processing>span>#page-size')
      }

      get status_data(){
        return cy.get('.ag-center-cols-clipper>div>div>div:nth-of-type(1)>div:nth-of-type(7)')
      }


      get enriched_data(){
        return cy.get('.ag-center-cols-clipper>div>div>div:nth-of-type(1)>div:nth-of-type(9)')
      }

      get validation_data(){
        return cy.get('.ag-center-cols-clipper>div>div>div:nth-of-type(1)>div:nth-of-type(8)')
      }


      get filter_all(){
        return {partner:'//*[@id="uncontrolled-tab-example-tabpane-Processing"]/div/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/div[3]/span/span',
        status:'//*[@id="uncontrolled-tab-example-tabpane-Processing"]/div/div/div/div/div[1]/div[2]/div[1]/div[2]/div/div/div[7]/div[3]/span/span'
        
  
      }
      }

      

      get filter_body(){
        return cy.get('.ag-filter-body>div>div>.ag-input-field-input.ag-text-field-input')
    }


    get user_nm(){
      return cy.xpath('//*[@id="userSignOutDropdown"]/div')
    }




    set_status(query,config){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: query
          }).then((result) => {
    
          })
    
        }


        set_status_failed(query,config){
          cy.task("DATABASE", {
              dbConfig: Cypress.env(config),
              sql: query
            }).then((result) => {
              cy.wait(5000)
              this.status_data.last().then(($el) => {
                expect($el.text()).to.eq('Internal Fail')
              })
      
            })
      
          }


         enriched_file_data(query,config){
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: query
              }).then((result) => {
                cy.wait(6000)
                this.enriched_data.last().then(($el) => {
                  expect($el.text()).to.eq('Vignesh.csv')
                })
        
              })
        
            }


            valdiation_report_data(query,config){
              cy.task("DATABASE", {
                  dbConfig: Cypress.env(config),
                  sql: query
                }).then((result) => {
                  cy.wait(6000)
                  this.enriched_data.last().then(($el) => {
                    expect($el.text()).to.eq('Vignesh.csv')
                  })
          
                })
          
              }


        InprocessTab_validation(title,description){
            this.InprocessTab.click()
            this.InprocessTab.contains(title)
            this.subdescription.contains(description)
            
    
        }


        uploadHistoryButton_click() {
          this.dataset_menu.click()
          this.historical_data.should('have.text','Historical Data')
          this.historical_data.click()
        }


        uploadHistoryButton_click_1() {
          this.dataset_menu.click()
          this.historical_data_1.should('have.text','Historical Data')
          this.historical_data_1.click()
        }

       // #uncontrolled-tab-example-tabpane-Processing > div > div > div > div > div.ag-root-wrapper-body.ag-focus-managed.ag-layout-auto-height > div.ag-root.ag-unselectable.ag-layout-auto-height > div.ag-header.ag-pivot-off > div.ag-header-viewport > div > div > div:nth-child(4) > div.ag-cell-label-container.ag-header-cell-sorted-none > div > span.ag-header-cell-text
       // #uncontrolled-tab-example-tabpane-Processing > div > div > div > div > div.ag-root-wrapper-body.ag-focus-managed.ag-layout-auto-height > div.ag-root.ag-unselectable.ag-layout-auto-height > div.ag-header.ag-pivot-off > div.ag-header-viewport > div > div > div:nth-child(5) > div.ag-cell-label-container.ag-header-cell-sorted-none > div > span.ag-header-cell-text
        columns_validaiton(columns){
            for(let i=1; i<columns.length;i++){
                //let j=i+1
                // if(i==3){
                //   continue;
                // }
                cy.get('#uncontrolled-tab-example-tabpane-Processing > div > div > div > div > div.ag-root-wrapper-body.ag-focus-managed.ag-layout-auto-height > div.ag-root.ag-unselectable.ag-layout-auto-height > div.ag-header.ag-pivot-off > div.ag-header-viewport > div > div > div:nth-child('+i+') > div.ag-cell-label-container.ag-header-cell-sorted-none > div > span.ag-header-cell-text').first().should('have.text',columns[i])
              }


              this.ag_grid.getAgGridData().then((actualTableData)=>{
                
                console.log(actualTableData)
                expect(Object.keys(actualTableData[0]).length).to.eq(columns.length-1)
                
              })
    
        }


        action_pagination(){
          cy.wait(3000)
          this.pagecount_button.last().then(($el) => {
              const overall_count = $el.text()
  
              cy.log(overall_count)
  
              if(overall_count<=5){
                  this.page_number.contains('1')
                  this.total_page.contains('1')
                 // this.prevpage.should('be.disabled')
                  //this.firstpage.should('be.disabled')
                  //this.nextpage.should('be.disabled')
                  //this.lastpage.should('be.disabled')
  
                  this.ag_grid.getAgGridData().then((actualTableData)=>{
                
                      this.firstrow_on_page.last().contains('1')
                      this.lastrow_on_page.last().contains(actualTableData.length)
                      
                    })
  
              }
  
              else {
  
                  if(overall_count>5 && overall_count<=10){
                      this.pagination(5)
  
                  }
  
                  if(overall_count>10 && overall_count<= 15){
                      this.pagination(5)
                      this.pagination(10)
                      
                  }
  
                  if(overall_count>15 && overall_count <=20){
                      this.pagination(5)
                      this.pagination(10)
                      this.pagination(15)
                  }
  
                  if(overall_count>20){
                      this.pagination(5)
                      this.pagination(10)
                      this.pagination(15)
                      this.pagination(20)
  
                  }
  
              }
          })
      }


      pagination(pagesize){
        if(pagesize==10){
          this.page_size.last().select('10')
        }
        else if(pagesize==5){
          this.page_size.last().select('5')
        }
        else if(pagesize==15){
          this.page_size.last().select('15')
        }
        else if(pagesize=20){
          this.page_size.last().select('20')
        }
        this.pagecount_button.last().then(($el) => {
          let gridData=[];
          const overall_count = $el.text()
          
          let page_count=Math.floor((overall_count)/pagesize)
          let remainder = overall_count%pagesize
          
         
          if(remainder>0){
            page_count=page_count+1
          }
  
          if(remainder==0){remainder=pagesize}else{remainder=remainder}
          
  
          console.log(page_count)
          let j=1;
          
  
          for(let i=0;i<page_count;i++){
            cy.wait(1000)
            this.ag_grid.getAgGridData().then((actualTableData)=>{
              
              gridData=gridData.concat(actualTableData)
              console.log(gridData)
              
            })
  
            
            
            this.page_number.last().contains(i+1)
            this.total_page.last().contains(page_count)
            this.firstrow_on_page.last().contains(j)
            if(i==page_count-1){
              this.lastrow_on_page.last().contains(overall_count)
              this.ag_grid.getAgGridData().then((actualTableData)=>{
                //console.log(actualTableData)
                //console.log(remainder)
                expect(actualTableData.length).to.eq(remainder)
                expect(gridData.length).to.eq(parseInt(overall_count))
              })
            }
            else{
              
              this.lastrow_on_page.last().contains((i+1)*pagesize)
              this.ag_grid.getAgGridData().then((actualTableData)=>{
                expect(actualTableData.length).to.eq(pagesize)
              })
            }
            
            this.pagecount_button.last().contains(overall_count)
            this.nextpage.last().click()
            j+=pagesize
  
            
            
  
  
          }
  
  
  
  
          
  
          
  
        })
  
       this.firstpage.last().click()
       this.page_size.last().select('10')
      }
  
      gridData(query,config,field_names){
            cy.wait(3000)
          
    
          this.total_page.last().then(($el) => {
            let gridData=[];
    
            const page_count = $el.text()
    
            for(let i=0;i<page_count;i++){
    
              this.ag_grid.getAgGridData().then((actualTableData)=>{
                
                gridData=gridData.concat(actualTableData)
                
    
                if(i==page_count-1){
                  cy.log(gridData)
                  
                  cy.task("DATABASE", {
                    dbConfig: Cypress.env(config),
                    sql: query
                  }).then((result) => {
    
                    console.log(result.rows)
    
                    expect(result.rows.length).to.eq(gridData.length)
                   
    
                    for(let i=0;i<result.rows.length;i++){
                      expect(result.rows[i][field_names[0]]).to.eq(gridData[i][field_names[2]])
                      expect(result.rows[i][field_names[1]]).to.eq(gridData[i][field_names[3]])
                      
                    }
    
                  })
                  
                }
                
              })
    
              this.nextpage.last().click()
    
            }
    
            
    
          })
    
          this.firstpage.last().click()
          
    
        }

        checking_count(query,config){

          this.pagecount_button.last().then(($el) => {
            const overall_count = $el.text()

          cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: query
          }).then((result) => {
            expect(result.rows[0].cnt).to.eq(overall_count)
          })

        })

        }



        role_check(role,config){

          const excelFilePath='./cypress/fixtures/input_data.xlsx'
          const sheetName = 'Processing_Role'

          cy.task('generateJSONFromExcel',{excelFilePath,sheetName}).then((user)=>{

            for(let i=0;i<user.length;i++){
              if(role==user[i].Role){
                cy.wait(3000)
                cy.log(user[i].expected_columns.split(","))
                this.columns_validaiton(user[i+1].expected_columns.split(","))
                this.checking_count(user[i].Data_query,config)

              }
            }

            

          })




        }


    

        role_change_old(role,config){

          const excelFilePath='./cypress/fixtures/input_data.xlsx'
          const sheetName = 'Processing_Role'

          cy.task('generateJSONFromExcel',{excelFilePath,sheetName}).then((user)=>{

            for(let i=0;i<user.length;i++){
              if(role==user[i].Role){
                cy.log(user[i].expected_columns.split(","))
                this.set_status(user[i].Grid_query,config)
              }
            }

            

          })

        }

        role_change(config,role_id){
        
          this.user_nm.first().then(($el) => {
            cy.task("DATABASE", {
              dbConfig: Cypress.env(config),
              sql:` update cdm_accs_enttl.prncpl_role_asgn set role_id=`+role_id+` where prncpl_id = (select prncpl_id from cdm_accs_enttl.usr where usr_nm='`+$el.text().trim()+`')`
        
            })
          })
      
        
        
        
        }


        grid_count_org(config){
          
          this.pagecount_button.last().then(($el) => {
            const overall_count = $el.text()

            this.user_nm.then(($us)=>{
              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: `select count(*) as cnt
                from 
                   cdm_core.file_onbord_instc fil
                     inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                            inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                            inner join cdm_accs_enttl.org org on org.org_id=pl.org_id  
                            inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
                where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',
                
                        'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
                and org1.org_nm = (  select org.org_nm from cdm_accs_enttl.usr usr 
                            inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                            inner join cdm_accs_enttl.org org on org.org_id=pl.org_id where usr_nm='`+$us.text().trim()+`')`
              }).then((result) => {
                expect(result.rows[0].cnt).to.eq(overall_count)
              })
            })
         

        })
        }

        grid_count_all(config){
          
          this.pagecount_button.last().then(($el) => {
            const overall_count = $el.text()

          cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `select count(*) as cnt
            from 
               cdm_core.file_onbord_instc fil
                 inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                        inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                        inner join cdm_accs_enttl.org org on org.org_id=pl.org_id  
            where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',
            
                    'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
            `
          }).then((result) => {
            expect(result.rows[0].cnt).to.eq(overall_count)
          })

        })
        }


        griddata(query,config){

          cy.wait(3000)
    
          this.total_page.last().then(($el) => {
            let gridData=[];
    
            const page_count = $el.text()
    
            for(let i=0;i<page_count;i++){
    
              this.ag_grid.getAgGridData().then((actualTableData)=>{
                
                gridData=gridData.concat(actualTableData)
                
    
                if(i==page_count-1){
                  console.log(gridData)
                  cy.task("DATABASE", {
                    dbConfig: Cypress.env(config),
                    sql: query
                  }).then((result) => {
    
                    console.log(result.rows)
    
                    expect(result.rows.length).to.eq(gridData.length)
                   
    
                    for(let i=0;i<result.rows.length/5;i++){
                      expect(result.rows[i]["file_ref_id"]).to.eq(gridData[i]["File Reference Id"])
                      expect(result.rows[i]["partner"]).to.eq(gridData[i]["Partner"])
                      expect(result.rows[i]["file_name"]).to.eq(gridData[i]["File Name"])
                      expect(result.rows[i]["uploaded_date"]).to.eq(gridData[i]["Uploaded Date (UTC)"])
                      expect(result.rows[i]["upload_mode"]).to.eq(gridData[i]["Upload Mode"])
                      expect(result.rows[i]["status"]).to.eq(gridData[i]["Status"])
                      expect(result.rows[i]["validation_report"]).to.eq(gridData[i]["Validation Report"])
                      expect(result.rows[i]["enriched_file"]).to.eq((gridData[i]["Enriched File"]))

                    }
    
                  })
                }
                
              })
    
              this.nextpage.last().click()
    
            }
    
            
    
          })
    
          this.firstpage.last().click()
          
    
        }


        filter_allcolumns(getvalues,filter,query,config){
          cy.wait(3000)
            cy.xpath(getvalues).last().click()
            this.filter_body.eq(0).type(filter)
            this.InprocessTab.click()
            cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: query
              }).then((result) => {
                  this.pagecount_button.last().should('have.text',result.rows[0].cnt)
    
              })
              cy.xpath(getvalues).last().click()
            this.filter_body.eq(0).clear()
            this.InprocessTab.click()
    
            
        }



}


export default new processing()