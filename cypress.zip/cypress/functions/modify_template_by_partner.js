// ************************ Configuration page - File Metadata Tables Check***********************************
// This file contains all the function definitions and css selectors used for testing the Duplicate tab
// Created by Vignesh Sekar
// 
// Css Selectors - CSS selectors is used for locating the elements in UI screen
//
// Below are the Scenarios Covered for testing these tables:
// 1.Checking the Title and Description of the Duplicate tab
// 2.Verifying the column level filter is working for all the columns in the grid
// 3.Sorting the grid using uploaded date
// 4.Pagination
// 5.Grid Data Validation
// 6.Accept and Reject Functionality
// 7.Role based check for the Grid data and buttons in the duplicate grid

class modify_by_partner {

    get configuration_button(){
        return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/a[1]')
    }

    get operation_button(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[1]/div[1]/div/div[2]/input')
    }

    get modify_template_button(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[4]/div/div[3]/button')
    }

    get title(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/h2')
    }

    get description(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[1]')
    }

    get partner_dropdown(){
        return cy.xpath('//*[@id="partnerNameIdPair"]')
    }

    get platform_dropdown(){
        return cy.xpath('//*[@id="platform"]')
    }


    get subject_dropdown(){
        return cy.xpath('//*[@id="tier2Name"]')
    }

    get process_dropdown(){
        return cy.xpath('//*[@id="tier3Name"]')
    }

    get dataset_dropdown(){
        return cy.xpath('//*[@id="dataset"]')
    }


    get version_dropdown(){
        return cy.xpath('//*[@id="versionNameNumberPair"]')
    }

    get ingestion_mode_dropdown(){
        return cy.xpath('//*[@id="ingestMode"]')
    }

    get retention_arch_input(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div/div[2]/p/div[2]/div/div[1]/input')
    }

    get retention_purge_input(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div/div[2]/p/div[2]/div/div[2]/input')
    }

    get retention_days_input(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div/div[2]/p/div[2]/div/div[3]/input')
    }

    get collab_ind_dropdown(){
        return cy.xpath('//*[@id="collaborationIndicator"]')
    }

    get file_split_ratio_input(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div/div[2]/p/div[3]/div/div[2]/input')
    }

    get org_tmplt_input(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div/div[2]/p/div[3]/div/div[3]/input')
    }

    get original_field_name_1(){
        return cy.xpath('//*[@id="originalTemplateField"]')
    }


    get override_field_name_1(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div/div[2]/p/div[2]/div[2]/div/input')
    }


    get original_field_name_2(){
        return cy.get('.main-content>main>div>div:nth-of-type(4)>div>div:nth-of-type(2)>p>div:nth-of-type(2)>div:nth-of-type(1)>select')
    }


    get override_field_name_2(){
        return cy.get('.main-content>main>div>div:nth-of-type(4)>div>div:nth-of-type(2)>p>div:nth-of-type(2)>div:nth-of-type(2)>div>input')
    }


    get original_field_name_3(){
        return cy.get('.main-content>main>div>div:nth-of-type(4)>div>div:nth-of-type(2)>p>div:nth-of-type(3)>div:nth-of-type(1)>select')
    }


    get override_field_name_3(){
        return cy.get('.main-content>main>div>div:nth-of-type(4)>div>div:nth-of-type(2)>p>div:nth-of-type(3)>div:nth-of-type(2)>div>input')
    }

    get is_active(){
        return cy.get('.main-content>main>div>div:nth-of-type(4)>div>div:nth-of-type(2)>p>div:nth-of-type(3)>div:nth-of-type(3)>div>input')
    }

    get add_another_override_field(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div/div[1]/button')
    }

    get switch_code_1(){
        return cy.xpath('//*[@id="switchCode0"]')
    }

    get switch_value_1(){
        return cy.xpath('//*[@id="switchValue"]')
    }


    get switch_code_2(){
        return cy.xpath('//*[@id="switchCode1"]')
    }

    

    get modify_template_by_partner_button(){
        return cy.get('.main-content>main>div>div:nth-of-type(6)>button:nth-of-type(2)')
    }

    get inactivate_button(){
        return cy.get('.main-content>main>div>div:nth-of-type(6)>button:nth-of-type(3)')
    }

    get modal_header(){
        return cy.xpath('/html/body/div[6]/div/div/div[1]')
    }

    get modal_body(){
        return cy.xpath('/html/body/div[6]/div/div/div[2]/p')
    }

    get ok_button(){
        return cy.xpath('/html/body/div[6]/div/div/div[3]/button')
    }

    get activate_button(){
        return cy.xpath('/html/body/div[6]/div/div/div[3]/button[2]')
    }

    get add_switch(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[5]/div[2]/div[2]/div[2]/div[1]/div/div/div/button/i')

        
    }

    get new_switch(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[5]/div[2]/div[2]/div[3]/div[1]/div/div/div/button/i')
    }

    get switch_name(){
        return cy.xpath('//*[@id="formBasicEmail"]')
    }

    get modal_body_input_1(){
        return cy.get('.mb-3:nth-of-type(1)>input')
    }

    get modal_body_input_2(){
        return cy.get('.mb-3:nth-of-type(2)>input')
    }

    get modal_add_button(){
        return cy.get('.modal-footer>button:nth-of-type(2)')
    }

    get choose_partner_section(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[1]')
    }

    get fields_section(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[1]')
    }

    get switch_section(){
        return cy.xpath('//*[@id="root"]/div[2]/main/div/div[5]/div[1]')
    }



    modify_template_partner_page(){
        this.configuration_button.click()
        cy.wait(1000)
        this.operation_button.click()
        cy.wait(1000)
        this.modify_template_button.should('have.text','Modify template version by partner')
        this.modify_template_button.click()

    }

    title_and_description(){
        this.title.should('have.text','Modify Template Version By Partner')
        this.description.should('have.text','Update an existing template by partner.')

    }

    partner_dropdown_selection(config){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `Select distinct o.org_nm from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id`,
          }).then((result) => {


            for(let i=0;i<result.rows.length;i++){
                this.partner_dropdown.select(result.rows[i].org_nm)
            }

            this.partner_dropdown.find('option').should('have.length',result.rows.length+1)
            this.partner_dropdown.select('Dell')

          });
    }


    platform_dropdown_selection(config){

        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `Select distinct t.pltfrm_cd from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            where o.org_nm='Dell'`,
          }).then((result) => {
            for(let i=0;i<result.rows.length;i++){
                this.platform_dropdown.select(result.rows[i].pltfrm_cd)
            }

            this.platform_dropdown.find('option').should('have.length',result.rows.length+1)
            this.platform_dropdown.select('Dell_plt')
          })

    }


    subject_area_dropdown_selection(config){

        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `Select distinct t1.tier2_hier_nm from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
            where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt'`,
          }).then((result) => {
            for(let i=0;i<result.rows.length;i++){
                this.subject_dropdown.select(result.rows[i].tier2_hier_nm)
            }

            this.subject_dropdown.find('option').should('have.length',result.rows.length+1)
            this.subject_dropdown.select('Dell_sub')
          })

    }

    process_area_dropdown_selection(config){

        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `Select distinct t1.tier3_hier_nm from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
            where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and t1.tier2_hier_nm='Dell_sub'`,
          }).then((result) => {
            for(let i=0;i<result.rows.length;i++){
                this.process_dropdown.select(result.rows[i].tier3_hier_nm)
            }

            this.process_dropdown.find('option').should('have.length',result.rows.length+1)
            this.process_dropdown.select('Dell_prc')
          })

    }


    dataset_dropdown_selection(config){

        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `Select distinct t.dset_cd from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
            where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and t1.tier2_hier_nm='Dell_sub' and  t1.tier3_hier_nm='Dell_prc'`,
          }).then((result) => {
            for(let i=0;i<result.rows.length;i++){
                this.dataset_dropdown.select(result.rows[i].dset_cd)
            }

            //this.dataset_dropdown.find('option').should('have.length',result.rows.length+1)
            this.dataset_dropdown.select('Dell_dataset')
          })

    }


    version_dropdown_selection(config){

        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `Select distinct tm.templt_ver_nm from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
            inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd and t.tier2_3_hier_id = tm.tier2_3_hier_id
            where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and t1.tier2_hier_nm='Dell_sub' and  t1.tier3_hier_nm='Dell_prc' and t.dset_cd ='Dell_dataset'`,
          }).then((result) => {
            for(let i=0;i<result.rows.length;i++){
                this.version_dropdown.select(result.rows[i].templt_ver_nm)
            }

            this.version_dropdown.find('option').should('have.length',result.rows.length+1)
            this.version_dropdown.select('Tablet')
          })

    }


    choose_partner_prepopulation(config){

       

        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `Select i.data_ingest_mode_cd,t.restate_allw_day, t.reten_befr_archv,t.reten_befr_prg, t.elig_for_wf_area_ind,cast(t.file_splt_thrhld_dnmntr_rtio as numeric(100)) as file_splt_thrhld_dnmntr_rtio
            ,t.org_templt_pri from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
            inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd
            inner join cdm_core.org_allw_templt_ingest_mode i on i.dset_cd = t.dset_cd and i.tier2_3_hier_id = t.tier2_3_hier_id and i.org_id=t.org_id and i.pltfrm_cd = t.pltfrm_cd and i.templt_ver_nbr = t.templt_ver_nbr
            where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and tm.templt_ver_nm='Tablet' `,
          }).then((result) => {
            
            this.ingestion_mode_dropdown.find('option:selected').should('have.text', result.rows[0].data_ingest_mode_cd);
            this.retention_arch_input.should('have.value', result.rows[0].reten_befr_archv)
            this.retention_purge_input.should('have.value', result.rows[0].reten_befr_prg)
            this.retention_days_input.should('have.value', result.rows[0].restate_allw_day)
            this.collab_ind_dropdown.find('option:selected').should('have.text', result.rows[0].elig_for_wf_area_ind);
            this.file_split_ratio_input.should('have.value', result.rows[0].file_splt_thrhld_dnmntr_rtio)
            this.org_tmplt_input.should('have.value', result.rows[0].org_templt_pri)


          })

    }


    Override_Fields_prepopulation(config){
       

        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `Select fld.orig_fld_nm,fld.new_fld_nm from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd
            inner join cdm_core.org_delim_templt_fld_ovrrd fld on fld.dset_cd = t.dset_cd and fld.tier2_3_hier_id = t.tier2_3_hier_id and  fld.pltfrm_cd = t.pltfrm_cd 
            and fld.templt_ver_nbr = t.templt_ver_nbr and fld.org_id=t.org_id
            where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and tm.templt_ver_nm='Tablet' `,
          }).then((result) => {
            
            this.original_field_name_1.find('option:selected').should('have.text', result.rows[0].orig_fld_nm);
            this.override_field_name_1.should('have.value', result.rows[0].new_fld_nm)


          })
    }

    switch_prepopulation(config){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: `Select sw.switc_cd,sw.switc_val from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd
            inner join cdm_core.org_allw_templt_switc sw on t.org_templt_id = sw.org_templt_id
            where o.org_nm='Dell' and  t.pltfrm_cd='Dell_plt' and tm.templt_ver_nm='Tablet' `,
          }).then((result) => {
            
            this.switch_code_1.find('option:selected').should('have.text', result.rows[0].switc_cd);
            this.switch_value_1.should('have.value', result.rows[0].switc_val)


          })
    }


    retention_before_archival(){
        cy.wait(2000)
        this.retention_arch_input.clear()
        this.retention_arch_input.type('30')
        this.retention_arch_input.should('have.value','30')
        this.retention_arch_input.clear()
        this.retention_arch_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
        this.retention_arch_input.should('have.value','')
        this.retention_arch_input.clear()
        this.retention_arch_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
        this.retention_arch_input.should('have.value','')
        this.retention_arch_input.clear()
        this.retention_arch_input.type("   ")
        this.retention_arch_input.should('have.value','')
        this.retention_arch_input.clear()
        this.retention_arch_input.type(" 3 0 ")
        this.retention_arch_input.should('have.value','30')
    
      }


      retention_before_purge(){
        this.retention_purge_input.clear()
        this.retention_purge_input.type('30')
        this.retention_purge_input.should('have.value','30')
        this.retention_purge_input.clear()
        this.retention_purge_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
        this.retention_purge_input.should('have.value','')
        this.retention_purge_input.clear()
        this.retention_purge_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
        this.retention_purge_input.should('have.value','')
        this.retention_purge_input.clear()
        this.retention_purge_input.type("   ")
        this.retention_purge_input.should('have.value','')
        this.retention_purge_input.clear()
        this.retention_purge_input.type(" 3 0 ")
        this.retention_purge_input.should('have.value','30')
      }
    
      restatement_allowed_days(){
        this.retention_days_input.clear()
        this.retention_days_input.type('30')
        this.retention_days_input.should('have.value','30')
        this.retention_days_input.clear()
        this.retention_days_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
        this.retention_days_input.should('have.value','')
        this.retention_days_input.clear()
        this.retention_days_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
        this.retention_days_input.should('have.value','')
        this.retention_days_input.clear()
        this.retention_days_input.type("   ")
        this.retention_days_input.should('have.value','')
        this.retention_days_input.clear()
        this.retention_days_input.type(" 3 0 ")
        this.retention_days_input.should('have.value','30')
      }
    
      collab_indicator(){
        this.collab_ind_dropdown.select('N')
      }
    
      file_split_ratio(){
        this.file_split_ratio_input.clear()
        this.file_split_ratio_input.type('30')
        this.file_split_ratio_input.should('have.value','30')
        this.file_split_ratio_input.clear()
        this.file_split_ratio_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
        this.file_split_ratio_input.should('have.value','')
        this.file_split_ratio_input.clear()
        this.file_split_ratio_input.type("   ")
        this.file_split_ratio_input.should('have.value','')
        this.file_split_ratio_input.clear()
        this.file_split_ratio_input.type(" 3 0 ")
        this.file_split_ratio_input.should('have.value','30')
        this.file_split_ratio_input.clear()
        this.file_split_ratio_input.type(" 30.001 ")
        this.file_split_ratio_input.should('have.value','30.001')
         this.file_split_ratio_input.clear()
        this.file_split_ratio_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
        this.file_split_ratio_input.should('have.value','')
        this.file_split_ratio_input.clear()
        this.file_split_ratio_input.type(" 30.001 ")
        this.file_split_ratio_input.should('have.value','30.001')
      }
    
    
      org_tmplt_priority(){
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.clear()
        this.org_tmplt_input.type('1')
        this.org_tmplt_input.should('have.value','1')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type('2')
        this.org_tmplt_input.should('have.value','2')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type('3')
        this.org_tmplt_input.should('have.value','3')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type('4')
        this.org_tmplt_input.should('have.value','4')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type('5')
        this.org_tmplt_input.should('have.value','5')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
        this.org_tmplt_input.should('have.value','')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
        this.org_tmplt_input.should('have.value','')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type("   ")
        this.org_tmplt_input.should('have.value','')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type(" 3 0 ")
        this.org_tmplt_input.should('have.value','3')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type('67890')
        this.org_tmplt_input.should('have.value','')
        this.org_tmplt_input.type('{backspace}')
        this.org_tmplt_input.type(" 3 0 ")
        this.org_tmplt_input.should('have.value','3')
      }


      greater_override_field(){
        this.override_field_name_1.clear()
        this.override_field_name_1.type('    abcdefghiljklmnopq    rstuvwxyzABCDEFGHIJKLMNOPVIGNESHSEkar    ')
        this.override_field_name_1.should('have.value','abcdefghiljklmnopqrstuvwxyzABCDEFGHIJKLMNOPVIGNESH')
      }

      editing_values(){
        this.ingestion_mode_dropdown.select('UU')
        this.retention_arch_input.clear()
        this.retention_arch_input.type('1000')
        this.retention_purge_input.clear()
            this.retention_purge_input.type('1001')
            this.retention_days_input.clear()
            this.retention_days_input.type('1002')
            this.collab_ind_dropdown.select('N')
            this.file_split_ratio_input.clear()
            this.file_split_ratio_input.type('1004')
            this.org_tmplt_input.type('{backspace}')
            this.org_tmplt_input.type('5')
            this.override_field_name_1.clear()
            this.override_field_name_1.type('Changing_Override_Field1')
            this.switch_value_1.select('N')

            this.modify_template_by_partner_button.click()
            cy.wait(2000)
            this.modal_header.should('have.text','Modify Template Version')
            this.modal_body.should('have.text','Template version updated successfully.')
            this.ok_button.click()

      }


      checking_editing_values(config){
        this.modify_template_partner_page()
        this.partner_dropdown_selection(config)
        this.platform_dropdown_selection(config)
        this.subject_area_dropdown_selection(config)
        this.process_area_dropdown_selection(config)
        this.dataset_dropdown_selection(config)
        this.version_dropdown_selection(config)
        this.choose_partner_prepopulation(config)
        this.Override_Fields_prepopulation(config)
        this.switch_prepopulation(config)
        

      }


      adding_new_override_field(){
        this.modify_template_partner_page()
        this.partner_dropdown.select('Dell')
        this.platform_dropdown.select('Dell_plt')
        this.subject_dropdown.select('Dell_sub')
        this.process_dropdown.select('Dell_prc')
        this.dataset_dropdown.select('Dell_dataset')
        this.version_dropdown.select('Desktop')
        cy.wait(2000)
        this.original_field_name_2.select('Field1')
        this.override_field_name_2.type('Desktop_Override_Field1')
        this.add_another_override_field.click()
        this.original_field_name_3.select('Field2')
        this.override_field_name_3.type('Desktop_Override_Field2')
        this.is_active.click()
      }


      adding_new_switch(){
        this.add_switch.click()
        //this.new_switch.click()
        this.modal_body_input_1.type('Partner_Switch_1')
        this.modal_body_input_2.type('Description')
        this.modal_add_button.click()
        this.switch_code_1.select('Partner_Switch_1')
        this.switch_value_1.select('Y')
        
        this.modify_template_by_partner_button.click()
        cy.wait(2000)
        this.modal_header.should('have.text','Modify Template Version')
        this.modal_body.should('have.text','Template version updated successfully.')
        this.ok_button.click()
      }



      Checking_new_override_fields_switch(){
        this.modify_template_partner_page()
        this.partner_dropdown.select('Dell')
        this.platform_dropdown.select('Dell_plt')
        this.subject_dropdown.select('Dell_sub')
        this.process_dropdown.select('Dell_prc')
        this.dataset_dropdown.select('Dell_dataset')
        this.version_dropdown.select('Desktop')
        cy.wait(2000)
        this.original_field_name_2.find('option:selected').should('have.text', 'Field1');
            this.override_field_name_2.should('have.value', 'Desktop_Override_Field1');
            this.original_field_name_3.find('option:selected').should('have.text', 'Field2');
            this.override_field_name_3.should('have.value', 'Desktop_Override_Field2');
            this.switch_code_1.find('option:selected').should('have.text', 'Partner_Switch_1');
            this.switch_value_1.find('option:selected').should('have.text', 'Y');
            this.is_active.should('have.css', 'background-color', 'rgb(255, 255, 255)')
      }


      greater_interger_Value(type){
        cy.on("uncaught:exception", (err, runnable) => {
            return false;
          });
        this.modify_template_partner_page()
        this.partner_dropdown.select('Dell')
        this.platform_dropdown.select('Dell_plt')
        this.subject_dropdown.select('Dell_sub')
        this.process_dropdown.select('Dell_prc')
        this.dataset_dropdown.select('Dell_dataset')
        this.version_dropdown.select('Desktop')
        cy.wait(2000)
        if(type=='Arch'){
            this.retention_arch_input.clear()
            this.retention_arch_input.type('123456789012321421')
        }

        if(type=='Purge'){
            this.retention_purge_input.clear()
            this.retention_purge_input.type('123456789012321421')
        }

        if(type=='Days'){
            this.retention_days_input.clear()
            this.retention_days_input.type('123456789012321421')
        }
       
        this.modify_template_by_partner_button.click()
        cy.wait(2000)
        this.modal_header.should('have.text','Modify Template Version')
        this.modal_body.should('have.text','Value/s provided in one or all retention fields can not be accepted. Value should be in the range: 0 to 2147483647')
        this.ok_button.click()


      }


      greater_numeric_Value(){
        cy.on("uncaught:exception", (err, runnable) => {
            return false;
          });
        this.modify_template_partner_page()
        this.partner_dropdown.select('Dell')
        this.platform_dropdown.select('Dell_plt')
        this.subject_dropdown.select('Dell_sub')
        this.process_dropdown.select('Dell_prc')
        this.dataset_dropdown.select('Dell_dataset')
        this.version_dropdown.select('Desktop')
        cy.wait(2000)
        this.file_split_ratio_input.clear()
        this.file_split_ratio_input.type('123456789012321421.9999999')
        this.modify_template_by_partner_button.click()
        cy.wait(2000)
        this.modal_header.should('have.text','Modify Template Version')
        this.modal_body.should('have.text','Value provided in the File Split Denominator Ratio field can not be accepted. Value should be in the range: 0 to 9999999.999')
        this.ok_button.click()



      }


      Inactivate_Template(){
        this.modify_template_partner_page()
        this.partner_dropdown.select('Dell')
        this.platform_dropdown.select('Dell_plt')
        this.subject_dropdown.select('Dell_sub')
        this.process_dropdown.select('Dell_prc')
        this.dataset_dropdown.select('Dell_dataset')
        this.version_dropdown.select('Tablet')
        this.inactivate_button.click()
        this.modal_header.should('have.text','Confirm Inactivation')
        this.modal_body.should('have.text','Clicking on Inactivate button will make the Template Version inactive for Dell. To make the Template Version Active, please go to the "Modify Template by Partner" screen, select the Partner and Template and click on Activate button')
        this.activate_button.click()
        this.fields_section.should('have.css', 'background-color', 'rgba(250, 250, 250, 0.52)')
        this.choose_partner_section.should('have.css', 'background-color', 'rgba(250, 250, 250, 0.52)')
        this.switch_section.should('have.css', 'background-color', 'rgba(250, 250, 250, 0.52)')

      }


      Activate_Template(){
        this.modify_template_partner_page()
        this.partner_dropdown.select('Dell')
        this.platform_dropdown.select('Dell_plt')
        this.subject_dropdown.select('Dell_sub')
        this.process_dropdown.select('Dell_prc')
        this.dataset_dropdown.select('Dell_dataset')
        this.version_dropdown.select('Tablet')
        this.inactivate_button.click()
        this.modal_header.should('have.text','Confirm Activation')
        this.modal_body.should('have.text','Clicking on Activate button will make the Template Version active for Dell. To make the Template Version Inactive, please go to the "Modify Template by Partner" screen, select the Partner and Template and click on Inactivate button.')
        this.activate_button.click()
        this.add_another_override_field.should('have.css', 'background-color', 'rgb(0, 104, 181)')
        

      }

      Activate_other_Template(){
        this.modify_template_partner_page()
        this.partner_dropdown.select('Dell')
        this.platform_dropdown.select('Dell_plt')
        this.subject_dropdown.select('Dell_sub')
        this.process_dropdown.select('Dell_prc')
        this.dataset_dropdown.select('Dell_dataset')
        this.version_dropdown.select('Desktop')
        this.add_another_override_field.should('have.css', 'background-color', 'rgb(0, 104, 181)')
      }

      Activate_other_partner(){
        this.modify_template_partner_page()
        this.partner_dropdown.select('Microsoft')
        this.platform_dropdown.select('Dell_plt')
        this.subject_dropdown.select('Dell_sub')
        this.process_dropdown.select('Dell_prc')
        this.dataset_dropdown.select('Dell_dataset')
        this.version_dropdown.select('Tablet')
        this.add_another_override_field.should('have.css', 'background-color', 'rgb(0, 104, 181)')
      }



}



export default new modify_by_partner();
