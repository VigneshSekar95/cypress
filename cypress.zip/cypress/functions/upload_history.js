import dup from '../functions/duplicate'
import rolefunc from '../functions/role'
//<reference types="cypress" />
class upload_histroy {
  //locators

  get uploadFileButton() {
    return cy.get("#responsive-navbar-nav>div:nth-of-type(2)>a");
  }

  get uploadHistoryButton() {
    return cy.get("#responsive-navbar-nav>div:nth-of-type(1)>a:nth-of-type(2)");
  }

  get dataset_menu(){
    return cy.xpath('//*[@id="datasetDropdown"]')
  }

  get historical_data() {
    return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[1]')
  }

  get wait3Sec() {
    return cy.wait(3000);
  }

  get wait6Sec() {
    return cy.wait(6000);
  }

  get pageTitle() {
    return cy.xpath('//*[@id="root"]/div[2]/main/h3');
  }

  get HistoryTab() {
    return cy.get("#uncontrolled-tab-example-tab-History");
  }

  get History_gridData(){
    return  cy.get('#uncontrolled-tab-example-tabpane-History')

}

  get subdescription() {
    return cy.xpath('//*[@id="root"]/div[2]/main/span');
  }

  get InprocessTab() {
    return cy.get("#uncontrolled-tab-example-tab-Processing");
  }

  get pagecount_button() {
    return cy.get(".ag-paging-panel>span>span:nth-of-type(5)");
  }

  get page_record_count(){
    return cy.get('.ag-paging-panel>span>span:nth-of-type(3)')
  }

  get export_button() {
    return cy.get(
      ".d-flex.justify-content-end.mt-3 > div > button:nth-of-type(6)"
    );
  }

  get checkbox() {
    return cy.get(
      ".ag-labeled.ag-label-align-right.ag-checkbox.ag-input-field:not(.ag-hidden)"
    );
  }

  get filter_file_ref_id(){
    return cy.get('.ag-header-cell:nth-of-type(2)>div:nth-of-type(3)>.ag-header-icon')
}

  get filter_filename(){
    return cy.get('.ag-header-cell:nth-of-type(6)>div:nth-of-type(3)>.ag-header-icon')
}

get filter_filestatus(){
  return cy.get('.ag-header-cell:nth-of-type(12)>div:nth-of-type(3)>.ag-header-icon')
}

get filter_body(){
    return cy.get('.ag-filter-body>div>div>.ag-input-field-input.ag-text-field-input')
}

get firstpage(){
    return cy.get('.ag-paging-page-summary-panel>div:nth-of-type(1)')
}

get nextpage(){
    return cy.get('.ag-paging-page-summary-panel>div:nth-of-type(3)')
}

get rows_loaded(){
  return cy.get(".ag-row-even[row-index='0']>.ag-cell:nth-of-type(8)")
}

get filter_all(){
    return {file_reference_id:'.ag-header-cell:nth-of-type(2)>div:nth-of-type(3)>.ag-header-icon',
    uploaded_date:'.ag-header-cell:nth-of-type(4)>div:nth-of-type(3)>.ag-header-icon',
    dataset:'.ag-header-cell:nth-of-type(5)>div:nth-of-type(3)>.ag-header-icon',
    submission_period:'.ag-header-cell:nth-of-type(7)>div:nth-of-type(3)>.ag-header-icon',
    submitted_by:'.ag-header-cell:nth-of-type(11)>div:nth-of-type(3)>.ag-header-icon',
    partner:'.ag-header-cell:nth-of-type(3)>div:nth-of-type(3)>.ag-header-icon',
    filename:'.ag-header-cell:nth-of-type(6)>div:nth-of-type(3)>.ag-header-icon',
    rowsloaded:'.ag-header-cell:nth-of-type(8)>div:nth-of-type(3)>.ag-header-icon',
    restatement:'.ag-header-cell:nth-of-type(9)>div:nth-of-type(3)>.ag-header-icon',
    filestatus:'.ag-header-cell:nth-of-type(12)>div:nth-of-type(3)>.ag-header-icon',
    enriched_file:'.ag-header-cell:nth-of-type(13)>div:nth-of-type(3)>.ag-header-icon',
    modified_by:'.ag-header-cell:nth-of-type(14)>div:nth-of-type(3)>.ag-header-icon',
    modified_datetime:'.ag-header-cell:nth-of-type(15)>div:nth-of-type(3)>.ag-header-icon',
    duplicate:'.ag-header-cell:nth-of-type(10)>div:nth-of-type(3)>.ag-header-icon'

  }
  }


  get uploadedDate_header(){
    return cy.get('.ag-header-row>div:nth-of-type(4)>div:nth-of-type(3)>div>span:nth-of-type(1)').eq(0)
}

get modifiedDate_header(){
    return cy.get('.ag-header-row>div:nth-of-type(15)>div:nth-of-type(3)>div>span:nth-of-type(1)')
}


get lastpage(){
  return cy.get('.ag-paging-page-summary-panel>div:nth-of-type(4)')
}

get firstpage(){
  return cy.get('.ag-paging-page-summary-panel>div:nth-of-type(1)')
}


get total_page(){
  return cy.get('.ag-paging-page-summary-panel>span>span:nth-of-type(4)')
}


get page_size(){
  //return cy.get('#uncontrolled-tab-example-tabpane-History>span>#page-size')
  return cy.xpath('//*[@id="page-size"]')
}


get firstrow_on_page(){
  return cy.get('.ag-root-wrapper>div:nth-of-type(2)>span>span:nth-of-type(1)')
}

get lastrow_on_page(){
  return cy.get('.ag-root-wrapper>div:nth-of-type(2)>span>span:nth-of-type(3)')
}

get page_number(){
  return cy.get('.ag-paging-page-summary-panel>span>span:nth-of-type(2)')
}

  get publish_button(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-History"]/div[1]/div/button[4]')
  }

  get file_status_first_row(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-History"]/div[3]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[1]/div[12]')
  }

  get file_status_second_row(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-History"]/div[3]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[2]/div[12]')
  }

  get modified_date_first_row(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-History"]/div[3]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[1]/div[15]')
  }

  get modified_date_second_row(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-History"]/div[3]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[2]/div[15]')
  }

  get file_reference_id_first_row(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-History"]/div[3]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[1]/div[2]')
  }

  get file_reference_id_second_row(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-History"]/div[3]/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div[2]/div[2]')
  }


  get user_profile(){
    return cy.xpath('//*[@id="nav-dropdown-light-example"]')
  }

  get email_addr(){
    return cy.xpath('//*[@id="navbar-light-example"]/div/div/div/span[2]')
  }

  get modal_header(){
    return cy.get('.modal-header')
  }

  get modal_body(){
    return cy.get('.modal-body')
  }

  get modal_footer(){
    return cy.get('.modal-footer>button')
  }

  get file_name(){
    return cy.get(".ag-row-even[row-index='0']>.ag-cell:nth-of-type(6)")
  }


  get user_nm(){
    return cy.xpath('//*[@id="userSignOutDropdown"]/div')
  }

  get inactive_button(){
    return cy.get('.d-flex.justify-content-end.mt-3 > div > button:nth-of-type(2)')
  }

  get filter_file_status(){
    return cy.get('.ag-header-cell:nth-of-type(12)>div:nth-of-type(3)>.ag-header-icon')
  }

  get checkbox(){
    return cy.get('.ag-labeled.ag-label-align-right.ag-checkbox.ag-input-field:not(.ag-hidden)')
}


get inactive_popup_button_close(){
  return cy.get('.btn-close')
}

get inactive_popup_title(){
  return cy.get('.modal-title')
}

get inactive_popup_description(){
  return cy.get('.modal-body>div>h5')
}

get inactive_popup_cancel_buton(){
  return cy.get('.modal-footer>button:first-of-type')
}

get inactive_popup_inactive_button(){
  return cy.get('.modal-footer>button:last-of-type')
}

get inactive_popup_textarea(){
  return cy.get('.modal-body>div>textarea')
}

get inactive_popup_note(){
  return cy.get('.modal-body>div>p')
}

get filter_file_reference_id(){
  return cy.get('.ag-header-cell:nth-of-type(2)>div:nth-of-type(3)>.ag-header-icon')
}

  //methods



  role_change(config,role_id){
    this.user_nm.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql:` update cdm_accs_enttl.prncpl_role_asgn set role_id=`+role_id+` where prncpl_id = (select prncpl_id from cdm_accs_enttl.usr where usr_nm='`+$el.text().trim()+`')`
  
      })
    })
    
  
  }

  launchApp(url, title) {
    cy.visit(url, { timeout: 30000 });
    cy.title().should("eq", title);
    cy.wait(5000);
  }

  uploadFileButton_click() {
    this.uploadFileButton.click();
  }

  uploadHistoryButton_click() {
    this.dataset_menu.click()
    this.historical_data.should('have.text','Historical Data')
    this.historical_data.click()


  }

  before_all() {
    this.uploadFileButton.click();
    this.uploadHistoryButton.click();
  }

  wait3Sec_app() {
    this.wait3Sec;
  }

  wait6Sec_app() {
    this.wait6Sec;
  }

  pageTitle_validation(title) {
    this.pageTitle.contains(title);
  }

  HistoryTab_validation(title, description) {
    this.HistoryTab.click();
    this.HistoryTab.contains(title);
    this.subdescription.contains(description);
  }

  InprocessTab_validation(title, description) {
    this.InprocessTab.click();
    this.InprocessTab.contains(title);
    this.subdescription.contains(description);
    this.HistoryTab.click();
  }

  columns_validaiton(columns) {
    for (let i = 0; i < 15; i++) {
      let j = i + 1;
      cy.get(
        ".ag-header-row>.ag-header-cell:nth-of-type(" +
          j +
          ")>div:nth-of-type(3)>div>span:nth-of-type(1)"
      )
        .eq(0)
        .should("have.text", columns[i]);
    }
  }

  exportfulldata(text, filePath, excelFilePath, deletefilepath) {
    cy.task("deletefile", deletefilepath, (result) => {
      cy.log(result);
    });
    this.pagecount_button.first().then(($el) => {
      const overall_count = $el.text()

      if(overall_count==0){
        this.export_button.should('be.disabled')
      }
      else{
        this.export_button.contains(text);
    this.export_button.click();
    cy.wait(5000)
    cy.task("renamefile_fulldata", filePath, (result) => {
      cy.log(result);
    });
    cy.task("readCSVfile_export", excelFilePath).then((result) => {
      cy.log(result);
      this.pagecount_button.eq(0).should("have.text", result);
    });
      }
    }) 
    
    
  }

  exportSelectedData(filePath, excelFilePath) {
    let arr = [1, 2, 3]

    this.pagecount_button.first().then(($el) => {
      const overall_count = $el.text()

      if(overall_count==0){
        this.export_button.should('be.disabled')
      }

    })
    cy.wait(1000)
    this.checkbox.each(function ($el, index, $listelements) {
      if (arr.includes(index)) {
        cy.wrap($el).click();
      }
    });

    this.export_button.click();
    cy.wait(5000)

    cy.task("renamefile_selecteddata", filePath, (result) => {
      cy.log(result);
    });

    cy.task("readCSVfile_export", excelFilePath).then((result) => {
      cy.log(result);
      expect(result).to.eq(arr.length);
      this.checkbox.each(function ($el, index, $listelements) {
        if (arr.includes(index)) {
          cy.wrap($el).click();
        }
      });
    });
  }

  export_button_disabled(filtervalue){
    this.filter_filename
          .first()
          .click()
        this.filter_body.eq(0)
          .type(filtervalue)
            cy.wait(1000)
          this.HistoryTab.click()
          cy.wait(1000)
          this.export_button.should('be.disabled')
          

  }

  exportcolumnFIlteredData(filePath,excelFilePath,filtervalue){
    this.filter_filename
          .first()
          .click()
        this.filter_body.eq(0)
          .clear()
        cy.wait(1000)
      this.filter_filename
          .first()
          .click()
        this.filter_body.eq(0)
          .type(filtervalue)

          cy.wait(1000)
          this.HistoryTab.click()
          this.export_button.click()
          cy.wait(5000)
      cy.task('renamefile_columnlevelfiltereddata',filePath,(result)=>{
      cy.log(result)
})
        cy.wait(1000)
      cy.task("readCSVfile_export",excelFilePath).then((result)=>{

      cy.log(result)

      this.pagecount_button.eq(0).should('have.text',result)

      this.filter_filename
          .first()
          .click()
        this.filter_body.eq(0)
          .clear()


          cy.wait(2000)



})
  }

  exportPaginatedData(filePath,excelFilePath){
    cy.wait(1000)
    this.checkbox
  .each(function($el,index,$listelements){

    if([1,2,3,4,5].includes(index)){
      
      cy.wrap($el).click()
    }
  })

  this.nextpage.eq(0).click()

  this.checkbox
  .each(function($el,index,$listelements){

    if([1,2,3,4,5].includes(index)){
      
      cy.wrap($el).click()
    }
  })

this.export_button.click()
cy.wait(5000)

cy.task('renamefile_paginatedselecteddata',filePath,(result)=>{
  cy.log(result)
})

cy.task("readCSVfile_export",excelFilePath).then((result)=>{
cy.log(result)
expect(result).to.eq(10)
this.checkbox
  .each(function($el,index,$listelements){

    if([1,2,3,4,5].includes(index)){
      
      cy.wrap($el).click()
    }
  })

  this.firstpage.eq(0).click()

  this.checkbox
  .each(function($el,index,$listelements){

    if([1,2,3,4,5].includes(index)){
      
      cy.wrap($el).click()
    }
  })
})
}


filter_allcolumns(getvalues,filter,query,config){
      cy.get(getvalues).first().click()
      this.filter_body.eq(0).type(filter)
      this.HistoryTab.click()
      cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: query
        }).then((result) => {
            this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)

        })
        cy.get(getvalues).first().click()
      this.filter_body.eq(0).clear()
      this.HistoryTab.click()

      
  }


  
filter_filename_link(getvalues,filter,query,config){
  cy.get(getvalues).first().click()
  this.filter_body.eq(0).type(filter)
  this.file_name.click()
  

  
}



  publish_button_disabled_page_load(){
      this.publish_button.should('be.disabled')
  }

  publish_button_disabled_publish_file(){
    let selection=[]
      this.filter_filestatus.click()
      this.filter_body.eq(0).type('publish')
      cy.wait(2000)
      this.page_record_count.first().then(($el) => {
            if($el.text()>=1){
              for (let i=1;i<=$el.text();i++){
                selection.push(i)
              }
              this.checkbox.each(function ($el, index, $listelements) {
                if (selection.includes(index)) {
                  cy.wrap($el).click();
                }
              });
            }
      })


      this.publish_button.should('be.disabled')

      this.page_record_count.first().then(($el) => {
        if($el.text()>=1){
          for (let i=1;i<=$el.text();i++){
            selection.push(i)
          }
          this.checkbox.each(function ($el, index, $listelements) {
            if (selection.includes(index)) {
              cy.wrap($el).click();
            }
          });
        }
  })

  this.filter_filestatus.click()
      this.filter_body.eq(0).clear()

  }

  selecting_published_processed(){
    let publish=[]
    let process=[]
    this.filter_filestatus.click()
    this.filter_body.eq(0).type('publish')
    cy.wait(2000)
    this.page_record_count.first().then(($el) => {
          if($el.text()>=1){
            for (let i=1;i<=$el.text();i++){
              publish.push(i)
            }
            this.checkbox.each(function ($el, index, $listelements) {
              if (publish.includes(index)) {
                cy.wrap($el).click();
              }
            });
          }
    })

    this.filter_filestatus.click()
    this.filter_body.eq(0).clear()
    cy.wait(2000)
    this.filter_body.eq(0).type('process')
    cy.wait(2000)
    this.page_record_count.first().then(($el) => {
      if($el.text()>=1){
        for (let i=1;i<=$el.text();i++){
          process.push(i)
        }
        this.checkbox.each(function ($el, index, $listelements) {
          if (process.includes(index)) {
            cy.wrap($el).click();
          }
        });
      }
})

this.publish_button.should('be.disabled')

cy.wait(5000)
dup.launching_consumer_data()
this.uploadHistoryButton_click("Historical Data");
cy.wait(10000)


  }


  no_data_grid_publish_button(){
    this.filter_filestatus.click()
    this.filter_body.eq(0).type('external')
    cy.wait(1000)
    this.publish_button.should('be.disabled')
    this.filter_filestatus.click()
    this.filter_body.eq(0).clear()

  }

  selecting_process_Files(){
    let process=[]
    let process_unselect=[]
    this.filter_filestatus.click()
    this.filter_body.eq(0).clear()
    this.filter_body.eq(0).type('process')
    cy.wait(2000)
    this.page_record_count.first().then(($el) => {
      if($el.text()>=1){
        for (let i=1;i<=$el.text();i++){
          process.push(i)
        }
        this.checkbox.each(function ($el, index, $listelements) {
          if (process.includes(index)) {
            cy.wrap($el).click();
          }
        });
      }

      this.publish_button.should('be.enabled')
      if($el.text()>=1){
        for (let i=1;i<=$el.text();i++){
          process_unselect.push(i)
        }
        this.checkbox.each(function ($el, index, $listelements) {
          if (process_unselect.includes(index)) {
            cy.wrap($el).click();
          }
        });
      }

})

  }

  formatAMPM(date) {
    var hours = date.getUTCHours();
    var minutes = date.getUTCMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    hours = hours < 10 ? '0'+hours : hours
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
  }

  selecting_single_file(config){
    var date = new Date();
    const monthNames = ["January", "February", "March", "April", "May", "June",
              "July", "August", "September", "October", "November", "December"
            ];
    let process=[]
    this.filter_filestatus.click()
    this.filter_body.eq(0).clear()
    this.filter_body.eq(0).type('process')
    cy.wait(1000)
    this.page_record_count.first().then(($el) => {
      if($el.text()>=1){
        for (let i=1;i<=1;i++){
          process.push(i)
        }
        this.checkbox.each(function ($el, index, $listelements) {
          if (process.includes(index)) {
            cy.wrap($el).click();
          }
      //    
        });
      }
      cy.wait(1000)
      //cy.log(date)
      //cy.log(date.getUTCFullYear() +"-"+ ((date.getUTCMonth()+1) < 10 ? '0'+ (date.getUTCMonth()+1) : (date.getUTCMonth()+1) )+"-"+ ( date.getUTCDate() < 10 ? '0'+date.getUTCDate() : date.getUTCDate()) + " " + ( date.getUTCHours() < 10 ? '0'+date.getUTCHours() : date.getUTCHours())  + ":" + ( date.getUTCMinutes() < 10 ? '0'+date.getUTCMinutes() : date.getUTCMinutes()) )
      //this.file_status_first_row.should('have.text','Processed')
     // this.modified_date_first_row.should('have.text',monthNames[date.getUTCMonth()].slice(0,3)+" "+ date.getUTCDate()+", "+date.getUTCFullYear() + " " +this.formatAMPM(date))
      var date_change=date.getUTCFullYear() +"-"+ ((date.getUTCMonth()+1) < 10 ? '0'+ (date.getUTCMonth()+1) : (date.getUTCMonth()+1) )+"-"+ ( date.getUTCDate() < 10 ? '0'+date.getUTCDate() : date.getUTCDate()) + " " + ( date.getUTCHours() < 10 ? '0'+date.getUTCHours() : date.getUTCHours())  + ":" + ( date.getUTCMinutes() < 10 ? '0'+date.getUTCMinutes() : date.getUTCMinutes()) 
     // this.publish_button.click()
      
      this.file_reference_id_first_row.first().then(($el)=>{

        this.publish_button.click()
            this.modal_header.should('have.text','Publish')
        this.modal_body.should('have.text','File(s) Published Successfully')
        this.modal_footer.should('have.text','Ok')
        this.modal_footer.click()

        // cy.task("DATABASE", {
        //   dbConfig: Cypress.env(config),
        //   sql: `  select a.file_ref_id,case when a.latst_onbord_sts_cd='CDM_Processing_Success' then 'Processed' when a.latst_onbord_sts_cd ='CDM_Published' then 'Published' end as latst_onbord_sts_cd
        //   ,a.chg_agnt_id,substr(cast(a.chg_dtm as varchar(100)),1,16) as chg_dtm,a.pblish_by, substr(cast(a.pblish_dtm as varchar(100)),1,16) as pblish_dtm,
        //   a.downstream_ind , u.email_addr,case when b.latst_onbord_sts_cd='CDM_Processing_Success' then 'Processed' when b.latst_onbord_sts_cd ='CDM_Published' then 'Published' end as sub_latst_onbord_sts_cd , 
        //   substr(cast(b.chg_dtm as varchar(100)),1,16) as sub_chg_dtm,
        //   u1.email_addr as sub_email_addr
        //   from cdm_core.file_onbord_instc  a 
        //    left join cdm_core.file_onbord_sub_instc b on a.file_instc_id = b.file_instc_id
        //   inner join cdm_accs_enttl.usr u on a.chg_agnt_id = cast(u.prncpl_id as varchar(100)) and a.pblish_by = cast(u.prncpl_id as varchar(100))
        //   left join cdm_accs_enttl.usr u1 on a.chg_agnt_id = cast(u1.prncpl_id as varchar(100)) and a.pblish_by = cast(u1.prncpl_id as varchar(100))
         
          
        //   where file_ref_id='`+$el.text()+`'`
        // }).then((result) => {
        //         console.log(result)
        //        // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
        //        expect(result.rows[0].file_ref_id).to.eq($el.text())
        //        expect(result.rows[0].downstream_ind).to.eq('Y')
        //        expect(result.rows[0].latst_onbord_sts_cd).to.eq('Published')
        //        expect(result.rows[0].pblish_dtm).to.eq(date_change)
        //        expect(result.rows[0].chg_dtm).to.eq(date_change)
        //        expect(result.rows[0].sub_chg_dtm).to.eq(date_change)
        //       expect(result.rows[0].sub_latst_onbord_sts_cd).to.eq('Published')
        //        this.user_profile.click()
        //        this.email_addr.should('have.text',result.rows[0].email_addr)
        //        this.email_addr.should('have.text',result.rows[0].sub_email_addr)

        // })

        

        this.filter_filestatus.click()
    this.filter_body.eq(0).clear()

    this.filter_file_ref_id.click()
    this.filter_body.eq(0).clear()
    this.filter_body.eq(0).type($el.text())
    cy.wait(1000)
    this.file_status_first_row.should('have.text','Published')
    //this.modified_date_first_row.should('have.text',monthNames[date.getUTCMonth()].slice(0,3)+" "+ ( date.getUTCDate() < 10 ? '0'+date.getUTCDate() : date.getUTCDate())+", "+date.getUTCFullYear() + " " +this.formatAMPM(date))
    //expect(inactive_grid_data['Modified Date (UTC)'].slice(0,12)).to.eq(monthNames[date.getUTCMonth()].slice(0,3)+" "+ (String(date.getUTCDate()).length<2?'0'+date.getUTCDate():date.getUTCDate())+", "+date.getUTCFullYear())
    this.modified_date_first_row.contains(monthNames[date.getUTCMonth()].slice(0,3)+" "+ (String(date.getUTCDate()).length<2?'0'+date.getUTCDate():date.getUTCDate())+", "+date.getUTCFullYear())
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql:`update cdm_core.file_onbord_instc set latst_onbord_sts_cd='CDM_Processing_Success' where file_ref_id='`+$el.text()+`'`

    })

    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql:`update cdm_core.file_onbord_sub_instc set latst_onbord_sts_cd='CDM_Processing_Success' where file_instc_id='`+$el.text().substring(0,$el.text().indexOf('_'))+`'`

    })

    this.filter_file_ref_id.click()
    this.filter_body.eq(0).clear()
    this.HistoryTab.click()
       
      })

      
     

    })


   

  }


  selecting_multiple_files(config){
    var date = new Date();
    const monthNames = ["January", "February", "March", "April", "May", "June",
              "July", "August", "September", "October", "November", "December"
            ];
    let process=[]
    this.filter_filestatus.click()
    this.filter_body.eq(0).clear()
    this.filter_body.eq(0).type('process')
    cy.wait(1000)
    this.page_record_count.first().then(($el) => {
      if($el.text()>1){
        for (let i=1;i<=3;i++){
          process.push(i)
        }
        this.checkbox.each(function ($el, index, $listelements) {
          if (process.includes(index)) {
            cy.wrap($el).click();
          }
      //    
        });
      }
      cy.wait(1000)
      //cy.log(date)
      //cy.log(date.getUTCFullYear() +"-"+ ((date.getUTCMonth()+1) < 10 ? '0'+ (date.getUTCMonth()+1) : (date.getUTCMonth()+1) )+"-"+ ( date.getUTCDate() < 10 ? '0'+date.getUTCDate() : date.getUTCDate()) + " " + ( date.getUTCHours() < 10 ? '0'+date.getUTCHours() : date.getUTCHours())  + ":" + ( date.getUTCMinutes() < 10 ? '0'+date.getUTCMinutes() : date.getUTCMinutes()) )
      //this.file_status_first_row.should('have.text','Processed')
     // this.modified_date_first_row.should('have.text',monthNames[date.getUTCMonth()].slice(0,3)+" "+ date.getUTCDate()+", "+date.getUTCFullYear() + " " +this.formatAMPM(date))
     
     // this.publish_button.click()
      
      //this.file_reference_id_first_row.first().then(($el)=>{

        this.History_gridData.getAgGridData().then((actualTableData)=>{
              this.publish_button.click()
            this.modal_header.should('have.text','Publish')
        this.modal_body.should('have.text','File(s) Published Successfully')
        this.modal_footer.should('have.text','Ok')
        this.modal_footer.click()

          for(let i=0;i<3;i++){

          cy.log(actualTableData[i]['File Reference Id'])

          var date_change=date.getUTCFullYear() +"-"+ ((date.getUTCMonth()+1) < 10 ? '0'+ (date.getUTCMonth()+1) : (date.getUTCMonth()+1) )+"-"+ ( date.getUTCDate() < 10 ? '0'+date.getUTCDate() : date.getUTCDate()) + " " + ( date.getUTCHours() < 10 ? '0'+date.getUTCHours() : date.getUTCHours())  + ":" + ( date.getUTCMinutes() < 10 ? '0'+date.getUTCMinutes() : date.getUTCMinutes()) 

        // cy.task("DATABASE", {
        //   dbConfig: Cypress.env(config),
        //   sql: `  select a.file_ref_id,case when a.latst_onbord_sts_cd='CDM_Processing_Success' then 'Processed' when a.latst_onbord_sts_cd ='CDM_Published' then 'Published' end as latst_onbord_sts_cd
        //   ,a.chg_agnt_id,substr(cast(a.chg_dtm as varchar(100)),1,16) as chg_dtm,a.pblish_by, substr(cast(a.pblish_dtm as varchar(100)),1,16) as pblish_dtm,
        //   a.downstream_ind , u.email_addr,case when b.latst_onbord_sts_cd='CDM_Processing_Success' then 'Processed' when b.latst_onbord_sts_cd ='CDM_Published' then 'Published' end as sub_latst_onbord_sts_cd , 
        //   substr(cast(b.chg_dtm as varchar(100)),1,16) as sub_chg_dtm,
        //   u1.email_addr as sub_email_addr
        //   from cdm_core.file_onbord_instc  a 
        //    left join cdm_core.file_onbord_sub_instc b on a.file_instc_id = b.file_instc_id
        //   inner join cdm_accs_enttl.usr u on a.chg_agnt_id = cast(u.prncpl_id as varchar(100)) and a.pblish_by = cast(u.prncpl_id as varchar(100))
        //   left join cdm_accs_enttl.usr u1 on a.chg_agnt_id = cast(u1.prncpl_id as varchar(100)) and a.pblish_by = cast(u1.prncpl_id as varchar(100))
         
          
        //   where file_ref_id='`+actualTableData[i]['File Reference Id']+`'`
        // }).then((result) => {
        //         console.log(result)
        //        expect(result.rows[0].file_ref_id).to.eq(actualTableData[i]['File Reference Id'])
        //        expect(result.rows[0].downstream_ind).to.eq('Y')
        //        expect(result.rows[0].latst_onbord_sts_cd).to.eq('Published')
        //        expect(result.rows[0].pblish_dtm).to.eq(date_change)
        //        expect(result.rows[0].chg_dtm).to.eq(date_change)
        //        expect(result.rows[0].sub_chg_dtm).to.eq(date_change)
        //       expect(result.rows[0].sub_latst_onbord_sts_cd).to.eq('Published')
        //        this.user_profile.click()
        //        this.email_addr.should('have.text',result.rows[0].email_addr)
        //        this.email_addr.should('have.text',result.rows[0].sub_email_addr)

        // })

        

        this.filter_filestatus.click()
    this.filter_body.eq(0).clear()

    this.filter_file_ref_id.click()
    this.filter_body.eq(0).clear()
    this.filter_body.eq(0).type(actualTableData[i]['File Reference Id'])
    cy.wait(1000)
    this.file_status_first_row.should('have.text','Published')
    //this.modified_date_first_row.should('have.text',monthNames[date.getUTCMonth()].slice(0,3)+" "+ ( date.getUTCDate() < 10 ? '0'+date.getUTCDate() : date.getUTCDate())+", "+date.getUTCFullYear() + " " +this.formatAMPM(date))
    this.modified_date_first_row.contains(monthNames[date.getUTCMonth()].slice(0,3)+" "+ (String(date.getUTCDate()).length<2?'0'+date.getUTCDate():date.getUTCDate())+", "+date.getUTCFullYear())

    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql:`update cdm_core.file_onbord_instc set latst_onbord_sts_cd='CDM_Processing_Success' where file_ref_id='`+actualTableData[i]['File Reference Id']+`'`

    })

    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql:`update cdm_core.file_onbord_sub_instc set latst_onbord_sts_cd='CDM_Processing_Success' where file_instc_id='`+actualTableData[i]['File Reference Id'].substring(0,actualTableData[i]['File Reference Id'].indexOf('_'))+`'`

    })

    this.filter_file_ref_id.click()
    this.filter_body.eq(0).clear()
    this.HistoryTab.click()
       
          }
      })

      
     

    })


   

  }


  publish_button_visible_role(config,role_id){
    dup.role_change(config,role_id);

    cy.wait(20000)
    dup.launching_consumer_data()
    cy.wait(20000)
    if(role_id==2){
      rolefunc.uploadHistoryButton_click_1();
    }
    if(role_id==3){
      rolefunc.uploadHistoryButton_click();
    }
    cy.wait(10000)
    this.publish_button.should('be.visible')
    this.publish_button.should('have.text','Publish')

    
  }


  publish_button_not_visible_role(config,role_id){
    dup.role_change(config,role_id);

    cy.wait(20000)
    dup.launching_consumer_data()
    cy.wait(20000)
    if(role_id==1){
      rolefunc.uploadHistoryButton_click();
    }
    if(role_id==5 || role_id==6){
      rolefunc.uploadHistoryButton_click_1();
    }
    
    cy.wait(10000)
    this.publish_button.should('be.visible')
    if(role_id=='1'){
      this.publish_button.should('have.text','Reprocess')

    }

    else{
      this.publish_button.should('have.text','Export')
    }
    
    
  }


  sorting(config,query,fieldname,sort_order){
      
    if(fieldname=="Uploaded Date"){
        this.uploadedDate_header.click()
        cy.wait(2000)
    }

    

    if(fieldname=="Modified Date"){
        this.modifiedDate_header.click()
        cy.wait(2000)
    }

    
    
    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: query
      }).then((result) => {
        
        const db_uploaded_date_first = result.rows[0]
        const db_uploaded_date_last = result.rows[result.rows.length-1]
        

        this.History_gridData.getAgGridData().then((actualTableData)=>{
            const grid_uploaded_date_first = actualTableData[0]
            expect(grid_uploaded_date_first['File Name']).to.eq(db_uploaded_date_first.file_name)
            expect(grid_uploaded_date_first['File Reference Id']).to.eq(db_uploaded_date_first.file_ref_id)
        })

        this.lastpage.eq(0).click()

        this.History_gridData.getAgGridData().then((lastpagedata)=>{
            const grid_uploaded_date_last = lastpagedata[lastpagedata.length-1]
            expect(grid_uploaded_date_last['File Name']).to.eq(db_uploaded_date_last.file_name)
            expect(grid_uploaded_date_last['File Reference Id']).to.eq(db_uploaded_date_last.file_ref_id)

        })

        this.firstpage.eq(0).click()

      })


      if(sort_order=='Desc'&& fieldname=="Uploaded Date"){
        this.uploadedDate_header.click()
        cy.wait(1000)
      }

      if(sort_order=='Desc' && fieldname=="Modified Date"){
        this.modifiedDate_header.click()
        cy.wait(1000)
      }

}


griddata(query,config){

  cy.wait(3000)

  this.total_page.eq(0).then(($el) => {
    let gridData=[];

    const page_count = $el.text()

    for(let i=0;i<page_count;i++){

      this.History_gridData.getAgGridData().then((actualTableData)=>{
        
        gridData=gridData.concat(actualTableData)
        

        if(i==page_count-1){
          console.log(gridData)
          cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: query
          }).then((result) => {

            console.log(result.rows)

            expect(result.rows.length).to.eq(gridData.length)
           

            for(let i=0;i<result.rows.length/5;i++){
              expect(result.rows[i]["file_ref_id"]).to.eq(gridData[i]["File Reference Id"])
              expect(result.rows[i]["uploaded_date"]).to.eq(gridData[i]["Uploaded Date (UTC)"])
              expect(result.rows[i]["dset_cd"]).to.eq(gridData[i]["Dataset"])
              expect(result.rows[i]["submission_period"]).to.eq(gridData[i]["Submission Period"])
              expect(result.rows[i]["submitted_by"]).to.eq(gridData[i]["Submitted By"])
              expect(result.rows[i]["partner"]).to.eq(gridData[i]["Partner"])
              expect(result.rows[i]["file_name"]).to.eq(gridData[i]["File Name"])
              expect(result.rows[i]["rows_loaded"]).to.eq(parseInt(gridData[i]["Rows Loaded"]))
              expect(result.rows[i]["restatement"]).to.eq(gridData[i]["Restatement"])
              expect(result.rows[i]["file_status"]).to.eq(gridData[i]["File Status"])
              expect(result.rows[i]["enriched_file"]).to.eq(gridData[i]["Enriched File"])
              expect(result.rows[i]["chg_agnt_id"]).to.eq(gridData[i]["Modified By"])
              expect(result.rows[i]["modified_date"]).to.eq(gridData[i]["Modified Date (UTC)"])
              expect(result.rows[i]["dup_ind"]).to.eq(gridData[i]["Duplicate"])

            }

          })
        }
        
      })

      this.nextpage.eq(0).click()

    }

    

  })

  this.firstpage.eq(0).click()
  

}


action_pagination(){
  cy.wait(3000)
  this.pagecount_button.last().then(($el) => {
      const overall_count = $el.text()

      cy.log(overall_count)

      if(overall_count<=5){
          this.page_number.contains('1')
          this.total_page.contains('1')
         // this.prevpage.should('be.disabled')
          //this.firstpage.should('be.disabled')
          //this.nextpage.should('be.disabled')
          //this.lastpage.should('be.disabled')

          this.History_gridData.getAgGridData().then((actualTableData)=>{
        
              this.firstrow_on_page.first().contains('1')
              this.lastrow_on_page.first().contains(actualTableData.length)
              
            })

      }

      else {

          if(overall_count>5 && overall_count<=10){
              this.pagination(5)

          }

          if(overall_count>10 && overall_count<= 15){
              this.pagination(5)
              this.pagination(10)
              
          }

          if(overall_count>15 && overall_count <=20){
              this.pagination(5)
              this.pagination(10)
              this.pagination(15)
          }

          if(overall_count>20){
              //this.pagination(5)
              this.pagination(10)
              //this.pagination(15)
              this.pagination(20)

          }

      }
  })
}


pagination(pagesize){
if(pagesize==10){
  this.page_size.first().select('10')
}
else if(pagesize==5){
  this.page_size.first().select('5')
}
else if(pagesize==15){
  this.page_size.first().select('15')
}
else if(pagesize=20){
  this.page_size.first().select('20')
}
this.pagecount_button.first().then(($el) => {
  let gridData=[];
  const overall_count = $el.text()
  
  let page_count=Math.floor((overall_count)/pagesize)
  let remainder = overall_count%pagesize
  
 
  if(remainder>0){
    page_count=page_count+1
  }

  if(remainder==0){remainder=pagesize}else{remainder=remainder}
  

  console.log(page_count)
  let j=1;
  

  for(let i=0;i<page_count;i++){
    cy.wait(1000)
    this.History_gridData.getAgGridData().then((actualTableData)=>{
      
      gridData=gridData.concat(actualTableData)
      console.log(gridData)
      
    })

    
    
    this.page_number.first().contains(i+1)
    this.total_page.first().contains(page_count)
    this.firstrow_on_page.first().contains(j)
    if(i==page_count-1){
      this.lastrow_on_page.first().contains(overall_count)
      this.History_gridData.getAgGridData().then((actualTableData)=>{
        //console.log(actualTableData)
        //console.log(remainder)
        expect(actualTableData.length).to.eq(remainder)
        expect(gridData.length).to.eq(parseInt(overall_count))
      })
    }
    else{
      
      this.lastrow_on_page.first().contains((i+1)*pagesize)
      this.History_gridData.getAgGridData().then((actualTableData)=>{
        expect(actualTableData.length).to.eq(pagesize)
      })
    }
    
    this.pagecount_button.first().contains(overall_count)
    this.nextpage.first().click()
    j+=pagesize

    
    


  }




  

  

})

this.firstpage.first().click()
this.page_size.first().select('10')
}


read_csv(filePath,query,config){
  cy.wait(6000)
  
  cy.task("DATABASE", {
    dbConfig: Cypress.env(config),
    sql: query
  }).then((result) => {
   
    const file_name =  result.rows[0]["file_name"]
    const regex =/:/g
    const newFileName = file_name.replaceAll(regex,"_")
    const excelFilePath=filePath+newFileName
    cy.task("readCSVfile_export",excelFilePath).then((result)=>{

      this.rows_loaded.then(($el)=>{
        const rowsloaded = $el.text()
        expect(parseInt(rowsloaded)).to.eq(result)
      })
      
    })
  })


 
  
  
}


file_name_link(){
  cy.get('.ag-header-cell:nth-of-type(6)>div:nth-of-type(3)>.ag-header-icon')
      this.file_name.click()
}


inactive_button_diabled_Validation(){
  this.inactive_button.first().should('have.text','Inactive')
  this.inactive_button.should('be.disabled')

}

inactive_disabled_duplicate(){
  //this.inactive_button.contains(text)
  this.filter_file_status.first().click()
  this.filter_body.eq(0).type("dup")
  cy.wait(1000)
  this.HistoryTab.click()
  this.checkbox.eq(1).click()
  ///this.checkbox.eq(2).click()
  this.inactive_button.should('be.disabled')
  this.checkbox.eq(1).click()
  //this.checkbox.eq(2).click()

  this.filter_file_status.first().click()
  this.filter_body.eq(0).clear()
    this.HistoryTab.click()
}


inactive_button_disabled_inactive_selection_Validation(){
   //this.inactive_button.contains(text)
   this.filter_file_status.first().click()
   this.filter_body.eq(0).type("Inactive")
   cy.wait(1000)
   this.HistoryTab.click()
   this.checkbox.eq(1).click()
   this.checkbox.eq(2).click()
   this.inactive_button.should('be.disabled')
   this.checkbox.eq(1).click()
   this.checkbox.eq(2).click()

   this.filter_file_status.first().click()
   this.filter_body.eq(0).clear()
     this.HistoryTab.click()
}



inactive_button_enabled_selection_Validation(selection,times){
 // homepage.wait3Sec_app()
  //this.inactive_button.contains(text)
  this.filter_file_status.first().click()
  this.filter_body.eq(0).type("Publish")
  cy.wait(3000)
  this.HistoryTab.click()
  this.checkbox.eq(1).click()
  if(selection=='multiple'){
    for(let i=2;i<=times;i++){
      this.checkbox.eq(i).click()
    }
  }
  this.inactive_button.first().should('be.enabled')
  this.inactive_button.first().click()
  if(selection=='single'){ this.inactive_popup_Validation('single')}
  else{ this.inactive_popup_Validation('multiple')}
 
  this.filter_file_status.first().click()
  this.filter_body.eq(0).clear()
  this.filter_body.eq(0).type('inactive')
  cy.wait(2000)

  this.modifiedDate_header.click()
  this.modifiedDate_header.click()
  cy.wait(1000)

  this.History_gridData.getAgGridData().then((actualTableData)=>{
    const inactive_grid_data=[]
    

    if(selection=='single'){ inactive_grid_data[0] = actualTableData[0]}
    else{
      for(let i=0;i<=times-1;i++){
        inactive_grid_data[i] = actualTableData[i]
      }
    }

   
    
   
    // if(selection=='multiple'){
    //   this.checkbox.eq(1).click()
    //   for(let i=2;i<=times;i++){
    //     this.checkbox.eq(i).click()
    //   }
    // }

  this.filter_file_status.first().click()
  this.filter_body.eq(0).clear()
  cy.wait(2000)
    this.HistoryTab.click()

    if(selection=='single'){this.filter_inactive_fil_ref_id(inactive_grid_data[0]['File Reference Id'])}
    else{
      for(let i=0;i<inactive_grid_data.length;i++){
        this.filter_inactive_fil_ref_id(inactive_grid_data[i]['File Reference Id'])
      }
    }


    this.modifiedDate_header.click()
    cy.wait(1000)

})



  

}

 formatAMPM(date) {
  var hours = date.getUTCHours();
  var minutes = date.getUTCMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  hours = hours < 12 ? '0'+hours : hours
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  return strTime;
}


filter_inactive_fil_ref_id(fil_ref_id){
  var date = new Date();
const monthNames = ["January", "February", "March", "April", "May", "June",
          "July", "August", "September", "October", "November", "December"
        ];

  this.filter_file_reference_id.first().click()
  cy.wait(3000)
    this.filter_body.eq(0).type(fil_ref_id)
    cy.wait(3000)
    this.HistoryTab.click()
    this.History_gridData.getAgGridData().then((actualTableData)=>{
      const inactive_grid_data = actualTableData[0]
      
      expect(inactive_grid_data['File Status']).to.eq('Inactive')
      expect(inactive_grid_data['Modified Date (UTC)'].slice(0,12)).to.eq(monthNames[date.getUTCMonth()].slice(0,3)+" "+ (String(date.getUTCDate()).length<2?'0'+date.getUTCDate():date.getUTCDate())+", "+date.getUTCFullYear())
      this.filter_file_reference_id.first().click()
    this.filter_body.eq(0).clear()
    this.HistoryTab.click()
    


      

    })


}

inactive_popup_Validation(selected){

  this.inactive_popup_button_close.click()
  this.inactive_button.first().click()
  cy.wait(3000)
  this.inactive_popup_cancel_buton.contains('Cancel')
  this.inactive_popup_cancel_buton.click()
  this.inactive_button.first().click()
  //this.inactive_popup_title.contains('Please provide reason to inactivate the set of selected files:')
  this.inactive_popup_description.contains('Please provide reason to inactivate the set of selected files:')
  if(selected=='single'){this.inactive_popup_note.should('not.exist')}
  else{
    this.inactive_popup_note.should('exist')
    this.inactive_popup_note.contains('The above reason will be applicable to inactive all the selected files. In case, you want to provide different reasons, please select single/group of files.')
  }
  this.inactive_popup_inactive_button.should('be.disabled')
  this.inactive_popup_textarea.type('Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis,')
  this.inactive_popup_inactive_button.contains('Inactive')
  this.inactive_popup_inactive_button.should('be.enabled')
  this.inactive_popup_inactive_button.click()
  cy.wait(5000)



}

}

export default new upload_histroy();
