//const save_data = require('../data/saved_filter')

class saved_filters {
  get show_filter_button() {
    return cy.xpath(
      '//*[@id="uncontrolled-tab-example-tabpane-History"]/div[1]/div/button[1]/span'
    );
  }

  get collapse_filter(){
    return cy.get('.collapse.show')
  }

  get saved_filters_tab(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tab-Filters"]')
  }

  

  get clear_all(){
    return cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(3)>div>div>button:nth-of-type(1)')
  }

  get submission_period(){
    return cy.get('.rmdp-input')
  }

  get submission_month(){
    return ['.rmdp-month-picker>div:nth-of-type(1)>div:nth-of-type(1)>span',
    '.rmdp-month-picker>div:nth-of-type(1)>div:nth-of-type(2)>span',
    '.rmdp-month-picker>div:nth-of-type(1)>div:nth-of-type(3)>span',
    '.rmdp-month-picker>div:nth-of-type(2)>div:nth-of-type(1)>span',
    '.rmdp-month-picker>div:nth-of-type(2)>div:nth-of-type(2)>span',
    '.rmdp-month-picker>div:nth-of-type(2)>div:nth-of-type(3)>span',
    '.rmdp-month-picker>div:nth-of-type(3)>div:nth-of-type(1)>span',
    '.rmdp-month-picker>div:nth-of-type(3)>div:nth-of-type(2)>span',
    '.rmdp-month-picker>div:nth-of-type(3)>div:nth-of-type(3)>span',
    '.rmdp-month-picker>div:nth-of-type(4)>div:nth-of-type(1)>span',
    '.rmdp-month-picker>div:nth-of-type(4)>div:nth-of-type(2)>span',
    '.rmdp-month-picker>div:nth-of-type(4)>div:nth-of-type(3)>span']
    
  }

  get HistoryTab(){
    return cy.get('#uncontrolled-tab-example-tab-History')
}

    get partner_filter(){
    return cy.xpath('//*[@id="filter"]/div[1]/div[1]/div[2]')

    
  }

  get all_partner_filter(){
    return cy.get('.css-11unzgr>div:nth-of-type(1)>div>input')
  }

  get submission_period_value(){
    return cy.get('.rmdp-input')
  }

  get save_filter_form(){
    cy.get('#formBasicEmail')
  }

  get save_filter_button(){
    return cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(3)>div>div>button:nth-of-type(2)')
  }

  get save_filter_filter_after_selection(){
    return cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(4)>div>div>button:nth-of-type(2)')
  }

  get filter_apply_button(){
    return cy.get('#uncontrolled-tab-example-tabpane-Filters>div>div:nth-of-type(3)>div>div>button:nth-of-type(3)')
  }

  get filter_apply_button_after(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-Filters"]/div/div[4]/div/div/button[3]')
  }

  

  get date_picker_left_arrow(){
    return cy.get('.rmdp-arrow-container.rmdp-left')
  }

  get date_picker_right_arrow(){
    return cy.get('.rmdp-arrow-container.rmdp-right')
  }

  get date_picker(){
    return cy.get('.rmdp-input')
  }

  get start_range(){
    return cy.get('.rmdp-panel-body>li:nth-of-type(1)')
  }

  get end_range(){
    return cy.get('.rmdp-panel-body>li:nth-of-type(2)')

    
  }

  get pagecount_button() {
    return cy.get(".ag-paging-panel>span>span:nth-of-type(5)");
  }

  get prev_month_arrow(){
    return cy.xpath('/html/body/div[5]/div[2]/div/div/div/div[1]/div[1]/div/span[1]/i')
  }

  get next_month_arrow(){
    return cy.xpath('/html/body/div[5]/div[2]/div/div/div/div[1]/div[1]/div/span[2]/i')
  }

  get save_filter(){
    return cy.xpath('//*[@id="btnSaveFilter"]')
  }

  get save_filter_input(){
    return cy.xpath('//*[@id="formBasicEmail"]')
  }

  get save_button(){
    return cy.xpath('//*[@id="btnSave"]')
  }


  get user_profile(){
    return cy.xpath('//*[@id="nav-dropdown-light-example"]')
  }

  get email_addr(){
    return cy.xpath('//*[@id="navbar-light-example"]/div/div/div/span[2]')
  }

  get saved_filters(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tab-SavedFilters"]')
  }

  get saved_filters_dropdown(){
    return cy.xpath('//*[@id="savedFilters"]')
  }

  get saved_filters_apply_button(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-SavedFilters"]/div/div[2]/div/div/button[2]')
  }

  get make_as_default_button(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-SavedFilters"]/div/div[2]/div/div/button[1]')
  }

  get saved_submission_period(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-SavedFilters"]/div/div[1]/div[3]/div/div[1]')
  }

  get all_partners(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-SavedFilters"]/div/div[1]/div[3]/div/div[2]')
  }

  get default_ind(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-SavedFilters"]/div/div[1]/div[3]/div/span')
  }

 

  /*  **************                   methods            *************          */


  access_token_storage(){
    cy.request({method: 'POST',
    url: 'https://login.microsoftonline.com/46c98d88-e344-4ed4-8496-4ed7712e255d/oauth2/token', // baseUrl is prepend to URL
    form: true, // indicates the body should be form urlencoded and sets Content-Type: application/x-www-form-urlencoded headers
    body: {
        client_id: "c6c423fb-935a-4eba-8032-9af931e8d21f",
        client_secret: "daW8Q~UDTUDMITt2VuOCG~QIIyo2AYzwqZdUecjO",
        grant_type: "client_credentials",
        scope:'c6c423fb-935a-4eba-8032-9af931e8d21f/.default',
        resource:"00000002-0000-0000-c000-000000000000"
       
    },
  }).then(
(response) => {
  console.log(response)
  localStorage.setItem("accessToken",'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IjJaUXBKM1VwYmpBWVhZR2FYRUpsOGxWMFRPSSIsImtpZCI6IjJaUXBKM1VwYmpBWVhZR2FYRUpsOGxWMFRPSSJ9.eyJhdWQiOiJjNmM0MjNmYi05MzVhLTRlYmEtODAzMi05YWY5MzFlOGQyMWYiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC80NmM5OGQ4OC1lMzQ0LTRlZDQtODQ5Ni00ZWQ3NzEyZTI1NWQvIiwiaWF0IjoxNjY0NTQwMTEwLCJuYmYiOjE2NjQ1NDAxMTAsImV4cCI6MTY2NDU0NTU1MCwiYWNyIjoiMSIsImFpbyI6IkFWUUFxLzhUQUFBQVc1Y1FZaDdhTkVEcW43VFhGWGVwbjRoZFFsNjJuSmYvZmJFZitrdHREalUrTSthMGh6WkRjR0tHa21hM1puMjVwT2VTdm1JS2l3NXdreEd5UVZVcFVPMjNiUHRYbGI4TlgxY3lnUUw3Q3AwPSIsImFtciI6WyJwd2QiLCJyc2EiLCJtZmEiXSwiYXBwaWQiOiJjNmM0MjNmYi05MzVhLTRlYmEtODAzMi05YWY5MzFlOGQyMWYiLCJhcHBpZGFjciI6IjAiLCJkZXZpY2VpZCI6IjlkNGIyOWUzLWI4MTAtNDliMC04N2EzLTZlMTJlZTBiMTE4ZCIsImlwYWRkciI6IjE5Mi41NS43OS4xNzEiLCJvaWQiOiIwNzhiYTRhYy00ODkxLTQ4MzMtYjZlNy04NzdiYmNkNDUxMGMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMTAwNDMzNjM0OC0xMzgzMzg0ODk4LTE0MTcwMDEzMzMtMTIxNDg5MiIsInJoIjoiMC5BUTBBaUkzSlJrVGoxRTZFbGs3WGNTNGxYZnNqeE1aYWs3cE9nREthLVRIbzBoOE5BS3cuIiwicm9sZXMiOlsidGVzdCJdLCJzY3AiOiJVc2VyLlJlYWQiLCJzdWIiOiJDa2h1TFozWXhBaUVvckhmaExWcmlTUzRHZEhyMnB0WGNpck1GOWJvY180IiwidGlkIjoiNDZjOThkODgtZTM0NC00ZWQ0LTg0OTYtNGVkNzcxMmUyNTVkIiwidW5pcXVlX25hbWUiOiJ2aWduZXNoeC5zZWthckBpbnRlbC5jb20iLCJ1cG4iOiJ2aWduZXNoeC5zZWthckBpbnRlbC5jb20iLCJ1dGkiOiJ2Vi1RbGNOSVJVTy1XR0FZbVpnRkFBIiwidmVyIjoiMS4wIn0.CRDyu5aqUAO0DgCUZVXNjXuQO3Ta5tJJrn-EnQ4e3T_GD6v6_tCNFEDE129UTl6mNfjJ_SxlGZDnO5MYE_M3vaWh6n_J9mgBWmW6ehaK9OSC53-PDOMy7hYNSoqfz7BZgWLwuRsoZXUtDgm2X9NXWLfR_tmFEuvcY2tid4ObyjwmE542QSdBrVlYT80FXAJFJ1IDS4NDBSPO3gc7K6iK0jJc-PX_pI962FBI6DA6CLboSLcV6gzKTOnY5YAF-xbTRxPvY-IrQwNQcPbrxdBCceRfU211PNj53szRyxtlTqvk38AcELtQUhi7ZT38Jla6QJO57Cv7Gw_COS68JhDyUA')
})
  }

  role_change(config,role_id){
    this.user_profile.click()
    //this.email_addr.should('have.text',result.rows[0].email_addr)

    this.email_addr.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql:` update cdm_accs_enttl.prncpl_role_asgn set role_id=`+role_id+` where prncpl_id = (select prncpl_id from cdm_accs_enttl.usr where email_addr='`+$el.text()+`')`
  
      })
    })

    cy.reload()
    cy.wait(5000)
   // this.publish_button.should('be.visible')
   // this.publish_button.should('have.text','Publish')

    
  
  }

  show_hide_filter(show_filter, hide_filter) {
    cy.wait(6000);
    this.show_filter_button.contains(show_filter);
    this.show_filter_button.click();
    this.collapse_filter.should("be.visible");
    this.show_filter_button.contains(hide_filter);
    this.show_filter_button.click();
    this.show_filter_button.contains(show_filter);
  }

  run_query(query,config){
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: query
    }).then((result) => {
        

    })

  }


  make_dflt_ind(role,config){
    const excelFilePath='./cypress/fixtures/input_data.xlsx'
    const sheetName = 'Save_filters'
  
    cy.task('generateJSONFromExcel',{excelFilePath,sheetName}).then((user)=>{
      for(let i=0;i<user.length;i++){
        if(role==user[i].Filter_Name){
         // cy.log(user[i].expected_columns.split(","))
          this.run_query(user[i].Filter_Description,config)
          
        }
      }
    })
  }
  




  // all_partner_check(){
  //   for(let i=1;i<7;i++){
  //       cy.get(' .css-1hwfws3>div:nth-of-type('+i+')>div:nth-of-type(1)').should('have.value',save_data.partners[i-1])
  //   }
  // }

  curr_month(){
    const d = new Date();
    const End_Month = d.getMonth()
    let end_month_added;
    if((End_Month+1)<10){end_month_added='0'+(End_Month+1)}else{end_month_added=(End_Month+1)}
    cy.get(this.submission_month[End_Month]).click()
    cy.get(this.submission_month[End_Month]).click()
    this.submission_period_value.should('have.value',end_month_added+'/'+(d.getFullYear())+' ~ '+end_month_added+'/'+(d.getFullYear()))
  }

  saving_filter(text){
    this.save_filter_button.click()
    this.save_filter_form.type(text)
    this.save_filter_filter_after_selection.click()
    this.filter_apply_button.click()
  }

  checking_in_dflt_sec(){
    
  }

  saving_filter_curr_month(){
    
    
    this.show_filter_button.click();
    this.clear_all.first().click();
    this.submission_period.click();
    this.curr_month()
    this.HistoryTab.click()
    this.partner_filter.click()
    cy.wait(3000)
    this.all_partner_filter.click()
    cy.wait(3000)
    this.all_partner_check()
    this.HistoryTab.click()
    this.saving_filter('curr_month')
    checking_in_dflt_sec()
  }


  future_months_disabled_current_month_enabled(){
    cy.wait(3000)
    this.show_filter_button.click()
    cy.get('.rmdp-input').click()

    const d = new Date();
    let month = d.getMonth();


    for(let i=month;i<=11;i++){
      if(i==month){
        cy.get(this.submission_month[i]).should('have.css', 'background-color', 'rgb(127, 219, 255)')
    cy.get(this.submission_month[i]).should('have.css', 'color', 'rgb(255, 255, 255)')
      }
      else{cy.get(this.submission_month[i]).should('have.css', 'color', 'rgb(135, 152, 173)')}
      
    }

    for(let j=0;j<month;j++){
      cy.get(this.submission_month[j]).should('have.css', 'color', 'rgb(0, 0, 0)')
    }

    this.HistoryTab.click()
  }

  past_months_disabled_current_month_enabled(){
    cy.wait(3000)
    cy.get('.rmdp-input').click()
  this.date_picker_left_arrow.click()
    const d = new Date();
    let month = d.getMonth();


    for(let i=month;i<=11;i++){
      cy.get(this.submission_month[i]).should('have.css', 'color', 'rgb(0, 0, 0)')
      
      
    }

    for(let j=0;j<month;j++){
      
      cy.get(this.submission_month[j]).should('have.css', 'color', 'rgb(135, 152, 173)')
    }

    this.HistoryTab.click()
  }

  months_highlighted(){

    const d = new Date();
      let month = d.getMonth();
    cy.wait(3000)
    this.date_picker.click()
    cy.get(this.submission_month[month]).click()
    cy.get(this.submission_month[0]).click()
    this.HistoryTab.click()
    this.date_picker.click()

    this.date_picker.invoke('val').then((value) => {

      let date_picker_value=value.split('~')

      this.start_range.contains(date_picker_value[0].trim())
       this.end_range.contains(date_picker_value[1].trim())
       this.start_range.should('have.css', 'background-color', 'rgb(0, 116, 217)')
      this.end_range.should('have.css', 'background-color', 'rgb(0, 116, 217)')

      if(date_picker_value[0].includes(d.getFullYear()) && date_picker_value[1].includes(d.getFullYear())){
        let start = (date_picker_value[0].trim().substring(0,date_picker_value[0].length-6)*1).toString()
        let end = (date_picker_value[1].trim().substring(0,date_picker_value[1].length-6)*1).toString()

       

        for (let i=start;i<=end-1;i++){
          cy.get(this.submission_month[i-1].substring(0,this.submission_month[i-1].length-5)).should('have.css', 'background-color', 'rgb(0, 116, 217)')
        }


      }
    })

      this.date_picker.click()
      this.date_picker_left_arrow.click()
      cy.get(this.submission_month[month]).click()
     this.date_picker_right_arrow.click()
     cy.get(this.submission_month[month]).click()


     this.date_picker.invoke('val').then((value) => {

      let date_picker_value=value.split('~')

      this.start_range.contains(date_picker_value[0].trim())
       this.end_range.contains(date_picker_value[1].trim())
       this.start_range.should('have.css', 'background-color', 'rgb(0, 116, 217)')
      this.end_range.should('have.css', 'background-color', 'rgb(0, 116, 217)')

         if(date_picker_value[0].includes(d.getFullYear()-1) && date_picker_value[1].includes(d.getFullYear())){
        let start = (date_picker_value[0].trim().substring(0,date_picker_value[0].length-6)*1).toString()
        let end = (date_picker_value[1].trim().substring(0,date_picker_value[1].length-6)*1).toString()

        
        this.date_picker_left_arrow.click()

        for (let i=start;i<=12;i++){
          cy.get(this.submission_month[i-1].substring(0,this.submission_month[i-1].length-5)).should('have.css', 'background-color', 'rgb(0, 116, 217)')
        }

        this.date_picker_right_arrow.click()

        for (let i=0;i<=end-1;i++){
          cy.get(this.submission_month[i].substring(0,this.submission_month[i].length-5)).should('have.css', 'background-color', 'rgb(0, 116, 217)')
        }



      }

    })



      this.date_picker.click()
      this.date_picker_left_arrow.click()
      cy.get(this.submission_month[month]).click()
      cy.get(this.submission_month[11]).click()


      this.date_picker.invoke('val').then((value) => {

        let date_picker_value=value.split('~')
  
        this.start_range.contains(date_picker_value[0].trim())
         this.end_range.contains(date_picker_value[1].trim())
         this.start_range.should('have.css', 'background-color', 'rgb(0, 116, 217)')
        this.end_range.should('have.css', 'background-color', 'rgb(0, 116, 217)')


      if(date_picker_value[0].includes(d.getFullYear()-1) && date_picker_value[1].includes(d.getFullYear()-1)){
        let start = (date_picker_value[0].trim().substring(0,date_picker_value[0].length-6)*1).toString()
        let end = (date_picker_value[1].trim().substring(0,date_picker_value[1].length-6)*1).toString()

        
        this.date_picker_left_arrow.click()

        for (let i=start;i<=end;i++){
          cy.get(this.submission_month[i-1].substring(0,this.submission_month[i-1].length-5)).should('have.css', 'background-color', 'rgb(0, 116, 217)')
        }


      }

    })


  

       this.HistoryTab.click()
  
   


    //cy.get(this.submission_month[1].substring(0,this.submission_month[1].length-5)).should('have.css', 'background-color', 'rgb(0, 116, 217)')

  }
  
  partner_dropdown(query,config){
    let xyz=1;
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: query
    }).then((result) => {
    //     console.log(result)
     this.partner_filter.click()
    // for(let i=0;i<result.rowCount;i++){
    //   cy.get('#react-select-2-listbox').find('.css-11unzgr').contains(result.rows[i].org_nm).click()
    //   cy.get('.css-1rhbuit-multiValue:nth-of-type(1)>div').contains(result.rows[i].org_nm)
    //   cy.get(' .css-11unzgr>div:nth-of-type('+(i+2)+')>div>input').should('be.checked')
    // }

    // cy.get(' .css-11unzgr>div:nth-of-type(1)>div>input').should('be.checked')

    // let j=result.rowCount
    // for(let i=0; i<result.rowCount;i++){

    // cy.get('.css-1rhbuit-multiValue:nth-of-type(1)>div:nth-of-type(2)').click()
    // cy.get(' .css-11unzgr>div:nth-of-type('+(j+1)+')>div>input').should('not.be.checked');
    // cy.get(' .css-11unzgr>div:nth-of-type(1)>div>input').should('not.be.checked')
    // j--;

    // }


    cy.get('#react-select-2-listbox>div>div:nth-of-type(1)>div>label').contains('All').click()

    for(let i=0;i<result.rowCount;i++){
      
      cy.get(' .css-11unzgr>div:nth-of-type('+(i+2)+')>div>input').should('be.checked')
    }


    

      for(let i=2;i<=result.rowCount+1;i=i+2){

            cy.get('#react-select-2-listbox>div>div:nth-of-type('+i+')>div>label').contains(result.rows[i-2].org_nm).click()
              cy.get('#react-select-2-listbox>div>div:nth-of-type('+i+')>div>input').should('not.be.checked')

              // cy.get('.css-1rhbuit-multiValue:nth-of-type(1)>div:nth-of-type(1)').then(($el) => {

              //        cy.get('.css-1rhbuit-multiValue:nth-of-type('+i+')>div:nth-of-type(2)').click()
              //        const org = $el.text()

              // })

            }

           

            for(let i=1;i<result.rowCount/2;i++){

              
              cy.get('.css-1rhbuit-multiValue:nth-of-type('+(i)+')>div:nth-of-type(1)').then(($el) => {
                const org = $el.text()
                console.log(result.rows[0].org_nm)
                console.log(xyz)
                console.log(result.rows[xyz].org_nm)
                expect(org).to.eq(result.rows[xyz].org_nm)
  
               // cy.get('.css-1rhbuit-multiValue:nth-of-type('+i+')>div:nth-of-type(2)')
                  
  
                })
               
                xyz=xyz+1; 
              }
        
            
    



       

    

    // for(let i=1;i<=result.rowCount;i++){

    //   cy.get('.css-1rhbuit-multiValue:nth-of-type(1)>div:nth-of-type(1)').then(($el) => {

    //     cy.get('.css-1rhbuit-multiValue:nth-of-type('+i+')>div:nth-of-type(2)').click()
    //     const org = $el.text()
        
    //    // cy.get('#react-select-2-listbox').find('.css-11unzgr').contains(org).should('not.be.checked');

    //    for(let i=2;i<=result.rowCount+1;i++){

    //     if(cy.get('#react-select-2-listbox>div>div:nth-of-type('+i+')>div>label').contains(org)){
    //       cy.get('#react-select-2-listbox>div>div:nth-of-type('+i+')>div>input').should('not.be.checked')
    //     }
    //   }
        })

     }


  saving_for_different_submission_month(){
    
  }

  current_month_all_partners(config){
    const d = new Date();
      let month = d.getMonth();
      this.clear_all.click()
      this.date_picker.click()
      cy.get(this.submission_month[month]).click()
      cy.get(this.submission_month[month]).click()
      this.saved_filters_tab.click()
      this.partner_filter.click()
      //cy.get('#react-select-2-listbox>div>div:nth-of-type(1)>div>label').contains('All').click()
      cy.get('#react-select-2-listbox>div>div:nth-of-type(1)>div>label').contains('All').click()
      this.saved_filters_tab.click()
      this.filter_apply_button.click()

      this.pagecount_button.first().then(($el) => {
        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: ` select count(*) as cnt   from cdm_core.file_onbord_instc fil 
          inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id 
          inner join cdm_accs_enttl.org org on org.org_id=fil.org_id 
          where fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed') 
          and extract (month FROM fil.file_land_dtm) = extract (month FROM now()) and extract (year FROM fil.file_land_dtm) = extract (year FROM now()) 
          and org.org_nm<>'-1' and org.org_nm<>'Intel'`
        }).then((result) => {
                console.log(result)
               // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
               expect(result.rows[0].cnt).to.eq($el.text())
      

        })
      })
  }


 prev_curr_month_all_partners(config){
  this.clear_all.click()
    const d = new Date();
      let month = d.getMonth();
      this.date_picker.click()
      this.prev_month_arrow.click()
      cy.get(this.submission_month[month]).click()
      this.next_month_arrow.click()
      cy.get(this.submission_month[month]).click()
      this.saved_filters_tab.click()
      this.partner_filter.click()
      cy.get('#react-select-2-listbox>div>div:nth-of-type(1)>div>label').contains('All').click()
      this.saved_filters_tab.click()
      this.filter_apply_button.click()

      this.pagecount_button.first().then(($el) => {
        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: ` select count(*) as cnt from cdm_core.file_onbord_instc fil
          inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                      inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                      inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
           where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                  and   fil.file_land_dtm >= (now() - interval '12 month')
                    and org.org_nm<>'-1' and org.org_nm<>'Intel'`
        }).then((result) => {
                console.log(result)
               // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
               expect(result.rows[0].cnt).to.eq($el.text())
      

        })
      })
  }


  prev_month_all_partners(config){
    this.clear_all.click()
    const d = new Date();
      let month = d.getMonth();
      this.date_picker.click()
      this.prev_month_arrow.click()
      cy.get(this.submission_month[month]).click()
      cy.get(this.submission_month[11]).click()
      this.saved_filters_tab.click()
      this.partner_filter.click()
      cy.get('#react-select-2-listbox>div>div:nth-of-type(1)>div>label').contains('All').click()
      this.saved_filters_tab.click()
      this.filter_apply_button.click()

      this.pagecount_button.first().then(($el) => {
        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: ` 
          select count(*) as cnt from cdm_core.file_onbord_instc fil
inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
 where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
        and fil.file_land_dtm >= (now() - interval '12 month')
          and extract (year FROM fil.file_land_dtm) = extract (year FROM now())-1
          and org.org_nm<>'-1' and org.org_nm<>'Intel'`
        }).then((result) => {
                console.log(result)
               // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
               expect(result.rows[0].cnt).to.eq($el.text())
      

        })
      })
  }

  saving_for_different_partners_1(config){
    this.clear_all.click()
    const d = new Date();
      let month = d.getMonth();
      this.date_picker.click()
      cy.get(this.submission_month[0]).click()
      cy.get(this.submission_month[month]).click()
      this.saved_filters_tab.click()
      this.partner_filter.click()

      //cy.xpath('//*[@id="react-select-2-option-1"]/input').click()
                 //*[@id="react-select-2-option-1"]/input
      //cy.xpath('')

      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: ` 
        select * from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' order by org_nm`
      }).then((result) => {
              console.log(result)
             
              for(let i=1; i<=result.rowCount;i=i+2){
                cy.xpath('//*[@id="react-select-2-option-'+i+'"]/input').click()
              }
    

      })

      this.saved_filters_tab.click()
      this.filter_apply_button.click()


      this.pagecount_button.first().then(($el) => {
        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: ` 
          select count(*) as  cnt from cdm_core.file_onbord_instc fil 
            inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
            where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed') 
            and fil.file_land_dtm >= (now() - interval '12 month')
            and extract (year FROM fil.file_land_dtm) = extract (year FROM now())
            and org.org_nm in (
            select org_nm from (
            select *,rank() over ( order by org_nm asc) as rnk  from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' 
            )a
            where a.rnk%2<>0
                    )`
        }).then((result) => {
                console.log(result)
               // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
               expect(result.rows[0].cnt).to.eq($el.text())
      

        })
      })




    
  }

  saving_for_different_partners_2(config){
    this.clear_all.click()
    const d = new Date();
      let month = d.getMonth();
      this.date_picker.click()
      cy.get(this.submission_month[0]).click()
      cy.get(this.submission_month[month]).click()
      this.saved_filters_tab.click()
      this.partner_filter.click()

      //cy.xpath('//*[@id="react-select-2-option-1"]/input').click()
                 //*[@id="react-select-2-option-1"]/input
      //cy.xpath('')

      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: ` 
        select * from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' order by org_nm`
      }).then((result) => {
              console.log(result)
             
              for(let i=2; i<=result.rowCount;i=i+2){
                cy.xpath('//*[@id="react-select-2-option-'+i+'"]/input').click()
              }
    

      })

      this.saved_filters_tab.click()
      this.filter_apply_button.click()


      this.pagecount_button.first().then(($el) => {
        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: ` 
          select count(*) as  cnt from cdm_core.file_onbord_instc fil 
            inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
            where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed') 
            and fil.file_land_dtm >= (now() - interval '12 month')
            and extract (year FROM fil.file_land_dtm) = extract (year FROM now())
            and org.org_nm in (
            select org_nm from (
            select *,rank() over ( order by org_nm asc) as rnk  from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' 
            )a
            where a.rnk%2=0
                    )`
        }).then((result) => {
                console.log(result)
               // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
               expect(result.rows[0].cnt).to.eq($el.text())
      

        })
      })




    
  }

  saving_filter_combination(config){
   this.saved_filters_tab.click()
    const d = new Date();
      let month = d.getMonth();
      let year = d.getFullYear();
let mon_name = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

    this.clear_all.click()
    this.current_month_all_partners(config)
    this.save_filter.click()
    this.save_filter_input.type('Saving_filter_test')
    this.filter_apply_button_after.click()
    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: ` select count(*) as cnt from cdm_core.file_onbord_instc fil 
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id 
        inner join cdm_accs_enttl.org org on org.org_id=fil.org_id 
        where fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed') 
        and extract (month FROM fil.file_land_dtm) = extract (month FROM now()) and extract (year FROM fil.file_land_dtm) = extract (year FROM now()) 
        and org.org_nm<>'-1' and org.org_nm<>'Intel'`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })

    this.save_button.click()
    cy.wait(2000)
   // this.clear_all.click()

    this.saved_filters.click()
    this.saved_filters_dropdown.select('Saving_filter_test')


    this.all_partners.then(($el) => {
      let org = $el.text()
      const myorg = org.split(",");
        console.log(myorg)


        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: ` 
          select org_nm from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' order by org_nm`
        }).then((result) => {
                console.log(result)
               
                for(let i=0; i<result.rowCount;i=i+1){
                 // cy.xpath('//*[@id="react-select-2-option-'+i+'"]/input').click()
                 if(i==0){
                  expect(myorg[i]).to.eq(' Partner(s):'+result.rows[i].org_nm)
                 }
                 else{
                  expect(myorg[i]).to.eq(' '+result.rows[i].org_nm)
                 }
                  
                }
      
  
        })

    })

    let derived = ' Submission Period:'+mon_name[month]+', '+year+'\n                  to '+mon_name[month]+', '+year+' '

    this.saved_submission_period.should('have.text',derived)

    // this.saved_submission_period.then(($el) => {

    // //  Submission Period:Sep, 2022 to Sep, 2022


    //     let submission_period = $el.text()
    //     let derived = ' Submission Period:'+mon_name[month]+', '+year+'\n to '+mon_name[month]+', '+year+' '
    //     expect(submission_period).to.eq(derived)
    // })


    this.default_ind.then(($el) => {
      expect('N ').to.eq($el.text())
    })




    this.saved_filters_apply_button.click()

    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `  select count(*) as cnt from cdm_core.file_onbord_instc fil 
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id 
        inner join cdm_accs_enttl.org org on org.org_id=fil.org_id 
        where fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed') 
        and extract (month FROM fil.file_land_dtm) = extract (month FROM now()) and extract (year FROM fil.file_land_dtm) = extract (year FROM now()) 
        and org.org_nm<>'-1' and org.org_nm<>'Intel'
`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })


    this.saved_filters_tab.click()
    this.filter_apply_button.click()

    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `  select count(*) as cnt from cdm_core.file_onbord_instc fil
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
         where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                  and extract (month FROM fil.file_land_dtm) = extract (month FROM now()) and extract (year FROM fil.file_land_dtm) = extract (year FROM now()) 
                  and org.org_nm<>'-1' and org.org_nm<>'Intel'`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })

    

  } 


  saving_filter_combination_II(config){
    this.saved_filters_tab.click()
    this.clear_all.click()
    const d = new Date();
      let month = d.getMonth();
      let year = d.getFullYear();
      let previous = d.getFullYear()-1;
let mon_name = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

    this.clear_all.click()
    this.prev_curr_month_all_partners(config)



    this.save_filter.click()
    this.save_filter_input.clear()
    this.save_filter_input.type('Saving_filter_test')
    this.filter_apply_button_after.click()
    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: ` select count(*) as cnt from cdm_core.file_onbord_instc fil
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
         where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                and   fil.file_land_dtm >= (now() - interval '12 month')
                  and org.org_nm<>'-1' and org.org_nm<>'Intel'`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })

    this.save_button.click()
    cy.wait(2000)
   // this.clear_all.click()

    this.saved_filters.click()
    this.saved_filters_dropdown.select('Saving_filter_test')


    this.all_partners.then(($el) => {
      let org = $el.text()
      const myorg = org.split(",");
        console.log(myorg)


        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: ` 
          select org_nm from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' order by org_nm`
        }).then((result) => {
                console.log(result)
               
                for(let i=0; i<result.rowCount;i=i+1){
                 // cy.xpath('//*[@id="react-select-2-option-'+i+'"]/input').click()
                 if(i==0){
                  expect(myorg[i]).to.eq(' Partner(s):'+result.rows[i].org_nm)
                 }
                 else{
                  expect(myorg[i]).to.eq(' '+result.rows[i].org_nm)
                 }
                  
                }
      
  
        })

    })

    let derived = ' Submission Period:'+mon_name[month]+', '+previous+'\n                  to '+mon_name[month]+', '+year+' '

    this.saved_submission_period.should('have.text',derived)

    // this.saved_submission_period.then(($el) => {

    // //  Submission Period:Sep, 2022 to Sep, 2022


    //     let submission_period = $el.text()
    //     let derived = ' Submission Period:'+mon_name[month]+', '+year+'\n to '+mon_name[month]+', '+year+' '
    //     expect(submission_period).to.eq(derived)
    // })


    this.default_ind.then(($el) => {
      expect('N ').to.eq($el.text())
    })




    this.saved_filters_apply_button.click()
    cy.wait(3000)
    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `  select count(*) as cnt from cdm_core.file_onbord_instc fil
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
         where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                and   fil.file_land_dtm >= (now() - interval '12 month')
                  and org.org_nm<>'-1' and org.org_nm<>'Intel'`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })


    this.saved_filters_tab.click()
    this.filter_apply_button.click()

    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `   select count(*) as cnt from cdm_core.file_onbord_instc fil
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
         where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                and   fil.file_land_dtm >= (now() - interval '12 month')
                  and org.org_nm<>'-1' and org.org_nm<>'Intel'`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })

    

  } 


  saving_filter_combination_III(config){
    //this.show_filter_button.click();
    this.saved_filters_tab.click()
    this.clear_all.click()
    const d = new Date();
      let month = d.getMonth();
      let year = d.getFullYear();
      let previous = d.getFullYear()-1;
let mon_name = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

    this.clear_all.click()
    this.prev_month_all_partners(config)



    this.save_filter.click()
    this.save_filter_input.clear()
    this.save_filter_input.type('Saving_filter_test')
    this.filter_apply_button_after.click()
    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `select count(*) as cnt from cdm_core.file_onbord_instc fil
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
         where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                and fil.file_land_dtm >= (now() - interval '12 month')
                  and extract (year FROM fil.file_land_dtm) = extract (year FROM now())-1
                  and org.org_nm<>'-1' and org.org_nm<>'Intel'`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })

    this.save_button.click()
    cy.wait(2000)
   // this.clear_all.click()

    this.saved_filters.click()
    this.saved_filters_dropdown.select('Saving_filter_test')


    this.all_partners.then(($el) => {
      let org = $el.text()
      const myorg = org.split(",");
        console.log(myorg)


        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: ` 
          select org_nm from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' order by org_nm`
        }).then((result) => {
                console.log(result)
               
                for(let i=0; i<result.rowCount;i=i+1){
                 // cy.xpath('//*[@id="react-select-2-option-'+i+'"]/input').click()
                 if(i==0){
                  expect(myorg[i]).to.eq(' Partner(s):'+result.rows[i].org_nm)
                 }
                 else{
                  expect(myorg[i]).to.eq(' '+result.rows[i].org_nm)
                 }
                  
                }
      
  
        })

    })

    let derived = ' Submission Period:'+mon_name[month]+', '+previous+'\n                  to '+mon_name[11]+', '+previous+' '

    this.saved_submission_period.should('have.text',derived)

    // this.saved_submission_period.then(($el) => {

    // //  Submission Period:Sep, 2022 to Sep, 2022


    //     let submission_period = $el.text()
    //     let derived = ' Submission Period:'+mon_name[month]+', '+year+'\n to '+mon_name[month]+', '+year+' '
    //     expect(submission_period).to.eq(derived)
    // })


    this.default_ind.then(($el) => {
      expect('N ').to.eq($el.text())
    })




    this.saved_filters_apply_button.click()
    cy.wait(3000)
    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `select count(*) as cnt from cdm_core.file_onbord_instc fil
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
         where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                and fil.file_land_dtm >= (now() - interval '12 month')
                  and extract (year FROM fil.file_land_dtm) = extract (year FROM now())-1
                  and org.org_nm<>'-1' and org.org_nm<>'Intel'`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })


    this.saved_filters_tab.click()
    this.filter_apply_button.click()

    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: ` select count(*) as cnt from cdm_core.file_onbord_instc fil
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
         where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                and fil.file_land_dtm >= (now() - interval '12 month')
                  and extract (year FROM fil.file_land_dtm) = extract (year FROM now())-1
                  and org.org_nm<>'-1' and org.org_nm<>'Intel'`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })

    

  } 


  saving_filter_combination_IV(config){
    this.saved_filters_tab.click()
    this.clear_all.click()
    const d = new Date();
      let month = d.getMonth();
      let year = d.getFullYear();
      let previous = d.getFullYear()-1;
let mon_name = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

    this.clear_all.click()
    this.saving_for_different_partners_1(config)



    this.save_filter.click()
    this.save_filter_input.clear()
    this.save_filter_input.type('Saving_filter_test')
    this.filter_apply_button_after.click()
    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: ` select count(*) as  cnt from cdm_core.file_onbord_instc fil 
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
        inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
        inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
        where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed') 
        and fil.file_land_dtm >= (now() - interval '12 month')
        and extract (year FROM fil.file_land_dtm) = extract (year FROM now())
        and org.org_nm in (
        select org_nm from (
        select *,rank() over ( order by org_nm asc) as rnk  from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' 
        )a
        where a.rnk%2<>0
                )`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })

    this.save_button.click()
    cy.wait(2000)
   // this.clear_all.click()

    this.saved_filters.click()
    this.saved_filters_dropdown.select('Saving_filter_test')


    this.all_partners.then(($el) => {
      let org = $el.text()
      const myorg = org.split(",");
        console.log(myorg)


        cy.task("DATABASE", {
          dbConfig: Cypress.env(config),
          sql: ` 
          select org_nm from (
            select *,rank() over ( order by org_nm asc) as rnk  from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' 
            )a where a.rnk%2<>0 order by org_nm desc `
        }).then((result) => {
                console.log(result)
               
                for(let i=0; i<result.rowCount;i=i+1){
                 // cy.xpath('//*[@id="react-select-2-option-'+i+'"]/input').click()
                 if(i==0){
                  expect(myorg[i]).to.eq(' Partner(s):'+result.rows[i].org_nm)
                 }
                 else{
                  expect(myorg[i]).to.eq(' '+result.rows[i].org_nm)
                 }
                  
                }
      
  
        })

    })

    let derived = ' Submission Period:'+mon_name[0]+', '+year+'\n                  to '+mon_name[month]+', '+year+' '

    this.saved_submission_period.should('have.text',derived)

    // this.saved_submission_period.then(($el) => {

    // //  Submission Period:Sep, 2022 to Sep, 2022


    //     let submission_period = $el.text()
    //     let derived = ' Submission Period:'+mon_name[month]+', '+year+'\n to '+mon_name[month]+', '+year+' '
    //     expect(submission_period).to.eq(derived)
    // })


    this.default_ind.then(($el) => {
      expect('N ').to.eq($el.text())
    })




    this.saved_filters_apply_button.click()
    cy.wait(3000)
    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: ` select count(*) as  cnt from cdm_core.file_onbord_instc fil 
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
        inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
        inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
        where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed') 
        and fil.file_land_dtm >= (now() - interval '12 month')
        and extract (year FROM fil.file_land_dtm) = extract (year FROM now())
        and org.org_nm in (
        select org_nm from (
        select *,rank() over ( order by org_nm asc) as rnk  from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' 
        )a
        where a.rnk%2<>0
                )`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })


    this.saved_filters_tab.click()
    this.filter_apply_button.click()

    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: ` select count(*) as  cnt from cdm_core.file_onbord_instc fil 
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
        inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
        inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
        where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed') 
        and fil.file_land_dtm >= (now() - interval '12 month')
        and extract (year FROM fil.file_land_dtm) = extract (year FROM now())
        and org.org_nm in (
        select org_nm from (
        select *,rank() over ( order by org_nm asc) as rnk  from cdm_accs_enttl.org where org_nm <> '-1' and org_nm <> 'Intel' 
        )a
        where a.rnk%2<>0
                )`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })

    

  } 


  make_as_default(config){
    this.saved_filters.click()
    this.saved_filters_dropdown.select('Saving_filter_test')

    this.make_as_default_button.click()
    cy.wait(5000)
    this.default_ind.then(($el) => {
      expect('Y ').to.eq($el.text())
    })
    cy.reload()
    cy.wait(10000)
    this.pagecount_button.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: ` select count(*) as cnt from cdm_core.file_onbord_instc fil
        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                    inner join cdm_accs_enttl.org org on org.org_id=fil.org_id
         where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                and fil.file_land_dtm >= (now() - interval '12 month')
                  and extract (year FROM fil.file_land_dtm) = extract (year FROM now())-1
                  and org.org_nm<>'-1' and org.org_nm<>'Intel'`
      }).then((result) => {
              console.log(result)
             // this.pagecount_button.eq(0).should('have.text',result.rows[0].cnt)
             expect(result.rows[0].cnt).to.eq($el.text())
    

      })
    })

  }

  }




export default new saved_filters();
