
class newonboard {
  get configuration_button() {
    return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/a[1]');
  }

  get operation() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[1]/div[1]/div/div[2]/input'
    );
  }

  get new_onboard_button() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[2]/div[2]/div/div[3]/button'
    );
  }

  get onboard_title() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div/h2');
  }

  get onboard_description() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[1]');
  }

  get onboard_description() {
    return cy.get(".main-content>main>div>div:nth-of-type(1)");
  }

  get section1_heading() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[1]/text()');
  }

  get platform_header() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[1]/label'
    );
  }

  get subjectarea_header() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[2]/label'
    );
  }

  get process_header() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[3]/label'
    );
  }

  get dataset_header() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[4]/label'
    );
  }

  get create_template_button() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[2]/div[1]/button');
  }

  get new_template_header() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div/h2');
  }

  get section2_heading() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[1]');
  }

  get new_platform_creation() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[2]/div/div/button/i'
    );
  }

  get new_subject_area_creation() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[4]/div/div/button/i'
    );
  }

  get new_process_creation() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[6]/div/div/button/i'
    );
  }

  get new_dataset_creation() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[2]/div[2]/p/div[8]/div/div/button/i'
    );
  }

  get modal_input1() {
    return cy.xpath('//*[@id="formBasicEmail"]');
  }

  get modal_input2() {
    return cy.get('//*[@id="formBasicEmail"]');
  }

  get modal_add_button() {
    return cy.xpath('//*[@id="btn"]');
  }

  get dataset_modal_input2() {
    return cy.xpath("/html/body/div[6]/div/div/div[2]/div[2]/input[1]");
  }

  get dataset_modal_input3() {
    return cy.xpath('//*[@id="fileTypeCode"]');
  }

  get dataset_modal_input4() {
    return cy.xpath("/html/body/div[6]/div/div/div[2]/div[2]/input[2]");
  }

  get dataset_modal_input5() {
    return cy.xpath('//*[@id="headerIndicator"]');
  }

  get platform_dropdown() {
    return cy.xpath('//*[@id="platform"]');
  }

  get subject_area_dropdown() {
    return cy.xpath('//*[@id="tier2Name"]');
  }

  get process_dropdown() {
    return cy.xpath('//*[@id="tier3Name"]');
  }

  get dataset_dropdown() {
    return cy.xpath('//*[@id="dataset"]');
  }

  get template_version_dropdown(){
    return cy.xpath('//*[@id="templateVersionPair"]')
  }

  get text_area() {
    return cy.xpath(
      '//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/textarea'
    );
  }

  get template_section_create_template_button() {
    return cy.xpath('//*[@id="btn"]');
  }

  get section2_heading(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[1]')
  }

  get organisation_dropdown_header(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[1]/div/div[1]/div[2]/label')
  }

  get organisation_dropdown(){
    return cy.xpath('//*[@id="organization"]')
  }

  get ingestion_mode_header(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[1]/div/div[2]/div[2]/label')
  }

  get ingestion_mode_dropdown(){
    return cy.xpath('//*[@id="ingestMode"]')
  }

  get add_ingestion_mode_button(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[1]/div/div[2]/div[2]/div/div/button/i')
  }

  get use_case_type(){
    return cy.xpath('//*[@id="useCaseTypeCode"]')
  }

  get retention_before_archival_header(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[2]/div/div[1]/label')
  }

  get retention_before_archival_input(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[2]/div/div[1]/input')
  }


  get retention_before_purge_header(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[2]/div/div[2]/label')
  }

  get retention_before_purge_input(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[2]/div/div[2]/input')
  }


  get restatement_allowed_days_header(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[2]/div/div[3]/label')
  }

  get restatement_allowed_days_input(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[2]/div/div[3]/input')
  }

  get collab_header(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[3]/div/div[1]/label')
  }

  get collab_dropdown(){
    return cy.xpath('//*[@id="collaborationIndicator"]')
  }

  get file_split_header(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[3]/div/div[2]/label')
  }

  get file_split_input(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[3]/div/div[2]/input')
  }

  get org_tmplt_header(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[3]/div/div[3]/label')
  }

  get org_tmplt_input(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div[3]/div/div[3]/input')
  }

  get field_name_input(){
    return cy.xpath('//*[@id="fieldName"]')
  }

  get field_startDate_button(){
    return cy.xpath('//*[@id="startDate"]')
  }

  get field_add_button(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[3]/div[2]/p/div/div/div/form/div/div/div/div[1]/div[2]/div[3]/div[2]/div/div/div/div[6]/button')
  }

  get messages(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/p')
  }

  get input_select_1(){
    return cy.get('.main-content>main>div>div:nth-of-type(4)>div:nth-of-type(2)>p>div:nth-of-type(2)>div>select')
  }

  get input_select_2(){
    return cy.get('.main-content>main>div>div:nth-of-type(4)>div:nth-of-type(2)>p>div:nth-of-type(3)>div>select')
  }

  get input_select_3(){
    return cy.get('.main-content>main>div>div:nth-of-type(4)>div:nth-of-type(2)>p>div:nth-of-type(4)>div>select')
  }

  get input_override_name_1(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[2]/p/div[2]/div[2]/div/input')
                    
  }


  get input_override_name_2(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[2]/p/div[3]/div[2]/div/input')
                    
  }


  get input_override_name_3(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[2]/p/div[4]/div[2]/div/input')
                    
  }

  get override_field_button(){
    return cy.xpath('//*[@id="root"]/div[2]/main/div/div[4]/div[1]/button')
  }

  get onboard_button(){
    return cy.xpath('//*[@id="btn"]')
  }

  get modal_header(){
    return cy.xpath('/html/body/div[6]/div/div/div[1]')
  }

  get modal_body(){
    return cy.xpath('/html/body/div[6]/div/div/div[2]/p')
  }

  get modal_button(){
    return cy.xpath('/html/body/div[6]/div/div/div[3]/button')
  }


  //   Methods  //

  going_to_newonboard_page() {
    this.configuration_button.click();
    cy.wait(2000);
    this.operation.click();
    this.new_onboard_button.contains("Onboard a new File");
    this.new_onboard_button.click();
  }

  checking_title_description() {
    this.onboard_title.should("have.text", "Onboard New Dataset/File");
    this.onboard_description.should("have.text", "Onboard a new Dataset/File.");
  }

  checking_section1_heading() {
    this.section1_heading.should(
      "have.text",
      "Choose Platform, Program/Subject Area, Process Area & Dataset"
    );
  }

  checking_section1_dropdown_header() {
    this.platform_header.should("have.text", "Platform*:");
    this.subjectarea_header.should("have.text", "Program/Subject Area*:");
    this.process_header.should("have.text", "Process Area*:");
    this.dataset_header.should("have.text", "Dataset*:");
  }

  checking_create_new_entry_button() {
    this.create_template_button.click();
    cy.wait(2000);
    this.new_template_header.should("have.text", "Create New Template");
    cy.go("back");
  }

  creating_template() {
    this.create_template_button.click();
    cy.wait(2000);
    this.new_template_header.should("have.text", "New Template Creation");
    this.new_platform_creation.click();
    this.modal_input1.first().type("New_onboard_dummy_platform");
    this.modal_input1.last().type("Description");
    this.modal_add_button.last().click();
    cy.go("back");
    cy.go("forward");
    this.new_subject_area_creation.click();
    this.modal_input1.first().type("New_onboard_dummy_subject_area");
    this.modal_input1.last().type("Description");
    this.modal_add_button.last().click();
    cy.go("back");
    cy.go("forward");
    this.new_process_creation.click();
    this.modal_input1.first().type("New_onboard_dummy_process");
    this.modal_input1.last().type("Description");
    this.modal_add_button.last().click();
    cy.go("back");
    cy.go("forward");
    this.new_dataset_creation.click();
    this.modal_input1.first().type("New_onboard_dummy_dataset");
    this.dataset_modal_input2.last().type("Description");
    this.dataset_modal_input3.select("Delimited");
    this.dataset_modal_input4.type("|");
    this.dataset_modal_input5.select("Y");
    this.modal_add_button.last().click();
    cy.go("back");
    cy.go("forward");
    this.platform_dropdown.select("New_onboard_dummy_platform");
    this.subject_area_dropdown.select("New_onboard_dummy_subject_area");
    this.process_dropdown.select("New_onboard_dummy_process");
    this.dataset_dropdown.select("New_onboard_dummy_dataset");
    //this.text_area.type("Onboard_new_file");
    this.field_name_input.type('Field1')
    this.field_startDate_button.type('2022-09-01')
    this.field_add_button.click()
    this.field_name_input.type('Field2')
    this.field_startDate_button.type('2022-09-01')
    this.field_add_button.click()
    this.field_name_input.type('Field3')
    this.field_startDate_button.type('2022-09-01')
    this.field_add_button.click()
    this.template_section_create_template_button.click();
    cy.wait(2000);
    this.messages.should('have.text','Template created successfully.')
    cy.go("back");
  }

  selecting_template() {
    this.platform_dropdown.select("dummy1_plt");
    cy.wait(1000)
    this.subject_area_dropdown.select("dummy2_sub");
    cy.wait(1000)
    this.process_dropdown.select("dummy3_proce");
    cy.wait(1000)
    this.dataset_dropdown.select("dummy4_dataset");
    cy.wait(1000)
    this.template_version_dropdown.select('Desktop')
  }

  selecting_template_laptop() {
    this.platform_dropdown.select("dummy1_plt");
    cy.wait(1000)
    this.subject_area_dropdown.select("dummy2_sub");
    cy.wait(1000)
    this.process_dropdown.select("dummy3_proce");
    cy.wait(1000)
    this.dataset_dropdown.select("dummy4_dataset");
    cy.wait(1000)
    this.template_version_dropdown.select('Tablet')
  }


  deleting_dummy_entries_org_delim_templt_fld_ovrrd(config,version) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.org_delim_templt_fld_ovrrd where org_templt_ovrrd_fld_id in (
        select fl.org_templt_ovrrd_fld_id
        from cdm_core.org_allw_templt t
        inner join cdm_core.org_delim_templt_fld_ovrrd fl on fl.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = fl.pltfrm_cd 
        and t.dset_cd = fl.dset_cd and fl.tier2_3_hier_id = t.tier2_3_hier_id
        inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd and tm.tier2_3_hier_id = t.tier2_3_hier_id
        where fl.dset_cd='dummy4_dataset' and fl.pltfrm_cd='dummy1_plt' and tm.templt_ver_nm='`+version+`'
        )`,
    }).then((result) => {});
  }


  
  deleting_dummy_entries_org_allw_templt_ingest_mode(config,version) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.org_allw_templt_ingest_mode where org_allw_templt_ingest_mode_id in (
        select distinct i.org_allw_templt_ingest_mode_id
        from cdm_core.org_allw_templt t
        inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd and tm.tier2_3_hier_id = t.tier2_3_hier_id
        inner join cdm_core.org_allw_templt_ingest_mode i on i.dset_cd = t.dset_cd and i.tier2_3_hier_id = t.tier2_3_hier_id and i.org_id=t.org_id and i.pltfrm_cd = t.pltfrm_cd and i.templt_ver_nbr = t.templt_ver_nbr
        where t.dset_cd='dummy4_dataset' and t.pltfrm_cd='dummy1_plt' and tm.templt_ver_nm='`+version+`'
        )`,
    }).then((result) => {});
  }


  deleting_dummy_entries_org_allw_templt(config,version) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.org_allw_templt where org_templt_id in (
        select distinct t.org_templt_id
        from cdm_core.org_allw_templt t
        inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd and tm.tier2_3_hier_id = t.tier2_3_hier_id
        where t.dset_cd='dummy4_dataset' and t.pltfrm_cd='dummy1_plt' and tm.templt_ver_nm='`+version+`'
        )`,
    }).then((result) => {});
  }

  deleting_dummy_entries_tmplt_fields(config) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.delim_templt_fld_def where dset_cd='New_onboard_dummy_dataset' and pltfrm_cd='New_onboard_dummy_platform'`,
    }).then((result) => {});
  }

  deleting_dummy_entries_tmplt(config) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.templt where tier2_3_hier_id=(select tier2_3_hier_id from cdm_core.tier2_3_hier 
            where tier2_hier_nm='New_onboard_dummy_subject_area' and tier3_hier_nm='New_onboard_dummy_process')`,
    }).then((result) => {});
  }

  deleting_dummy_entries_dset_lkup(config) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.dset_lkup where dset_cd='New_onboard_dummy_dataset'`,
    }).then((result) => {});
  }

  deleting_dummy_entries_tier2_3_hier(config) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.tier2_3_hier where tier2_3_hier_id=(select tier2_3_hier_id from cdm_core.tier2_3_hier 
                    where tier2_hier_nm='New_onboard_dummy_subject_area' and tier3_hier_nm='New_onboard_dummy_process')`,
    }).then((result) => {});
  }

  deleting_dummy_entries_class_hier_lkup_tier2(config) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.class_hier_lkup where hier_cd='New_onboard_dummy_subject_area'`,
    }).then((result) => {});
  }

  deleting_dummy_entries_class_hier_lkup_tier3(config) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.class_hier_lkup where hier_cd='New_onboard_dummy_process'`,
    }).then((result) => {});
  }

  deleting_dummy_entries_pltfrm_lkup(config) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.pltfrm_lkup where pltfrm_lkup.pltfrm_cd='New_onboard_dummy_platform'`,
    }).then((result) => {});
  }

  deleting_dummy_entries_ingestion_lkup(config) {
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `delete from cdm_core.data_ingest_mode_lkup where data_ingest_mode_cd='New_onboard_dummy_ingestion_mode'`,
    }).then((result) => {});
  }

  section2_heading_check(){
    this.section2_heading.should('have.text','Choose Partner and related Attributes')
  }

  organisation_dropdown_check(){
    this.organisation_dropdown_header.should('have.text','Organization*:')
    this.organisation_dropdown.select('Dell')

  }

  ingestion_mode_dropdown_check(){
    this.ingestion_mode_header.should('have.text','Ingestion Mode*:')
    this.ingestion_mode_dropdown.select('UU')

  }

  add_ingestion_mode(){
    this.add_ingestion_mode_button.click()
    this.modal_input1.first().type("New_onboard_dummy_ingestion_mode");
    this.modal_input1.last().type("Description");
    this.use_case_type.select('OL')
    this.modal_add_button.last().click();
    cy.wait(2000)
    this.ingestion_mode_dropdown.select('New_onboard_dummy_ingestion_mode')
  }

  retention_before_archival(){
    this.retention_before_archival_header.should('have.text','Retention Before Archival(In Days):')
    this.retention_before_archival_input.should('have.attr','placeholder','For Example:300')
    this.retention_before_archival_input.type('30')
    this.retention_before_archival_input.should('have.value','30')
    this.retention_before_archival_input.clear()
    this.retention_before_archival_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
    this.retention_before_archival_input.should('have.value','')
    this.retention_before_archival_input.clear()
    this.retention_before_archival_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
    this.retention_before_archival_input.should('have.value','')
    this.retention_before_archival_input.clear()
    this.retention_before_archival_input.type("   ")
    this.retention_before_archival_input.should('have.value','')
    this.retention_before_archival_input.clear()
    this.retention_before_archival_input.type(" 3 0 ")
    this.retention_before_archival_input.should('have.value','30')

  }

  retention_before_purge(){
    this.retention_before_purge_header.should('have.text','Retention Before Purge(In Days):')
    this.retention_before_purge_input.should('have.attr','placeholder','For Example:300')
    this.retention_before_purge_input.type('30')
    this.retention_before_purge_input.should('have.value','30')
    this.retention_before_purge_input.clear()
    this.retention_before_purge_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
    this.retention_before_purge_input.should('have.value','')
    this.retention_before_purge_input.clear()
    this.retention_before_purge_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
    this.retention_before_purge_input.should('have.value','')
    this.retention_before_purge_input.clear()
    this.retention_before_purge_input.type("   ")
    this.retention_before_purge_input.should('have.value','')
    this.retention_before_purge_input.clear()
    this.retention_before_purge_input.type(" 3 0 ")
    this.retention_before_purge_input.should('have.value','30')
  }

  restatement_allowed_days(){
    this.restatement_allowed_days_header.should('have.text','Restatement Allowed(In Days):')
    this.restatement_allowed_days_input.should('have.attr','placeholder','For Example:300')
    this.restatement_allowed_days_input.type('30')
    this.restatement_allowed_days_input.should('have.value','30')
    this.restatement_allowed_days_input.clear()
    this.restatement_allowed_days_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
    this.restatement_allowed_days_input.should('have.value','')
    this.restatement_allowed_days_input.clear()
    this.restatement_allowed_days_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
    this.restatement_allowed_days_input.should('have.value','')
    this.restatement_allowed_days_input.clear()
    this.restatement_allowed_days_input.type("   ")
    this.restatement_allowed_days_input.should('have.value','')
    this.restatement_allowed_days_input.clear()
    this.restatement_allowed_days_input.type(" 3 0 ")
    this.restatement_allowed_days_input.should('have.value','30')
  }

  collab_indicator(){
    this.collab_header.should('have.text','Eligible for Collaboration Indicator(Y/N)*:')
    this.collab_dropdown.select('Y')
  }

  file_split_ratio(){
    this.file_split_header.should('have.text','File Split Denominator Ratio(Number)*:')
    this.file_split_input.should('have.attr','placeholder','For Example:4.00')
    this.file_split_input.type('30')
    this.file_split_input.should('have.value','30')
    this.file_split_input.clear()
    this.file_split_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
    this.file_split_input.should('have.value','')
    this.file_split_input.clear()
    this.file_split_input.type("   ")
    this.file_split_input.should('have.value','')
    this.file_split_input.clear()
    this.file_split_input.type(" 3 0 ")
    this.file_split_input.should('have.value','30')
    this.file_split_input.clear()
    this.file_split_input.type(" 30.001 ")
    this.file_split_input.should('have.value','30.001')
     this.file_split_input.clear()
    this.file_split_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
    this.file_split_input.should('have.value','')
    this.file_split_input.clear()
    this.file_split_input.type(" 30.001 ")
    this.file_split_input.should('have.value','30.001')
  }


  org_tmplt_priority(){
    this.org_tmplt_header.should('have.text','Organization Template Priority(Number)*:')
    this.org_tmplt_input.should('have.attr','placeholder','1-5, 5 is highest')
    this.org_tmplt_input.clear()
    this.org_tmplt_input.type('1')
    this.org_tmplt_input.should('have.value','1')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type('2')
    this.org_tmplt_input.should('have.value','2')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type('3')
    this.org_tmplt_input.should('have.value','3')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type('4')
    this.org_tmplt_input.should('have.value','4')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type('5')
    this.org_tmplt_input.should('have.value','5')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz')
    this.org_tmplt_input.should('have.value','')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type("~`!@#$%^&*()-_+={}[]|\/:;\"'<>,.?")
    this.org_tmplt_input.should('have.value','')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type("   ")
    this.org_tmplt_input.should('have.value','')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type(" 3 0 ")
    this.org_tmplt_input.should('have.value','3')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type('67890')
    this.org_tmplt_input.should('have.value','')
    this.org_tmplt_input.type('{backspace}')
    this.org_tmplt_input.type(" 3 0 ")
    this.org_tmplt_input.should('have.value','3')
  }

  override_field_name(type){
    cy.wait(2000)
    this.going_to_newonboard_page()
    cy.wait(2000)
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    // this.override_field_button.should('be.disabled')
    //  this.input_select_1.select('Field1')
    //  this.override_field_button.should('be.disabled')
    //  this.input_override_name_1.type('Vignesh1')
    //  this.override_field_button.click()
    //  this.input_select_2.select('Field2')
    //  this.override_field_button.should('be.disabled')
    //  this.input_override_name_2.type('Vignesh2')
    //  this.override_field_button.click()
    //  this.input_select_3.select('Field3')
    //  this.override_field_button.should('be.disabled')
    //  this.input_override_name_3.type('Vignesh3')
    //  this.onboard_button.click()

    // this.platform_dropdown.select("dummy1_plt");
    // this.subject_area_dropdown.select("dummy2_sub");
    // this.process_dropdown.select("dummy3_proce");
    // this.dataset_dropdown.select("dummy4_dataset");
    // this.template_version_dropdown.select('Desktop')
    if(type=='version'){
      this.selecting_template_laptop()
    }
    else{
      this.selecting_template()
    }
  
    this.organisation_dropdown.select('Arrow Electronics');
    this.ingestion_mode_dropdown.select('UU');
    this.retention_before_archival_input.type('30')
    this.collab_dropdown.select('Y')
    this.file_split_input.type('30')
    this.org_tmplt_input.type('4')
      this.input_select_1.select('Field1')
     this.override_field_button.should('be.disabled')
     this.input_override_name_1.type('Vignesh1')
     if(type != 'version'){
     this.override_field_button.click()
     this.input_select_2.select('Field2')
     this.override_field_button.should('be.disabled')
     this.input_override_name_2.type('Vignesh2')
     this.override_field_button.click()
     this.input_select_3.select('Field3')
     this.override_field_button.should('be.disabled')
     this.input_override_name_3.type('Vignesh3')
     }
    this.onboard_button.click()
    cy.wait(3000)
    this.modal_header.should('have.text','Dataset/File Onboard')
    this.modal_body.should('have.text','Dataset/File onboarded successfully.')
    this.modal_button.click()
    cy.wait(2000)
    this.new_onboard_button.contains("Onboard a new File");
    this.new_onboard_button.click();
    
  }


  duplicate_dataset_onboard(type){
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    cy.wait(2000)
    this.going_to_newonboard_page()
    cy.wait(2000)
    if(type=='version'){
      this.selecting_template_laptop()
    }
    else{
      this.selecting_template()
    }
    
    this.organisation_dropdown.select('Arrow Electronics');
    this.ingestion_mode_dropdown.select('FTP');
    this.retention_before_archival_input.type('30')
    this.collab_dropdown.select('Y')
    this.file_split_input.type('30')
    this.org_tmplt_input.type('4')
      this.input_select_1.select('Field1')
     this.override_field_button.should('be.disabled')
     this.input_override_name_1.type('Vignesh1')
     if(type != 'version'){
      this.override_field_button.click()
      this.input_select_2.select('Field2')
      this.override_field_button.should('be.disabled')
      this.input_override_name_2.type('Vignesh2')
      this.override_field_button.click()
      this.input_select_3.select('Field3')
      this.override_field_button.should('be.disabled')
      this.input_override_name_3.type('Vignesh3')
     }
  
    this.onboard_button.click()
    cy.wait(3000)
    this.modal_header.should('have.text','Dataset/File Onboard')
    this.modal_body.should('have.text',' Uniqueness violation. Combination of Template, Partner & Related Attributes and Override Template Field/s (if selected) already exists.')
    this.modal_button.click()
  }


  greater_integer_value(){
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    cy.wait(2000)
    this.going_to_newonboard_page()
    cy.wait(2000)
    this.selecting_template()
    this.organisation_dropdown.select('Arrow Electronics');
    this.ingestion_mode_dropdown.select('FTP');
    this.retention_before_archival_input.type('123456789012321421')
    this.collab_dropdown.select('Y')
    this.file_split_input.type('30')
    this.org_tmplt_input.type('4')
      this.input_select_1.select('Field1')
     this.override_field_button.should('be.disabled')
     this.input_override_name_1.type('Vignesh1')
     this.override_field_button.click()
     this.input_select_2.select('Field2')
     this.override_field_button.should('be.disabled')
     this.input_override_name_2.type('Vignesh2')
     this.override_field_button.click()
     this.input_select_3.select('Field3')
     this.override_field_button.should('be.disabled')
     this.input_override_name_3.type('Vignesh3')
    this.onboard_button.click()
    cy.wait(3000)
    this.modal_header.should('have.text','Dataset/File Onboard')
    this.modal_body.should('have.text','Value/s provided in one or all retention fields can not be accepted. Value should be in the range: 0 to 2147483647')
    this.modal_button.click()
    cy.wait(2000)
    this.going_to_newonboard_page()
    
  }

  greater_integer_value_restatement(){
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    cy.wait(2000)
    this.going_to_newonboard_page()
    cy.wait(2000)
    this.selecting_template()
    this.organisation_dropdown.select('Arrow Electronics');
    this.ingestion_mode_dropdown.select('FTP');
    this.restatement_allowed_days_input.type('123456789012321421')
    this.collab_dropdown.select('Y')
    this.file_split_input.type('30')
    this.org_tmplt_input.type('4')
      this.input_select_1.select('Field1')
     this.override_field_button.should('be.disabled')
     this.input_override_name_1.type('Vignesh1')
     this.override_field_button.click()
     this.input_select_2.select('Field2')
     this.override_field_button.should('be.disabled')
     this.input_override_name_2.type('Vignesh2')
     this.override_field_button.click()
     this.input_select_3.select('Field3')
     this.override_field_button.should('be.disabled')
     this.input_override_name_3.type('Vignesh3')
    this.onboard_button.click()
    cy.wait(3000)
    this.modal_header.should('have.text','Dataset/File Onboard')
    this.modal_body.should('have.text','Value/s provided in one or all retention fields can not be accepted. Value should be in the range: 0 to 2147483647')
    this.modal_button.click()
    cy.wait(2000)
    this.going_to_newonboard_page()
    
  }

  greater_integer_value_purge(){
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    cy.wait(2000)
    this.going_to_newonboard_page()
    cy.wait(2000)
    this.selecting_template()
    this.organisation_dropdown.select('Arrow Electronics');
    this.ingestion_mode_dropdown.select('FTP');
    this.retention_before_purge_input.type('123456789012321421')
    this.collab_dropdown.select('Y')
    this.file_split_input.type('30')
    this.org_tmplt_input.type('4')
      this.input_select_1.select('Field1')
     this.override_field_button.should('be.disabled')
     this.input_override_name_1.type('Vignesh1')
     this.override_field_button.click()
     this.input_select_2.select('Field2')
     this.override_field_button.should('be.disabled')
     this.input_override_name_2.type('Vignesh2')
     this.override_field_button.click()
     this.input_select_3.select('Field3')
     this.override_field_button.should('be.disabled')
     this.input_override_name_3.type('Vignesh3')
    this.onboard_button.click()
    cy.wait(3000)
    this.modal_header.should('have.text','Dataset/File Onboard')
    this.modal_body.should('have.text','Value/s provided in one or all retention fields can not be accepted. Value should be in the range: 0 to 2147483647')
    this.modal_button.click()
    cy.wait(2000)
    this.going_to_newonboard_page()
    
  }

  greater_numeric_value(){
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    cy.wait(2000)
    this.going_to_newonboard_page()
    cy.wait(2000)
    this.selecting_template()
    this.organisation_dropdown.select('Arrow Electronics');
    this.ingestion_mode_dropdown.select('FTP');
    //this.retention_before_purge_input.type('123456789012321421')
    this.collab_dropdown.select('Y')
    this.file_split_input.type('9999999.9999')
    this.org_tmplt_input.type('4')
      this.input_select_1.select('Field1')
     this.override_field_button.should('be.disabled')
     this.input_override_name_1.type('Vignesh1')
     this.override_field_button.click()
     this.input_select_2.select('Field2')
     this.override_field_button.should('be.disabled')
     this.input_override_name_2.type('Vignesh2')
     this.override_field_button.click()
     this.input_select_3.select('Field3')
     this.override_field_button.should('be.disabled')
     this.input_override_name_3.type('Vignesh3')
    this.onboard_button.click()
    cy.wait(3000)
    this.modal_header.should('have.text','Dataset/File Onboard')
    this.modal_body.should('have.text','Value provided in the File Split Denominator Ratio field can not be accepted. Value should be in the range: 0 to 9999999.999')
    this.modal_button.click()
    cy.wait(2000)
    this.going_to_newonboard_page()
    
  }

  greater_override_fields(){
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    cy.wait(2000)
    this.going_to_newonboard_page()
    cy.wait(2000)
    this.selecting_template()
    this.organisation_dropdown.select('Arrow Electronics');
    this.ingestion_mode_dropdown.select('FTP');
    //this.retention_before_purge_input.type('123456789012321421')
    this.collab_dropdown.select('Y')
    this.file_split_input.type('9999999.999')
    this.org_tmplt_input.type('4')
      this.input_select_1.select('Field1')
     this.override_field_button.should('be.disabled')
     this.input_override_name_1.type('    abcdefghiljklmnopq    rstuvwxyzABCDEFGHIJKLMNOPVIGNESHSEkar    ')
     this.input_override_name_1.should('have.value','abcdefghiljklmnopqrstuvwxyzABCDEFGHIJKLMNOPVIGNESH')
     this.override_field_button.click()
     this.input_select_2.select('Field2')
     this.override_field_button.should('be.disabled')
     this.input_override_name_2.type('    abcdefghiljklmnopq    rstuvwxyzABCDEFGHIJKLMNOPVIGNESHSEkar    ')
     this.input_override_name_2.should('have.value','abcdefghiljklmnopqrstuvwxyzABCDEFGHIJKLMNOPVIGNESH')
     this.override_field_button.click()
     this.input_select_3.select('Field3')
     this.override_field_button.should('be.disabled')
     this.input_override_name_3.type('    abcdefghiljklmnopq    rstuvwxyzABCDEFGHIJKLMNOPVIGNESHSEkar    ')
     this.input_override_name_3.should('have.value','abcdefghiljklmnopqrstuvwxyzABCDEFGHIJKLMNOPVIGNESH')
    this.onboard_button.click()
    cy.wait(3000)
    this.modal_header.should('have.text','Dataset/File Onboard')
    this.modal_body.should('have.text','Dataset/File onboarded successfully.')
    this.modal_button.click()
    // cy.wait(2000)
    // cy.reload()
    
  }


  platform_dropdown_selection(config){

    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `Select distinct t.pltfrm_cd from cdm_core.templt t`,
      }).then((result) => {
        for(let i=0;i<result.rows.length;i++){
            this.platform_dropdown.select(result.rows[i].pltfrm_cd)
        }

        this.platform_dropdown.find('option').should('have.length',result.rows.length+1)
        this.platform_dropdown.select('Dell_plt')
      })

}

subject_area_dropdown_selection(config){

  cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `Select distinct t1.tier2_hier_nm from cdm_core.templt t
      inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
      where  t.pltfrm_cd='Dell_plt'`,
    }).then((result) => {
      for(let i=0;i<result.rows.length;i++){
          this.subject_area_dropdown.select(result.rows[i].tier2_hier_nm)
      }

      this.subject_area_dropdown.find('option').should('have.length',result.rows.length+1)
      this.subject_area_dropdown.select('Dell_sub')
    })

}

process_area_dropdown_selection(config){

  cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `Select distinct t1.tier3_hier_nm from cdm_core.templt t
      inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
      where  t.pltfrm_cd='Dell_plt'`,
    }).then((result) => {
      for(let i=0;i<result.rows.length;i++){
          this.process_dropdown.select(result.rows[i].tier3_hier_nm)
      }

      this.process_dropdown.find('option').should('have.length',result.rows.length+1)
      this.process_dropdown.select('Dell_prc')
    })

}


dataset_dropdown_selection(config){

  cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `Select distinct t.dset_cd from cdm_core.templt t
      inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
      where  t.pltfrm_cd='Dell_plt' and t1.tier3_hier_nm='Dell_prc' and t1.tier2_hier_nm = 'Dell_sub'`,
    }).then((result) => {
      for(let i=0;i<result.rows.length;i++){
          this.dataset_dropdown.select(result.rows[i].dset_cd)
      }

     // this.dataset_dropdown.find('option').should('have.length',result.rows.length+1)
      this.dataset_dropdown.select('Dell_dataset')
    })

}


version_dropdown_selection(config,version){

  cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `   Select distinct t.templt_ver_nm from cdm_core.templt t inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id 
      where t.pltfrm_cd='Dell_plt' and t1.tier3_hier_nm='Dell_prc' and t1.tier2_hier_nm = 'Dell_sub' and t.dset_cd='Dell_dataset' `,
    }).then((result) => {
      for(let i=0;i<result.rows.length;i++){
          this.template_version_dropdown.select(result.rows[i].templt_ver_nm)
      }

      this.template_version_dropdown.find('option').should('have.length',result.rows.length+1)
     
    })

    this.template_version_dropdown.select(version)

}


version_dropdown_validation(config,version){
  this.platform_dropdown_selection(config)
  this.subject_area_dropdown_selection(config)
  this.process_area_dropdown_selection(config)
  this.dataset_dropdown_selection(config)
  this.version_dropdown_selection(config,version)
}

version_partner_field(){
  this.organisation_dropdown.select('Dell');
    this.ingestion_mode_dropdown.select('FTP');
    this.collab_dropdown.select('Y')
    this.file_split_input.type('2000')
    this.org_tmplt_input.type('4')
      this.input_select_1.select('Field1')
     this.input_override_name_1.type('Override_Field1')
}


}

export default new newonboard();
