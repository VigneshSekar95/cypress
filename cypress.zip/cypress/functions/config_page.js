// ************************ Configuration page - File Metadata Tables Check***********************************
// This file contains all the function definitions and css selectors used for testing the Metadata tables
// Created by Vignesh Sekar
// 
// Css Selectors - CSS selectors is used for locating the elements in UI screen
//
// Below are the Scenarios Covered for testing these tables:
// 1.Adding a Record and checking the record is available in the grid
// 2.Search for a Record in the Grid
// 3.Edit a  Record and Check the edited data is available in Grid
// 4.Pagination
// 5.Grid Data Validation
// 6.Is_active button functionality
// 7.Uniqueness Violation Check
// 8.Cheking the Maxallowed character for the input fields
// 9.Checking in the backend whether the new entries are created.




class configfunc {
    get configuration_button() {
      return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/a[1]')
    }

    get file_metadata_config_button(){
        return cy.get('.main-content>main>div>div:nth-of-type(2)>div:nth-of-type(1)>div>div:nth-of-type(3)>button')
    }

    get file_metadata(){
        return cy.get('.accordion>div:nth-of-type(1)>h2>button')
    }

    get access_tables(){
        return cy.get('.accordion>div:nth-of-type(2)>h2>button')
    }

    get external_call(){
      return cy.get('.accordion>div:nth-of-type(3)>h2>button')
  }

    get Action(){
        return cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type(1)')
    }

    get Application(){
      return cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type(2)')
    }

    get Affliation(){
      return cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type(3)')
    }

    get Resource(){
      return cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type(4)')
    }

    get Principal(){
      return cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type(5)')
    }

    get add_record(){
        return cy.get('.me-2.btn.btn-primary.btn-sm')
    }

    get modal_title(){
        return cy.get('.modal-title')
    }

    get add_button(){
        return cy.get('.modal-footer>button:nth-of-type(2)')
    }

    get cancel_button(){
        return cy.get('.modal-footer>button:nth-of-type(1)')
    }

    get cancel_icon(){
        return cy.get('.btn-close')
    }

    get search_box(){
        return cy.get('.input-group>input')
    }

    get first_row_first_column(){
        return cy.get('.ag-row-even>div:nth-of-type(1)')
    }

    get first_row_second_column(){
        return cy.get('.ag-row-even>div:nth-of-type(2)')
    }

    get first_row_third_column(){
      return cy.get('.ag-row-even>div:nth-of-type(3)')
  }

  get first_row_fourth_column(){
    return cy.get('.ag-row-even>div:nth-of-type(4)')
}

get first_row_fifth_column(){
  return cy.get('.ag-row-even>div:nth-of-type(5)')
}

    get active_button(){
        return cy.get('.ag-row-even:nth-of-type(1)>div:nth-of-type(3)>span>div>input')
    }

    get qual_active_button(){
      return cy.get('.ag-row-even:nth-of-type(1)>div:nth-of-type(4)>span>div>input')
    }

    get external_active_button(){
      return cy.get('.ag-row-even:nth-of-type(1)>div:nth-of-type(5)>span>div>input')
    }

    get dataset_active_button(){
      return cy.get('.ag-row-even:nth-of-type(1)>div:nth-of-type(6)>span>div>input')
    }

    get edit_button(){
        return cy.get('.ag-row-even:nth-of-type(1)>div:nth-of-type(4)')
    } 

    get dataset_edit_button(){
      return cy.get('.ag-row-even:nth-of-type(1)>div:nth-of-type(7)')
  } 

  get external_appl_edit_button(){
    return cy.get('.ag-row-even:nth-of-type(1)>div:nth-of-type(6)')
} 

get qual_sys_edit_button(){
  return cy.get('.ag-row-even:nth-of-type(1)>div:nth-of-type(5)')
} 

    get pagecount_button(){
        return cy.get('.ag-paging-panel>span>span:nth-of-type(5)')
    }

    get page_number(){
        return cy.get('.ag-paging-page-summary-panel>span>span:nth-of-type(2)')
      }
  
      get total_page(){
        return cy.get('.ag-paging-page-summary-panel>span>span:nth-of-type(4)')
      }

      get lastpage(){
        return cy.get('.ag-paging-page-summary-panel>div:nth-of-type(4)')
    }

    get firstpage(){
        return cy.get('.ag-paging-page-summary-panel>div:nth-of-type(1)')
    }

    get nextpage(){
        return cy.get('.ag-paging-page-summary-panel>div:nth-of-type(3)')
    }

    get prevpage(){
        return cy.get('.ag-paging-page-summary-panel>div:nth-of-type(2)')
    }

    get ag_grid(){
        return cy.get('.ag-root-wrapper')
    }

    get firstrow_on_page(){
        return cy.get('.ag-paging-panel>span>span:nth-of-type(1)')
      }
  
      get lastrow_on_page(){
        return cy.get('.ag-paging-panel>span>span:nth-of-type(3)')
      }

      get page_size(){
        return cy.get('#page-size')
      }

      get error_message(){
        return cy.get('.invalid-feedback')
    }

      

  
    /*  ***************************Methods********************************/
  
    config_page(title,button){
      cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });
        this.configuration_button.should('have.text',title)
        this.configuration_button.click()
        this.file_metadata_config_button.should('have.text',button)
        this.file_metadata_config_button.click()
        
    }

    filemetadata(){
      cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });
        this.file_metadata.click()

    }

    access_entitlement(){
      cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });
        this.file_metadata.click()
        this.access_tables.click()

    }

    externalcall(){
      cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });
        this.external_call.click()

    }

    going_to_table(list,table){
      if(table=='Access'){
          cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
      }
      else if(table=='External'){
          cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
      }
      else{
          cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
      }

    }


    add_new_record(list,code,desc,modal_title,modal_header1,modal_header2,table){
      cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });
        if(table=='Access'){
            cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
        }
        else if(table=='External'){
            cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
        }
        else{
            cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
        }
        
        this.add_record.click()
        cy.wait(1000)
        this.add_button.should('be.disabled')
        cy.wait(1000)
        this.cancel_button.click()
        cy.wait(1000)
        this.add_record.click()
        cy.wait(1000)
        this.cancel_icon.click()
        cy.wait(1000)
        this.add_record.click()
        cy.wait(1000)
        this.modal_title.should('have.text',modal_title)
        cy.wait(2000)
        cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
        cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
        cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
        cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
        this.add_button.click()
        cy.wait(2000)
        this.search_box.clear()
        this.search_box.type(code.substring(0,47))
        cy.wait(1000)
        this.first_row_first_column.contains(code.substring(0,47))
        this.first_row_second_column.contains(desc.substring(0,251))
        this.search_box.clear()
    }


    external_new_record(list,code,desc,type,name,modal_title,modal_header1,modal_header2,modal_header3,modal_header4,table){
      if(table=='Access'){
          cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
      }
      else if(table=='External'){
          cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
      }
      else{
          cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
      }
      
      this.add_record.click()
      cy.wait(1000)
      this.add_button.should('be.disabled')
      cy.wait(1000)
      this.cancel_button.click()
      cy.wait(1000)
      this.add_record.click()
      cy.wait(1000)
      this.cancel_icon.click()
      cy.wait(1000)
      this.add_record.click()
      cy.wait(1000)
      this.modal_title.should('have.text',modal_title)
      cy.wait(1000)
      cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
      cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
      cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
      cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(2)').contains(modal_header3)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>select:nth-of-type(1)').select(type)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(3)').contains(modal_header4)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>select:nth-of-type(2)').select(name)
      this.add_button.click()
      cy.wait(1000)
      this.search_box.clear()
      this.search_box.type(code.substring(0,47))
      this.first_row_first_column.contains(code.substring(0,47))
      this.first_row_second_column.contains(desc.substring(0,251))
      this.first_row_third_column.contains(type)
      this.first_row_fourth_column.contains(name)
      this.search_box.clear()
  }


  dataset_new_record(list,code,desc,type,name,header,modal_title,modal_header1,modal_header2,modal_header3,modal_header4,modal_header5,table){
    if(table=='Access'){
        cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
    }
    else if(table=='External'){
        cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
    }
    else{
        cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
    }
    
    this.add_record.click()
    cy.wait(1000)
    this.add_button.should('be.disabled')
    cy.wait(1000)
    this.cancel_button.click()
    cy.wait(1000)
    this.add_record.click()
    cy.wait(1000)
    this.cancel_icon.click()
    cy.wait(1000)
    this.add_record.click()
    cy.wait(1000)
    this.modal_title.should('have.text',modal_title)
    cy.wait(1000)
    cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
    cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
    cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
    cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
    cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(2)').contains(modal_header3)
    cy.get('.modal-body>div:nth-of-type(2)>select:nth-of-type(1)').select(type)
    cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(3)').contains(modal_header4)
    cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(2)').type(name)
    cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(4)').contains(modal_header5)
    cy.get('.modal-body>div:nth-of-type(2)>select:nth-of-type(2)').select(header)
    this.add_button.click()
    cy.wait(1000)
    this.search_box.clear()
    this.search_box.type(code.substring(0,47))
    this.first_row_first_column.contains(code.substring(0,47))
    this.first_row_second_column.contains(desc.substring(0,251))
    this.first_row_third_column.contains(type)
    this.first_row_fourth_column.contains(name)
    this.first_row_fifth_column.contains(header)
    this.search_box.clear()
}


  qualification_new_record(list,code,desc,type,modal_title,modal_header1,modal_header2,modal_header3,table){
    if(table=='Access'){
        cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
    }
    else if(table=='External'){
        cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
    }
    else{
        cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
    }
    
    this.add_record.click()
    cy.wait(1000)
    this.add_button.should('be.disabled')
    cy.wait(1000)
    this.cancel_button.click()
    cy.wait(1000)
    this.add_record.click()
    cy.wait(1000)
    this.cancel_icon.click()
    cy.wait(1000)
    this.add_record.click()
    cy.wait(1000)
    this.modal_title.should('have.text',modal_title)
    cy.wait(1000)
    cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
    cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
    cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
    cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
    cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(2)').contains(modal_header3)
    cy.get('.modal-body>.mb-3:nth-of-type(2)>select:nth-of-type(1)').select(type)
    this.add_button.click()
    cy.wait(1000)
    this.search_box.clear()
    this.search_box.type(code.substring(0,47))
    this.first_row_first_column.contains(code.substring(0,47))
    this.first_row_second_column.contains(desc.substring(0,251))
    this.first_row_third_column.contains(type)
    this.search_box.clear()
}


data_ingestion_new_record(list,code,desc,type,modal_title,modal_header1,modal_header2,modal_header3,table){
  if(table=='Access'){
      cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
  }
  else if(table=='External'){
      cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
  }
  else{
      cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
  }
  
  this.add_record.click()
  cy.wait(1000)
  this.add_button.should('be.disabled')
  cy.wait(1000)
  this.cancel_button.click()
  cy.wait(1000)
  this.add_record.click()
  cy.wait(1000)
  this.cancel_icon.click()
  cy.wait(1000)
  this.add_record.click()
  cy.wait(1000)
  this.modal_title.should('have.text',modal_title)
  cy.wait(1000)
  cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
  cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
  cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
  cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
  cy.get('.modal-body>.mb-3:nth-of-type(3)>label').contains(modal_header3)
  cy.get('.modal-body>.mb-3:nth-of-type(3)>select').select(type)
  this.add_button.click()
  cy.wait(1000)
  this.search_box.clear()
  this.search_box.type(code.substring(0,47))
  this.first_row_first_column.contains(code.substring(0,47))
  this.first_row_second_column.contains(desc.substring(0,251))
  this.first_row_third_column.contains(type)
  this.search_box.clear()
}

    dataset_add_record(){

    }


    error_check(list,code,desc){
        cy.on("uncaught:exception", (err, runnable) => {
            return false;
          });
        this.add_record.click()
        cy.wait(1000)
        cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
        cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
     
        this.add_button.click()
        this.error_message.should('have.text','Uniqueness violation. Please try with a different value')
        this.cancel_button.click()
        
       
    }

    external_error_check(list,code,desc,type,name){
      cy.on("uncaught:exception", (err, runnable) => {
          return false;
        });
      this.add_record.click()
      cy.wait(1000)
      cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
      cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
      cy.get('.modal-body>.mb-3:nth-of-type(2)>select:nth-of-type(1)').select(type)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>select:nth-of-type(2)').select(name)
      this.add_button.click()
      this.error_message.should('have.text','Uniqueness violation. Please try with a different value')
      this.cancel_button.click()
      
     
  }


  qual_error_check(list,code,desc,type,name){
    cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });
    this.add_record.click()
    cy.wait(1000)
    cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
    cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
    cy.get('.modal-body>.mb-3:nth-of-type(2)>select:nth-of-type(1)').select(type)
    this.add_button.click()
    this.error_message.should('have.text','Uniqueness violation. Please try with a different value')
    this.cancel_button.click()
    
   
}

data_ingestion_error_check(list,code,desc,type,name){
  cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
  this.add_record.click()
  cy.wait(1000)
  cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
  cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
  cy.get('.modal-body>.mb-3:nth-of-type(3)>select').select(type)
  this.add_button.click()
  this.error_message.should('have.text','Uniqueness violation. Please try with a different value')
  this.cancel_button.click()
  
 
}

dataset_error_check(list,code,desc,type,name,header){
  cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
  this.add_record.click()
  cy.wait(1000)
 
    cy.get('.modal-body>.mb-3:nth-of-type(1)>input:nth-of-type(1)').type('   '+code+'   ')
   
    cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
    
    cy.get('.modal-body>div:nth-of-type(2)>select:nth-of-type(1)').select(type)

    cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(2)').type(name)
   
    cy.get('.modal-body>div:nth-of-type(2)>select:nth-of-type(2)').select(header)
  this.add_button.click()
  this.error_message.should('have.text','Uniqueness violation. Please try with a different value')
  this.cancel_button.click()
  
 
}




    search(code,desc){
      cy.wait(1000)
        this.search_box.clear()
        this.search_box.type(code)
        this.first_row_first_column.contains(code)
        this.first_row_second_column.contains(desc)
        this.search_box.clear()
    }

    edit(list,code,desc,modal_title,modal_header1,modal_header2,table){
        if(table=='Access'){
            cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
        }
        else if(table=='External'){
            cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
        }
        else{
            cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
        }
        this.search_box.clear()
        this.search_box.type(code)
        this.edit_button.click()
        cy.wait(1000)
        this.cancel_button.click()
        cy.wait(1000)
        this.edit_button.click()
        cy.wait(1000)
        this.cancel_icon.click()
        cy.wait(1000)
        this.edit_button.click()
        cy.wait(1000)
        this.modal_title.should('have.text',modal_title)
        cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
        cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
        cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').clear()
        cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type(desc)
        this.add_button.click()
    }


    external_edit_record(list,code,desc,type,name,modal_title,modal_header1,modal_header2,modal_header3,modal_header4,table){
      if(table=='Access'){
          cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
      }
      else if(table=='External'){
          cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
      }
      else{
          cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
      }
      
      this.search_box.clear()
      this.search_box.type(code)
      cy.wait(1000)
      this.external_appl_edit_button.click()
      cy.wait(1000)
      this.cancel_button.click()
      cy.wait(1000)
      this.external_appl_edit_button.click()
      cy.wait(1000)
      this.cancel_icon.click()
      cy.wait(1000)
      this.external_appl_edit_button.click()
      cy.wait(1000)
      this.modal_title.should('have.text',modal_title)
      cy.wait(1000)
      cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').clear()
      cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
      cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(2)').contains(modal_header3)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>select:nth-of-type(1)').select(type)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(3)').contains(modal_header4)
      cy.get('.modal-body>.mb-3:nth-of-type(2)>select:nth-of-type(2)').select(name)
      this.add_button.click()
      cy.wait(1000)
      this.search_box.clear()
      this.search_box.type(code.substring(0,47))
      this.first_row_first_column.contains(code.substring(0,47))
      this.first_row_second_column.contains(desc.substring(0,251))
      this.first_row_third_column.contains(type)
      this.first_row_fourth_column.contains(name)
      this.search_box.clear()
  }


  dataset_edit_record(list,code,desc,type,name,header,modal_title,modal_header1,modal_header2,modal_header3,modal_header4,modal_header5,table){
    if(table=='Access'){
        cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
    }
    else if(table=='External'){
        cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
    }
    else{
        cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
    }
    
    this.search_box.clear()
    this.search_box.type(code)
    cy.wait(1000)
    this.dataset_edit_button.click()
    cy.wait(1000)
    this.cancel_button.click()
    cy.wait(1000)
    this.dataset_edit_button.click()
    cy.wait(1000)
    this.cancel_icon.click()
    cy.wait(1000)
    this.dataset_edit_button.click()
    cy.wait(1000)
    this.modal_title.should('have.text',modal_title)
    cy.wait(1000)
    cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
    cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
    cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(1)').clear()
    cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
    cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(2)').contains(modal_header3)
    cy.get('.modal-body>div:nth-of-type(2)>select:nth-of-type(1)').select(type)
    cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(3)').contains(modal_header4)
    cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(2)').clear()
    cy.get('.modal-body>div:nth-of-type(2)>input:nth-of-type(2)').type(name)
    cy.get('.modal-body>div:nth-of-type(2)>label:nth-of-type(4)').contains(modal_header5)
    cy.get('.modal-body>div:nth-of-type(2)>select:nth-of-type(2)').select(header)
    this.add_button.click()
    cy.wait(1000)
    this.search_box.clear()
    cy.wait(1000)
    this.search_box.type(code.substring(0,47))
    this.first_row_first_column.contains(code.substring(0,47))
    this.first_row_second_column.contains(desc.substring(0,251))
    this.first_row_third_column.contains(type)
    this.first_row_fourth_column.contains(name)
    this.first_row_fifth_column.contains(header)
    this.search_box.clear()
}


  qualfication_edit_record(list,code,desc,type,modal_title,modal_header1,modal_header2,modal_header3,table){
    if(table=='Access'){
        cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
    }
    else if(table=='External'){
        cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
    }
    else{
        cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
    }
    cy.wait(1000)
    this.search_box.clear()
    this.search_box.type(code)
    cy.wait(1000)
    this.qual_sys_edit_button.click()
    cy.wait(1000)
    this.cancel_button.click()
    cy.wait(1000)
    this.qual_sys_edit_button.click()
    cy.wait(1000)
    this.cancel_icon.click()
    cy.wait(1000)
    this.qual_sys_edit_button.click()
    cy.wait(1000)
    this.modal_title.should('have.text',modal_title)
    cy.wait(1000)
    cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
    cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
    cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').clear()
    cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
    cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(2)').contains(modal_header3)
    cy.get('.modal-body>.mb-3:nth-of-type(2)>select:nth-of-type(1)').select(type)
    this.add_button.click()
    cy.wait(1000)
    this.search_box.clear()
 this.search_box.type(code.substring(0,47))
    this.first_row_first_column.contains(code.substring(0,47))
    this.first_row_second_column.contains(desc.substring(0,251))
    this.first_row_third_column.contains(type)
     //  this.add_button.click()
    cy.wait(1000)
    this.search_box.clear()
}

data_ingestion_edit_record(list,code,desc,type,modal_title,modal_header1,modal_header2,modal_header3,table){
  if(table=='Access'){
      cy.get('.accordion>div:nth-of-type(2)>div>div>div>button:nth-of-type('+list+')').click()
  }
  else if(table=='External'){
      cy.get('.accordion>div:nth-of-type(3)>div>div>div>button:nth-of-type('+list+')').click()
  }
  else{
      cy.get('.accordion>div:nth-of-type(1)>div>div>div>button:nth-of-type('+list+')').click()
  }
  cy.wait(1000)
  this.search_box.clear()
  this.search_box.type(code)
  cy.wait(1000)
  this.qual_sys_edit_button.click()
  cy.wait(1000)
  this.cancel_button.click()
  cy.wait(1000)
  this.qual_sys_edit_button.click()
  cy.wait(1000)
  this.cancel_icon.click()
  cy.wait(1000)
  this.qual_sys_edit_button.click()
  cy.wait(1000)
  this.modal_title.should('have.text',modal_title)
  cy.wait(1000)
  cy.get('.modal-body>.mb-3:nth-of-type(1)>label:nth-of-type(1)').contains(modal_header1)
  cy.get('.modal-body>.mb-3:nth-of-type(2)>label:nth-of-type(1)').contains(modal_header2)
  cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').clear()
  cy.get('.modal-body>.mb-3:nth-of-type(2)>input:nth-of-type(1)').type('   '+desc+'   ')
  cy.get('.modal-body>.mb-3:nth-of-type(3)>label').contains(modal_header3)
  cy.get('.modal-body>.mb-3:nth-of-type(3)>select').select(type)
  this.add_button.click()
  cy.wait(1000)
  this.search_box.clear()
this.search_box.type(code.substring(0,47))
  this.first_row_first_column.contains(code.substring(0,47))
  this.first_row_second_column.contains(desc.substring(0,251))
  this.first_row_third_column.contains(type)
   //  this.add_button.click()
  cy.wait(1000)
  this.search_box.clear()
}


    action_pagination(){
        cy.wait(3000)
        this.pagecount_button.last().then(($el) => {
            const overall_count = $el.text()
  
            cy.log(overall_count)
  
            if(overall_count<=5){
                this.page_number.contains('1')
                this.total_page.contains('1')
               // this.prevpage.should('be.disabled')
                //this.firstpage.should('be.disabled')
                //this.nextpage.should('be.disabled')
                //this.lastpage.should('be.disabled')
  
                this.ag_grid.getAgGridData().then((actualTableData)=>{
              
                    this.firstrow_on_page.last().contains('1')
                    this.lastrow_on_page.last().contains(actualTableData.length)
                    
                  })
  
            }
  
            else {
  
                if(overall_count>5 && overall_count<=10){
                    this.pagination(5)
  
                }
  
                if(overall_count>10 && overall_count<= 15){
                    this.pagination(5)
                    this.pagination(10)
                    
                }
  
                if(overall_count>15 && overall_count <=20){
                    this.pagination(5)
                    this.pagination(10)
                    this.pagination(15)
                }
  
                if(overall_count>20){
                    this.pagination(5)
                    this.pagination(10)
                    this.pagination(15)
                    this.pagination(20)
  
                }
  
            }
        })
    }
  
  
    pagination(pagesize){
      if(pagesize==10){
        this.page_size.last().select('10')
      }
      else if(pagesize==5){
        this.page_size.last().select('5')
      }
      else if(pagesize==15){
        this.page_size.last().select('15')
      }
      else if(pagesize=20){
        this.page_size.last().select('20')
      }
      this.pagecount_button.last().then(($el) => {
        let gridData=[];
        const overall_count = $el.text()
        
        let page_count=Math.floor((overall_count)/pagesize)
        let remainder = overall_count%pagesize
        
       
        if(remainder>0){
          page_count=page_count+1
        }
  
        if(remainder==0){remainder=pagesize}else{remainder=remainder}
        
  
        //console.log(page_count)
        let j=1;
        
  
        for(let i=0;i<page_count;i++){
          cy.wait(1000)
          this.ag_grid.getAgGridData().then((actualTableData)=>{
            
            gridData=gridData.concat(actualTableData)
            //console.log(gridData)
            
          })
  
          
          
          this.page_number.last().contains(i+1)
          this.total_page.last().contains(page_count)
          this.firstrow_on_page.first().contains(j)
          if(i==page_count-1){
            this.lastrow_on_page.first().contains(overall_count)
            this.ag_grid.getAgGridData().then((actualTableData)=>{
              //console.log(actualTableData)
              //console.log(remainder)
              expect(actualTableData.length).to.eq(remainder)
              expect(gridData.length).to.eq(parseInt(overall_count))
            })
          }
          else{
            
            this.lastrow_on_page.last().contains((i+1)*pagesize)
            this.ag_grid.getAgGridData().then((actualTableData)=>{
              expect(actualTableData.length).to.eq(pagesize)
            })
          }
          
          this.pagecount_button.last().contains(overall_count)
          this.nextpage.last().click()
          j+=pagesize
  
          
          
  
  
        }
  
  
  
  
        
  
        
  
      })
  
     this.firstpage.last().click()
     this.page_size.last().select('10')
    }

    griddata(query,config,field_names){
    cy.wait(1000)
      this.total_page.eq(0).then(($el) => {
        let gridData=[];

        const page_count = $el.text()

        for(let i=0;i<page_count;i++){

          this.ag_grid.getAgGridData().then((actualTableData)=>{
            
            gridData=gridData.concat(actualTableData)
            

            if(i==page_count-1){
              cy.log(gridData)
              
              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: query
              }).then((result) => {

                //console.log(result.rows[0])
                //console.log(gridData[0])


                expect(result.rows.length).to.eq(gridData.length)


            
                    for(let i=0;i<result.rows.length;i++){
                      expect(result.rows[i][field_names[0]]).to.eq(gridData[i][field_names[2]])
                      expect(result.rows[i][field_names[1]]).to.eq(gridData[i][field_names[3]])
                      
                    }

                  
                                

              })
              
            }
            
          })

          this.nextpage.eq(0).click()

        }

        

      })

      this.firstpage.eq(0).click()
      

    }

    external_griddata(query,config,field_names){
    
      this.total_page.eq(0).then(($el) => {
        let gridData=[];

        const page_count = $el.text()

        for(let i=0;i<page_count;i++){

          this.ag_grid.getAgGridData().then((actualTableData)=>{
            
            gridData=gridData.concat(actualTableData)
            

            if(i==page_count-1){
              cy.log(gridData)
              
              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: query
              }).then((result) => {

                //console.log(result.rows[0])
                //console.log(gridData[0])


                expect(result.rows.length).to.eq(gridData.length)


            
                    for(let i=0;i<result.rows.length;i++){
                      expect(result.rows[i][field_names[0]]).to.eq(gridData[i][field_names[4]])
                      expect(result.rows[i][field_names[1]]).to.eq(gridData[i][field_names[5]])
                      expect(result.rows[i][field_names[2]]).to.eq(gridData[i][field_names[6]])
                      expect(result.rows[i][field_names[3]]).to.eq(gridData[i][field_names[7]])

                      
                    }

                  
                                

              })
              
            }
            
          })

          this.nextpage.eq(0).click()

        }

        

      })

      this.firstpage.eq(0).click()
      

    }

    qual_griddata(query,config,field_names){
    
      this.total_page.eq(0).then(($el) => {
        let gridData=[];

        const page_count = $el.text()

        for(let i=0;i<page_count;i++){

          this.ag_grid.getAgGridData().then((actualTableData)=>{
            
            gridData=gridData.concat(actualTableData)
            

            if(i==page_count-1){
              cy.log(gridData)
              
              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: query
              }).then((result) => {

                //console.log(result.rows[0])
                //console.log(gridData[0])


                expect(result.rows.length).to.eq(gridData.length)


            
                    for(let i=0;i<result.rows.length;i++){
                      expect(result.rows[i][field_names[0]]).to.eq(gridData[i][field_names[3]])
                      expect(result.rows[i][field_names[1]]).to.eq(gridData[i][field_names[4]])
                      expect(result.rows[i][field_names[2]]).to.eq(gridData[i][field_names[5]])
                    

                      
                    }

                  
                                

              })
              
            }
            
          })

          this.nextpage.eq(0).click()

        }

        

      })

      this.firstpage.eq(0).click()
      

    }

    
    dataset_griddata(query,config,field_names){
    
      this.total_page.eq(0).then(($el) => {
        let gridData=[];

        const page_count = $el.text()

        for(let i=0;i<page_count;i++){

          this.ag_grid.getAgGridData().then((actualTableData)=>{
            
            gridData=gridData.concat(actualTableData)
            

            if(i==page_count-1){
              cy.log(gridData)
              
              cy.task("DATABASE", {
                dbConfig: Cypress.env(config),
                sql: query
              }).then((result) => {

                //console.log(result.rows[0])
                //console.log(gridData[0])


                expect(result.rows.length).to.eq(gridData.length)


            
                    for(let i=0;i<result.rows.length;i++){
                      expect(result.rows[i][field_names[0]]).to.eq(gridData[i][field_names[5]])
                      expect(result.rows[i][field_names[1]]).to.eq(gridData[i][field_names[6]])
                      expect(result.rows[i][field_names[2]]).to.eq(gridData[i][field_names[7]])
                      expect(result.rows[i][field_names[3]]).to.eq(gridData[i][field_names[8]])
                      expect(result.rows[i][field_names[4]]).to.eq(gridData[i][field_names[9]])
                    

                    

                      
                    }

                  
                                

              })
              
            }
            
          })

          this.nextpage.eq(0).click()

        }

        

      })

      this.firstpage.eq(0).click()
      

    }


    is_active(code){
      cy.wait(1000)
        this.search_box.clear()

        this.search_box.type(code)
        this.active_button.should('have.css', 'background-color', 'rgb(0, 104, 181)')
        this.active_button.click()
        this.search_box.clear()
        this.search_box.type(code)
        this.active_button.should('have.css', 'background-color', 'rgb(255, 255, 255)')
        cy.on("uncaught:exception", (err, runnable) => {
          return false;
        });
    }


    external_is_active(code){
      this.search_box.clear()
      this.search_box.type(code)
      this.external_active_button.should('have.css', 'background-color', 'rgb(0, 104, 181)')
      this.external_active_button.click()
      cy.wait(2000)
      this.external_active_button.should('have.css', 'background-color', 'rgb(255, 255, 255)')
      cy.on("uncaught:exception", (err, runnable) => {
        return false;
      });
  }


  dataset_is_active(code){
    this.search_box.clear()
    this.search_box.type(code)
    this.dataset_active_button.should('have.css', 'background-color', 'rgb(0, 104, 181)')
    this.dataset_active_button.click()
    cy.wait(2000)
    this.dataset_active_button.should('have.css', 'background-color', 'rgb(255, 255, 255)')
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
}


  qual_is_active(code){
    this.search_box.clear()
    this.search_box.type(code)
    this.qual_active_button.should('have.css', 'background-color', 'rgb(0, 104, 181)')
    this.qual_active_button.click()
    cy.wait(2000)
    this.qual_active_button.should('have.css', 'background-color', 'rgb(255, 255, 255)')
    cy.on("uncaught:exception", (err, runnable) => {
      return false;
    });
}

    backend_entry(query,config,code){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: query+code+"'  and actv_ind='N' "
          }).then((result) => {

            //console.log(result.rows)

            expect(result.rows[0].cnt).to.eq('1')
           

            

          })
    }


    delete_the_record(query,code,config){
        cy.task("DATABASE", {
            dbConfig: Cypress.env(config),
            sql: query+code+"'"
          }).then((result) => {
    
          })
    
        }



        


   
  }
  
  export default new configfunc();
  