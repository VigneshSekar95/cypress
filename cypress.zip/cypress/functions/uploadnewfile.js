
const now = Math.floor(Date.now() / 1000);
import { decode } from "jsonwebtoken";

let envi = Cypress.env('ENV');
console.log(envi)
const env_var = require('../support/environment')

const url = env_var.getBaseUrl(envi);
const tenant_id = env_var.getTenantID(envi);
const client_id = env_var.getClientID(envi);
const client_secret = env_var.getClientSecret(envi);
const scope = env_var.getScope(envi);
const resource = env_var.getResource(envi);
const sessionStorage_1_key = env_var.getSessionStorage_1_key(envi);
const sessionStorage_1_value1 = env_var.getSessionStorage_1_value1(envi);
const sessionStorage_1_value2 = env_var.getSessionStorage_1_value2(envi);
const sessionStorage_2_key = env_var.getSessionStorage_2_key(envi);
const sessionStorage_2_value = env_var.getSessionStorage_2_value(envi);

const { encrypt, decrypt } = require('../e2e/crypto')
const config_encrypt = env_var.getpostgres_conn(envi);
const config = JSON.parse(decrypt(config_encrypt));

console.log(decrypt(tenant_id))

class UploadNewFile {

  get dataset_menu(){
    return cy.xpath('//*[@id="datasetDropdown"]')
  }

  get uploadfilebutton() {
    return cy.xpath('//*[@id="basic-navbar-nav"]/div[1]/div/div/a[1]');
  }

  get page_title() {
    return cy.xpath('//*[@id="root"]/div[2]/main/h3');
  }

  get platform_header() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div[1]/div[2]/p/div[1]/label');
  }

  get subject_header() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div[1]/div[2]/p/div[2]/label');
  }

  get process_header() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div[1]/div[2]/p/div[3]/label');
  }

  get dataset_header() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div[1]/div[2]/p/div[4]/label');
  }

  get platform_dropdown() {
    return cy.xpath('//*[@id="platform"]');
  }

  get subject_dropdown() {
    return cy.xpath(
      '//*[@id="tier2Name"]'
    );
    //return cy.get('#react-select-2-input')
  }

  get getsubjectarealist() {
    //return cy.get('#react-select-2-listbox')
    // return cy.xpath('//*[@id="react-select-5-listbox"]/div')
    return cy.get(".card-body>p>div:nth-of-type(2)>div>div:nth-of-type(2)>div");
  }

  get process_dropdown() {
    return cy.xpath(
      '//*[@id="tier3Name"]'
    );
    //return cy.get("#react-select-3-input");
  }

  get getprocessarealist() {
    return cy.get(".card-body>p>div:nth-of-type(3)>div>div:nth-of-type(2)>div");
  }

  get dataset_dropdown() {
    return cy.xpath(
      '//*[@id="datasetNameDscPair"]'
    );
    // return cy.get('#react-select-4-input')
  }

  get getdatasetlist() {
   // return cy.get(".card-body>p>div:nth-of-type(4)>div>div:nth-of-type(2)>div>div");
   //return cy.xpath('//*[@id="react-select-4-option-2"]')
   return cy.get('.card-body>p>div:nth-of-type(4)>div>div:nth-of-type(2)>div>div:nth-of-type(1)')
  }

  get template_version(){
    return cy.xpath('//*[@id="versionNameNumberPair"]')
  }

  get user_profile() {
    return cy.xpath('//*[@id="nav-dropdown-light-example"]');
  }

  get email_addr() {
    return cy.xpath('//*[@id="userSignOutDropdown"]/div')

  }

  get template_name() {
    return cy.xpath('//*[@id="root"]/div[2]/main/div[2]/div[2]/p/span/span');
  }

  get browse_button() {
    return cy.xpath('//*[@id="btn"]');
  }

  get input_file() {
    return cy.xpath('//*[@id="customFile"]');
  }

  get configuration_button() {
    return cy.xpath('//*[@id="responsive-navbar-nav"]/div[1]/a[4]');
  }

  get input_file_name() {
    return cy.xpath(
      '//*[@id="uncontrolled-tab-example-tabpane-0"]/div[1]/div/span[1]'
    );
  }

  get input_file_name() {
    return cy.xpath(
      '//*[@id="uncontrolled-tab-example-tabpane-0"]/div[1]/div/span[1]'
    );
  }

  get cross_button() {
    return cy.xpath(
      '//*[@id="uncontrolled-tab-example-tabpane-0"]/div[1]/div/span[1]/i'
    );
  }

  get file_size() {
    return cy.xpath(
      '//*[@id="uncontrolled-tab-example-tabpane-0"]/div[1]/div/span[2]'
    );
  }

  get preload_check_header() {
    return cy.xpath(
      '//*[@id="uncontrolled-tab-example-tabpane-0"]/div[2]/div[1]/span'
    );
  }

  get progress_bar() {
    return cy.xpath(
      '//*[@id="uncontrolled-tab-example-tabpane-0"]/div[2]/div[1]/div/div/div[1]/div'
    );
  }

get second_progress_bar(){
  return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-0"]/div[2]/div[2]/div/div/div[1]/div')
}
  

  get preload_message() {
    return cy.xpath(
      '//*[@id="uncontrolled-tab-example-tabpane-0"]/div[2]/div[1]/div/div/div[2]'
    );
  }

  get external_header(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-0"]/div[2]/div[2]/span')
  }

  get external_progress_bar(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-0"]/div[2]/div[2]/div/div/div[1]/div')
  }

  get external_message(){
    return cy.xpath('//*[@id="uncontrolled-tab-example-tabpane-0"]/div[2]/div[2]/div/div/div[2]')
  }

  visit_upload_file_page() {
    this.dataset_menu.click()
    this.uploadfilebutton.contains("Upload File");
    cy.wait(5000)
    this.uploadfilebutton.click();
  }

  pagetitle_validation() {
    this.page_title.should("have.text", "Upload New File");
  }

  dropdown_header() {
    this.platform_header.should("have.text", "Platform*:");
    this.subject_header.should("have.text", "Program/Subject Area*:");
    this.process_header.should("have.text", "Process Area*:");
    this.dataset_header.should("have.text", "Dataset*:");
  }

  Dropdown_selection_old() {
    this.browse_button.should("be.disabled");
    this.platform_dropdown.select("CRM");
    cy.wait(2000);
    this.browse_button.should("be.disabled");
    this.subject_dropdown.click();
    this.getsubjectarealist.contains("IPA").click();
    cy.wait(2000);
    this.browse_button.should("be.disabled");
    this.process_dropdown.click();
    this.getprocessarealist.contains("IOTG").click();
    cy.wait(2000);
    this.browse_button.should("be.disabled");
    this.dataset_dropdown.click();
    this.getdatasetlist.should('have.text','Co-Sell').first().click()
    // this.getdatasetlist.should('have.text',"Co-Sell").click();

   // this.
     this.browse_button.should("be.enabled");
  }

 

  Template_name(config) {
    // this.dataset_dropdown.last().then(($el) => {

    //    cy.log($el.text())

    // })
    //Co-Sell1, Co-Sell for Nutanix
    //this.user_profile.click();
    this.email_addr.first().then(($el) => {
      cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql:
          `select o.org_nm  from cdm_accs_enttl.usr u 
                    inner join cdm_accs_enttl.prncpl p on p.prncpl_id = u.prncpl_id
                    inner join cdm_accs_enttl.org o on p.org_id = o.org_id  
                    where u.usr_nm='` +
          $el.text().trim() +
          `'
                    union all
                    select ' '||dset_cd||', '||dset_dsc||' for Salesout version for ' from cdm_core.dset_lkup where dset_lkup.dset_cd='Co-Sell'`,
      }).then((result) => {
        cy.log(result.rows[0].org_nm);

        this.template_name.first().then(($el) => {
          expect($el.text()).to.eq(
            result.rows[1].org_nm.concat(result.rows[0].org_nm)
          );
        });
      });
    });
  }

  access_token_storage(){
    cy.request({method: 'POST',
    url: 'https://login.microsoftonline.com/'+decrypt(tenant_id)+'/oauth2/token', 
    form: true, 
    body: {
        client_id: decrypt(client_id),
        client_secret: decrypt(client_secret),
        grant_type: "client_credentials",
        scope:decrypt(scope),
        resource:decrypt(resource)
    },
  }).then(
(response) => {
  console.log(response)
  localStorage.setItem("accessToken",response.body.access_token)
})
  }

  upload_file_no_headers(file_type,file_name) {
    cy.on('uncaught:exception', (err, runnable) => {
      return false })
      //sessionStorage.clear()
  
  
    //this.configuration_button.click();
   // this.uploadfilebutton.click();
    this.Dropdown_selection();
    this.input_file.attachFile(file_type+"/"+file_name);
    this.input_file_name.contains(file_name);
    //this.file_size.should("have.text", "Size:155 Bytes");
    this.cross_button.click();
    this.input_file_name.contains("No files selected");
    this.file_size.should("have.text", "Size:N/A");
    this.input_file.attachFile(file_type+"/"+file_name);
    cy.wait(2000)
    this.browse_button.click();
    cy.wait(20000);
    this.preload_check_header.should("have.text", "Preload Check Progress:");
    this.progress_bar.should("have.css", "background-color", "rgb(206, 0, 0)");
    this.preload_message.should(
      "have.text",
      "Preload Fail. Expected header and actual header do not match."
    );
  }

  upload_file_only_header(file_type,file_name) {
    cy.on('uncaught:exception', (err, runnable) => {
      return false })
    //this.configuration_button.click();
   // this.uploadfilebutton.click();
    this.Dropdown_selection();
    this.input_file.attachFile(file_type+"/"+file_name);
    this.input_file_name.contains(file_name);
    //this.file_size.should("have.text", "Size:155 Bytes");
    this.cross_button.click();
    this.input_file_name.contains("No files selected");
    this.file_size.should("have.text", "Size:N/A");
    this.input_file.attachFile(file_type+"/"+file_name);
    cy.wait(2000)
    this.browse_button.click();
    cy.wait(20000);
    this.preload_check_header.should("have.text", "Preload Check Progress:");
    this.progress_bar.should("have.css", "background-color", "rgb(206, 0, 0)");
    this.preload_message.should(
      "have.text",
      "Preload Fail. File has no rows, only the header."
    );
  }

  upload_file_different_extension(file_type,file_name) {
    cy.on('uncaught:exception', (err, runnable) => {
      return false })
  // this.configuration_button.click();
   // this.uploadfilebutton.click();
    this.Dropdown_selection();
    this.input_file.attachFile(file_type+"/"+file_name);
    this.input_file_name.contains(file_name);
   // this.file_size.should("have.text", "Size:155 Bytes");
    this.cross_button.click();
    this.input_file_name.contains("No files selected");
    this.file_size.should("have.text", "Size:N/A");
    this.input_file.attachFile(file_type+"/"+file_name);
   cy.wait(5000);
    this.browse_button.click();
    cy.wait(20000);
    this.preload_check_header.should("have.text", "Preload Check Progress:");
    this.progress_bar.should("have.css", "background-color", "rgb(206, 0, 0)");
    this.preload_message.contains(
      
      "File extension png not supported, valid extensions are:- ['xlsx', 'xls', 'txt', 'csv', 'json', 'xml']"
    );
  }

  preload_external_pass(file_type,file_name) {
    cy.on('uncaught:exception', (err, runnable) => {
      return false })
    //this.configuration_button.click();
    //this.uploadfilebutton.click();
    this.Dropdown_selection();
    this.input_file.attachFile(file_type+"/"+file_name);
    this.input_file_name.contains(file_name);
    //this.file_size.should("have.text", "Size:1.54 KB");
    this.cross_button.click();
    this.input_file_name.contains("No files selected");
    this.file_size.should("have.text", "Size:N/A");
    this.input_file.attachFile(file_type+"/"+file_name);
    cy.wait(2000);
    this.browse_button.click();
    cy.wait(20000);
    this.preload_check_header.should("have.text", "Preload Check Progress:");
    this.progress_bar.should("have.css", "background-color", "rgb(0, 138, 0)");
    this.preload_message.should(
      "have.text",
      "Preload Process. File is valid"
    );
    this.external_header.should("have.text", "External Check Progress:");
    this.second_progress_bar.should("have.css", "background-color", "rgb(0, 138, 0)");
    this.external_message.contains(
      "Validation successful, No errors. File Reference ID :"
    );
  }


  external_fail_scenario(file_type,file_name) {
    cy.on('uncaught:exception', (err, runnable) => {
      return false })
    //this.configuration_button.click();
    //this.uploadfilebutton.click();
    this.Dropdown_selection();
    this.input_file.attachFile(file_type+"/"+file_name);
    this.input_file_name.contains(file_name);
   // this.file_size.should("have.text", "Size:1.54 KB");
    this.cross_button.click();
    this.input_file_name.contains("No files selected");
    this.file_size.should("have.text", "Size:N/A");
    this.input_file.attachFile(file_type+"/"+file_name);
    cy.wait(2000)
    this.browse_button.click();
    cy.wait(20000);
    this.preload_check_header.should("have.text", "Preload Check Progress:");
    this.progress_bar.should("have.css", "background-color", "rgb(0, 138, 0)");
    this.preload_message.should(
      "have.text",
      "Preload Process. File is valid"
    );
    this.external_header.should("have.text", "External Check Progress:");
    this.second_progress_bar.should("have.css", "background-color", "rgb(206, 0, 0)");
    this.external_message.contains('Validation failed, fallout file generated to ADLS.')
  }

  external_fail_scenario_version(file_type,file_name,config,version) {
    cy.on('uncaught:exception', (err, runnable) => {
      return false })
    //this.configuration_button.click();
    //this.uploadfilebutton.click();
    this.version_dropdown_validation(config,version)
    this.input_file.attachFile(file_type+"/"+file_name);
    this.input_file_name.contains(file_name);
   // this.file_size.should("have.text", "Size:1.54 KB");
    this.cross_button.click();
    this.input_file_name.contains("No files selected");
    this.file_size.should("have.text", "Size:N/A");
    this.input_file.attachFile(file_type+"/"+file_name);
    cy.wait(2000)
    this.browse_button.click();
    cy.wait(20000);
    this.preload_check_header.should("have.text", "Preload Check Progress:");
    this.progress_bar.should("have.css", "background-color", "rgb(0, 138, 0)");
    this.preload_message.should(
      "have.text",
      "Preload Process. File is valid"
    );
    this.external_header.should("have.text", "External Check Progress:");
    this.second_progress_bar.should("have.css", "background-color", "rgb(206, 0, 0)");
    this.external_message.contains('Validation failed, fallout file generated to ADLS.')
  }


  upload_pipe_delimited_file(file_type,file_name) {
   // this.configuration_button.click();
    //this.uploadfilebutton.click();
    // cy.reload()
    // cy.wait(5000)
    this.Dropdown_selection();
    this.input_file.attachFile(file_type+"/"+file_name);
    this.input_file_name.contains(file_name);
    //this.file_size.should("have.text", "Size:155 Bytes");
    this.cross_button.click();
    this.input_file_name.contains("No files selected");
    this.file_size.should("have.text", "Size:N/A");
    this.input_file.attachFile(file_type+"/"+file_name);
    cy.wait(5000);
    this.browse_button.click();
    cy.wait(5000);
    this.preload_check_header.should("have.text", "Preload Check Progress:");
    this.progress_bar.should("have.css", "background-color", "rgb(206, 0, 0)");
    this.preload_message.should(
      "have.text",
      "Preload Fail. File has no rows, only the header."
    );
  }


  uploading_xlsx_file(file_type,file_name) {
    cy.on('uncaught:exception', (err, runnable) => {
      return false })
   // this.configuration_button.click();
    //this.uploadfilebutton.click();
    this.Dropdown_selection();
    this.input_file.attachFile(file_type+"/"+file_name);
    this.input_file_name.contains(file_name);
    //this.file_size.should("have.text", "Size:155 Bytes");
    this.cross_button.click();
    this.input_file_name.contains("No files selected");
    this.file_size.should("have.text", "Size:N/A");
    this.input_file.attachFile(file_type+"/"+file_name);
    cy.wait(2000);
    this.browse_button.click();
    cy.wait(20000);
    this.preload_check_header.should("have.text", "Preload Check Progress:");
    this.progress_bar.should("have.css", "background-color", "rgb(206, 0, 0)");
    this.preload_message.should(
      "have.text",
      "Preload Fail. Incorrect extension for Delimited type file"
    );
  }

  uploading_csv_file(file_type,file_name){
    cy.on('uncaught:exception', (err, runnable) => {
      return false })
    //this.configuration_button.click();
    //this.uploadfilebutton.click();
    this.Dropdown_selection();
    this.input_file.attachFile(file_type+"/"+file_name);
    this.input_file_name.contains(file_name);
    //this.file_size.should("have.text", "Size:155 Bytes");
    this.cross_button.click();
    this.input_file_name.contains("No files selected");
    this.file_size.should("have.text", "Size:N/A");
    this.input_file.attachFile(file_type+"/"+file_name);
    cy.wait(2000);
    this.browse_button.click();
    cy.wait(20000);
    this.preload_check_header.should("have.text", "Preload Check Progress:");
    this.progress_bar.should("have.css", "background-color", "rgb(206, 0, 0)");
    this.preload_message.should(
      "have.text",
      "Preload Fail. Incorrect extension for Excel type file"
    );
  }


  file_type_changing_to_xlsx(config){
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `update cdm_core.dset_lkup set file_type_cd='Excel' where dset_lkup.dset_cd='Co-Sell'`
    }).then((result) => {

    })
  }


  file_type_changing_to_pipe(config){
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `update cdm_core.dset_lkup set file_type_cd='Delimited',file_dlmtr='|' where dset_lkup.dset_cd='Co-Sell'`
    }).then((result) => {

    })
  }


  file_type_changing_to_csv(config){
    cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `update cdm_core.dset_lkup set file_type_cd='Delimited',file_dlmtr=',' where dset_lkup.dset_cd='Co-Sell'`
    }).then((result) => {

    })
  }


  platform_dropdown_selection(config){

    cy.task("DATABASE", {
        dbConfig: Cypress.env(config),
        sql: `Select distinct t.pltfrm_cd from cdm_core.org_allw_templt t
        inner join cdm_accs_enttl.org o on t.org_id = o.org_id
        where o.org_nm='Dell'`,
      }).then((result) => {
        for(let i=0;i<result.rows.length;i++){
            this.platform_dropdown.select(result.rows[i].pltfrm_cd)
        }

        this.platform_dropdown.find('option').should('have.length',result.rows.length+1)
        this.platform_dropdown.select('CRM')
      })

}

subject_area_dropdown_selection(config){

  cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `Select distinct t1.tier2_hier_nm from cdm_core.org_allw_templt t
      inner join cdm_accs_enttl.org o on t.org_id = o.org_id
      inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
      where o.org_nm='Dell' and  t.pltfrm_cd='CRM'`,
    }).then((result) => {
      for(let i=0;i<result.rows.length;i++){
          this.subject_dropdown.select(result.rows[i].tier2_hier_nm)
      }

      this.subject_dropdown.find('option').should('have.length',result.rows.length+1)
      this.subject_dropdown.select('IPA')
    })

}

process_area_dropdown_selection(config){

  cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `Select distinct t1.tier3_hier_nm from cdm_core.org_allw_templt t
      inner join cdm_accs_enttl.org o on t.org_id = o.org_id
      inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
      where o.org_nm='Dell' and  t.pltfrm_cd='CRM'`,
    }).then((result) => {
      for(let i=0;i<result.rows.length;i++){
          this.process_dropdown.select(result.rows[i].tier3_hier_nm)
      }

      this.process_dropdown.find('option').should('have.length',result.rows.length+1)
      this.process_dropdown.select('IOTG')
    })

}


dataset_dropdown_selection(config){

  cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `Select distinct t.dset_cd from cdm_core.org_allw_templt t
      inner join cdm_accs_enttl.org o on t.org_id = o.org_id
      inner join cdm_core.tier2_3_hier t1 on t1.tier2_3_hier_id = t.tier2_3_hier_id
      where o.org_nm='Dell' and  t.pltfrm_cd='CRM'`,
    }).then((result) => {
      for(let i=0;i<result.rows.length;i++){
          this.dataset_dropdown.select(result.rows[i].dset_cd)
      }

      this.dataset_dropdown.find('option').should('have.length',result.rows.length+1)
      this.dataset_dropdown.select('Co-Sell')
    })

}


version_dropdown_selection(config,version){

  cy.task("DATABASE", {
      dbConfig: Cypress.env(config),
      sql: `Select  distinct tm.templt_ver_nm
      from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd and tm.tier2_3_hier_id = t.tier2_3_hier_id
            where o.org_nm='Dell' and  t.pltfrm_cd='CRM' and t.actv_ind='Y' and t.dset_cd='Co-Sell' `,
    }).then((result) => {
      for(let i=0;i<result.rows.length;i++){
          this.template_version.select(result.rows[i].templt_ver_nm)
      }

      this.template_version.find('option').should('have.length',result.rows.length+1)
     
    })

    this.template_version.select(version)

}


version_dropdown_validation(config,version){
  this.platform_dropdown_selection(config)
  this.subject_area_dropdown_selection(config)
  this.process_area_dropdown_selection(config)
  this.dataset_dropdown_selection(config)
  this.version_dropdown_selection(config,version)
}


Checking_backend(config,version){
  cy.task("DATABASE", {
    dbConfig: Cypress.env(config),
    sql: `Select * from (
      Select A, templt_ver_nbr, org_templt_pri from (
      Select  'File_onboard_ins' as A, ins.templt_ver_nbr, ins.org_templt_pri, rank() over (order by ins.file_instc_id desc)  as rnk
      from cdm_core.file_onbord_instc ins
      )B where rnk=1
      
      union all
      
      Select 'Org_allow_tem' as A, t.templt_ver_nbr, t.org_templt_pri
      from cdm_core.org_allw_templt t
            inner join cdm_accs_enttl.org o on t.org_id = o.org_id
            inner join cdm_core.templt tm on tm.templt_ver_nbr = t.templt_ver_nbr and t.pltfrm_cd = tm.pltfrm_cd and t.dset_cd = tm.dset_cd and tm.tier2_3_hier_id = t.tier2_3_hier_id
            where o.org_nm='Dell' and  t.pltfrm_cd='CRM' and t.actv_ind='Y' and t.dset_cd='Co-Sell' and tm.templt_ver_nm='`+version+`'
      
      )A order by A desc`,
  }).then((result) => {
        expect(result.rows[0].templt_ver_nbr).to.eq(result.rows[1].templt_ver_nbr)
        expect(result.rows[0].org_templt_pri).to.eq(result.rows[1].org_templt_pri)
    
  })
}

Dropdown_selection(){
  this.platform_dropdown.select("CRM");
  cy.wait(2000);
  //this.browse_button.should("be.disabled");
  this.subject_dropdown.select("IPA");
  cy.wait(2000);
  //this.browse_button.should("be.disabled");
  this.process_dropdown.select("IOTG");
  cy.wait(2000);
  //this.browse_button.should("be.disabled");
  this.dataset_dropdown.select("Co-Sell");
  cy.wait(2000);
  //this.browse_button.should("be.disabled");
  this.template_version.select("Salesout");
  cy.wait(2000);
}


}

export default new UploadNewFile();
