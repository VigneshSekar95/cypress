// ************************Processing  Grid Queries***********************************
// 
// We are storing all the queries that is used for testing the processing page scenarios
// Queries we store here are used for testing the below scenarios:
// 1.Real time change of status and validation report column in the grid
// 2.Column level filter for the fields Partner, Status in the grid 
// 3.Grid data validation in the processing grid

module.exports={
    set_status_success:`
    update cdm_core.file_onbord_instc  set latst_onbord_sts_cd='CDM_Internal_Success'  
    where file_ref_id = ( select  fil.file_ref_id from 
       cdm_core.file_onbord_instc fil
       
    where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',

    'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
    order by fil.chg_dtm desc limit 1)`,

    set_status_data_dump_path_original:`
    update cdm_core.file_onbord_sub_instc  set nrch_data_full_pth='Enriched/Intel/CRM/IPA/IOTG/Co-Sell/2022/06/28/940_Rashmi_20220628/Vignesh_original.csv'  
    where file_instc_id = ( select  fil.file_instc_id from 
       cdm_core.file_onbord_instc fil
       
    where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',

    'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
    order by fil.chg_dtm desc limit 1)`,

    set_validation_report_original:`update cdm_core.file_onbord_sub_instc  set intrnl_vld_rpt_full_pth='Process/Validation Report Consolidated/Dell/CRM/IPA/ISV/Salesout/Salesout/2022/11/14/2823_Surbhi Chaurasiya_20221114/Vignesh_INTERNAL_Original.csv'  
    where file_instc_id = ( select  fil.file_instc_id from 
       cdm_core.file_onbord_instc fil
       
    where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',

    'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
    order by fil.chg_dtm desc limit 1)`,


    set_validation_report:`update cdm_core.file_onbord_sub_instc  set intrnl_vld_rpt_full_pth='Process/Validation Report Consolidated/Dell/CRM/IPA/ISV/Salesout/Salesout/2022/11/14/2823_Surbhi Chaurasiya_20221114/Vignesh_INTERNAL.csv'  
    where file_instc_id = ( select  fil.file_instc_id from 
       cdm_core.file_onbord_instc fil
       
    where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',

    'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
    order by fil.chg_dtm desc limit 1)`,

    set_status_data_dump_path:`
    update cdm_core.file_onbord_sub_instc  set nrch_data_full_pth='Enriched/Intel/CRM/IPA/IOTG/Co-Sell/2022/06/28/940_Rashmi_20220628/Vignesh.csv'  
    where file_instc_id = ( select  fil.file_instc_id from 
       cdm_core.file_onbord_instc fil
       
    where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',

    'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
    order by fil.chg_dtm desc limit 1)`,

    set_status_failed:`
    update cdm_core.file_onbord_instc  set latst_onbord_sts_cd='CDM_Internal_Failed'  
    where file_ref_id = ( select  fil.file_ref_id from 
       cdm_core.file_onbord_instc fil
       
    where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',

    'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
    order by fil.chg_dtm desc limit 1)`,


    inprocesstab_title:'Processing',
    inprocesspage_subdesc:'All processed files will be moved to the history section.',
    expected_columns_processing:['','File Reference Id',"Partner","","File Name","Uploaded Date (UTC)","Upload Mode","Status",
    "Validation Report","Enriched File"],

    grid_query:`
    select
file_ref_id,partner,substr(File_name_1,0,position('.' in File_name_1)-20)||substr(File_name_1,position('.' in File_name_1),length(File_name_1)) as file_name,
uploaded_date,upload_mode,status,validation_report,enriched_file from (
SELECT
fil.file_ref_id,
org1.org_nm as Partner,
substr(fil.file_land_full_pth,length(fil.file_land_full_pth) - position('/' in reverse(fil.file_land_full_pth)) + 2,
            length(fil.file_land_full_pth)) as File_name_1,
to_char(fil.file_land_dtm at time zone 'UTC','Mon DD')||', ' 
            ||to_char(fil.file_land_dtm at time zone 'UTC','YYYY')||' '||to_char( fil.file_land_dtm at time zone 'UTC', 'HH12:MI PM' ) as Uploaded_Date,
case when us.use_case_type_cd ='OL' then 'Online' else 'Offline' end as Upload_Mode,
case when fil.latst_onbord_sts_cd in ('CDM_Internal_IP') then 'Internal Process'
when fil.latst_onbord_sts_cd in ('CDM_Internal_Success') then 'Internal Success'
when fil.latst_onbord_sts_cd in ('CDM_Internal_Failed') then 'Internal Fail'
when fil.latst_onbord_sts_cd in ('CDM_Duplicate_Reprocess') then 'Duplicate'
end as Status,
 case when (sub.intrnl_vld_rpt_full_pth is null or sub.intrnl_vld_rpt_full_pth ='') then 'NA' 
 when sub.intrnl_vld_rpt_full_pth ='path' then 'path'
 else substr(sub.intrnl_vld_rpt_full_pth,length(sub.intrnl_vld_rpt_full_pth) - position('/' in reverse(sub.intrnl_vld_rpt_full_pth)) + 2,
            length(sub.intrnl_vld_rpt_full_pth)) end as Validation_Report,
    case when (sub.nrch_data_full_pth is null or sub.nrch_data_full_pth ='') then 'NA' else substr(sub.nrch_data_full_pth,length(sub.nrch_data_full_pth) - position('/' in reverse(sub.nrch_data_full_pth)) + 2,
            length(sub.nrch_data_full_pth)) end  as Enriched_File        
from 
   cdm_core.file_onbord_instc fil
     inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
            inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
      left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
      left join cdm_core.org_allw_templt_ingest_mode ing on fil.tier2_3_hier_id = ing.tier2_3_hier_id and fil.org_id =  ing.org_id and fil.templt_ver_nbr = ing.templt_ver_nbr
      and fil.dset_cd = ing.dset_cd and fil.data_ingest_mode_cd = ing.data_ingest_mode_cd and fil.pltfrm_cd = ing.pltfrm_cd
     left join cdm_core.data_ingest_mode_lkup data_ing on ing.data_ingest_mode_cd = data_ing.data_ingest_mode_cd
     left join cdm_core.use_case_type_lkup us on data_ing.use_case_type_cd = us.use_case_type_cd
      
where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Confirmed',

        'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
order by fil.chg_dtm desc

)a
`,

filter_partner_data:`arrow`,
filter_status:`success`,
filter_partner_query:`select count(*) as cnt
from 
   cdm_core.file_onbord_instc fil
     inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
            inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
      left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Reprocess','CDM_Duplicate_Confirmed',

'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
and org1.org_nm like '%Arrow%'`,
filter_status_query:`select count(*) as cnt
from 
   cdm_core.file_onbord_instc fil
     inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
            inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
      left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
where fil.latst_onbord_sts_cd not in ('CDM_Preload_Failed_Extension_Check', 'CDM_Preload_Failed_Header_Check', 'CDM_Preload_Failed_Empty_Check','CDM_Preload_Failed','CDM_Duplicate','CDM_Duplicate_Reprocess','CDM_Duplicate_Confirmed',

'CDM_File_Uploaded','CDM_External_IP','CDM_External_Success','CDM_External_Failed','CDM_Preload_Success','CDM_Preload_IP', 'CDM_Inactive', 'CDM_Published', 'CDM_Processing_Success')
and fil.latst_onbord_sts_cd like '%Success%'`
   
}