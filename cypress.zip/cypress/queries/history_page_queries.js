// ************************Historical Data Grid Queries***********************************
// 
// We are storing all the queries that is used for testing the historical page scenarios
// Queries we store here are used for testing the below scenarios:
// 1.Uploaded_date, Modified_date sorting check
// 2.Column level filter for all the fields in the grid
// 3.Grid data validation in the historical grid


module.exports={
    uploadedDate_ascending:`select file_ref_id, substr(File_name_1,0,position('.' in File_name_1)-20)||substr(File_name_1,position('.' in File_name_1),length(File_name_1)) as file_name from (
      select a.file_ref_id,
      substr(a.file_land_full_pth,length(a.file_land_full_pth) - position('/' in reverse(a.file_land_full_pth)) + 2,
      length(a.file_land_full_pth)) as File_name_1
      from cdm_core.file_onbord_instc a  where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
      and a.file_land_dtm >= (now() - interval '12 month')
      order by a.file_land_dtm asc
      )a`,

uploadedDate_descending:`select file_ref_id, substr(File_name_1,0,position('.' in File_name_1)-20)||substr(File_name_1,position('.' in File_name_1),length(File_name_1)) as file_name from (
  select a.file_ref_id,
  substr(a.file_land_full_pth,length(a.file_land_full_pth) - position('/' in reverse(a.file_land_full_pth)) + 2,
  length(a.file_land_full_pth)) as File_name_1
  from cdm_core.file_onbord_instc a  where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
  and a.file_land_dtm >= (now() - interval '12 month')
  order by a.file_land_dtm desc
  )a`,

modifiedDate_ascending:`select file_ref_id, substr(File_name_1,0,position('.' in File_name_1)-20)||substr(File_name_1,position('.' in File_name_1),length(File_name_1)) as file_name from (
  select a.file_ref_id,
  substr(a.file_land_full_pth,length(a.file_land_full_pth) - position('/' in reverse(a.file_land_full_pth)) + 2,
  length(a.file_land_full_pth)) as File_name_1
  from cdm_core.file_onbord_instc a  where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
  and a.file_land_dtm >= (now() - interval '12 month')
  order by a.chg_dtm asc
  )a`,

modifiedDate_descending:`select file_ref_id, substr(File_name_1,0,position('.' in File_name_1)-20)||substr(File_name_1,position('.' in File_name_1),length(File_name_1)) as file_name from (
  select a.file_ref_id,
  substr(a.file_land_full_pth,length(a.file_land_full_pth) - position('/' in reverse(a.file_land_full_pth)) + 2,
  length(a.file_land_full_pth)) as File_name_1
  from cdm_core.file_onbord_instc a  where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
  and a.file_land_dtm >= (now() - interval '12 month')
  order by a.chg_dtm desc
  )a`,

filter_fil_ref_id:` select count(*) as cnt from cdm_core.file_onbord_instc a  
where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
and a.file_land_dtm >= (now() - interval '12 month')
and cast(a.file_ref_id as varchar(100))  like '%6%';`,

filter_uploaded_date:` select count(*) as cnt from cdm_core.file_onbord_instc a  
where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
and a.file_land_dtm >= (now() - interval '12 month')
  and to_char(a.file_land_dtm at time zone 'UTC','Mon DD')||', ' 
  ||to_char(a.file_land_dtm at time zone 'UTC','YYYY')||' '||
  to_char( a.file_land_dtm at time zone 'UTC' , 'HH12:MI PM' )  
   like '%05%' `,

  filter_dataset:` select count(*) as cnt from cdm_core.file_onbord_instc a  
  where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
  and a.file_land_dtm >= (now() - interval '12 month')
  and cast(a.dset_cd as varchar(100))  like '%I%' `,

  filter_submission_period:` select count(*) as cnt from cdm_core.file_onbord_instc a  
  where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
  and a.file_land_dtm >= (now() - interval '12 month')
    and TO_CHAR(TO_DATE (cast(EXTRACT(MONTH FROM a.file_land_dtm)as varchar(100))::text, 'MM'),
     'Month')  like '%Sep%'`,

  
     filter_submitted_by :`select count(*) as cnt from cdm_core.file_onbord_instc a  
     inner join cdm_accs_enttl.usr b on a.upld_by_usr_prncpl_id = b.prncpl_id
     where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
and a.file_land_dtm >= (now() - interval '12 month')
       and cast(b.usr_nm as varchar(100))  like '%Vignesh%' `,


       filter_partner:`  select count(*) as cnt from cdm_core.file_onbord_instc a  
       inner join cdm_accs_enttl.usr usr on a.upld_by_usr_prncpl_id=usr.prncpl_id
inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
inner join cdm_accs_enttl.org org on org.org_id=a.org_id
       where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
and a.file_land_dtm >= (now() - interval '12 month')
         and cast(org.org_nm as varchar(100))  like '%Ar%' `,

      filter_filename:`select count(*) as cnt from (
        select a.file_ref_id,
        substr(a.file_land_full_pth,length(a.file_land_full_pth) - position('/' in reverse(a.file_land_full_pth)) + 2,
        length(a.file_land_full_pth)) as File_name
         from cdm_core.file_onbord_instc a  where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
         and a.file_land_dtm >= (now() - interval '12 month') 
        )a
        where  File_name like '%Happy%' `,
        
        
      filter_rows_loaded:`select count(*) as cnt from cdm_core.file_onbord_instc a  
      where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
         and a.file_land_dtm >= (now() - interval '12 month')
        and cast(a.rec as varchar(100))  like '%9%' `,

        filter_restatement:`select count(*) as cnt from cdm_core.file_onbord_instc a  
        where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
         and a.file_land_dtm >= (now() - interval '12 month')
          and cast(a.restate_file_ind as varchar(100))  like '%Y%' `,

        filter_file_status:` select count(*) as cnt from cdm_core.file_onbord_instc a  
        where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
         and a.file_land_dtm >= (now() - interval '12 month')
          and cast(a.latst_onbord_sts_cd as varchar(100))  like '%Publish%' `,

          filter_modified_by:`select count(*) as cnt from cdm_core.file_onbord_instc a  
          where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
         and a.file_land_dtm >= (now() - interval '12 month')
            and cast(a.chg_agnt_id as varchar(100))  like '%y%' `,


            filter_modified_datetime:`
            select count(*) as cnt from cdm_core.file_onbord_instc a  
where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
and a.file_land_dtm >= (now() - interval '12 month')
  and to_char(a.chg_dtm at time zone 'UTC','Mon DD')||', ' 
  ||to_char(a.chg_dtm at time zone 'UTC','YYYY')||' '||
  to_char( a.chg_dtm at time zone 'UTC' , 'HH12:MI PM' )  
   like '%07%' `,


   filter_duplicate:`
   select count(*) as cnt from cdm_core.file_onbord_instc a  
where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
and a.dup_ind like '%Y%' `,


            make_dflt_ind:`update cdm_ui_cntnt.ui_sav_srch_nm set make_dflt_ind='N'
            where sav_by_usr_prncpl_id=8`,

            total_rows:`select count(*) as cnt from cdm_core.file_onbord_instc a  
            where a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive')
            and a.file_land_dtm >= (now() - interval '12 month')`,


            grid_data:`

            select file_ref_id,partner,uploaded_date,dset_cd,substr(File_name_1,0,position('.' in File_name_1)-20)||substr(File_name_1,position('.' in File_name_1),length(File_name_1)) as file_name
            ,submission_period,rows_loaded,restatement,dup_ind,submitted_by,file_status,enriched_file,chg_agnt_id,modified_date
            from (
            select '',
                        fil.file_ref_id
                        ,org1.org_nm as Partner
                        , to_char(fil.file_land_dtm at time zone 'UTC','Mon DD')||', ' 
                        ||to_char(fil.file_land_dtm at time zone 'UTC','YYYY')||' '||to_char( fil.file_land_dtm at time zone 'UTC', 'HH12:MI PM' ) as Uploaded_Date
                        ,fil.dset_cd
                         ,substr(fil.file_land_full_pth,length(fil.file_land_full_pth) - position('/' in reverse(fil.file_land_full_pth)) + 2,
                        length(fil.file_land_full_pth)) as File_name_1
                        ,to_char(fil.file_land_dtm,'Mon, YYYY') as submission_period
                        ,fil.rec as rows_loaded
                         ,fil.restate_file_ind as Restatement
                         ,fil.dup_ind as dup_ind
                        ,usr.usr_nm as Submitted_By
                        ,case when fil.latst_onbord_sts_cd='CDM_Inactive' then 'Inactive'
                        when fil.latst_onbord_sts_cd='CDM_Processing_Success' then 'Processed'
                        when fil.latst_onbord_sts_cd='CDM_Published' then 'Published' 
                        when fil.latst_onbord_sts_cd='CDM_Duplicate_Confirmed' then 'Confirmed Duplicate' end as File_status
                       ,case when substr(sub.nrch_data_full_pth,length(sub.nrch_data_full_pth) - position('/' in reverse(sub.nrch_data_full_pth)) + 2,
                        length(sub.nrch_data_full_pth)) is null then 'NA' else substr(sub.nrch_data_full_pth,length(sub.nrch_data_full_pth) - position('/' in reverse(sub.nrch_data_full_pth)) + 2,
                        length(sub.nrch_data_full_pth))  end  as Enriched_File
                        ,fil.chg_agnt_id
                        ,to_char(fil.chg_dtm at time zone 'UTC','Mon DD')||', ' 
                        ||to_char(fil.chg_dtm at time zone 'UTC','YYYY')||' '||to_char( fil.chg_dtm at time zone 'UTC', 'HH12:MI PM' )  as Modified_Date
                        from 
                        cdm_core.file_onbord_instc fil
                        left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
                        inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
                        inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
                        inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
                        inner join cdm_accs_enttl.org org1 on org1.org_id=fil.org_id
                        where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
                        and fil.file_land_dtm >= (now() - interval '12 month')
                        order by fil.file_land_dtm desc
            )a`,

            org_nm:`select o1.org_nm from cdm_accs_enttl.org o1 where org_nm<>'-1' and org_nm<>'Intel' order by org_nm asc`,

            file_name_query:`select
            substr(sub.prcss_data_dump_full_pth,length(sub.prcss_data_dump_full_pth) - position('/' in reverse(sub.prcss_data_dump_full_pth)) + 2,
           length(sub.prcss_data_dump_full_pth)) as File_name
           from 
           cdm_core.file_onbord_instc fil
           left join cdm_core.file_onbord_sub_instc sub on fil.file_instc_id = sub.file_instc_id
           where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive','CDM_Duplicate_Confirmed')
           and fil.file_land_dtm >= (now() - interval '12 month')
           order by fil.file_land_dtm desc limit 1`









    



}