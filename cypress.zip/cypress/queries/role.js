module.exports={
    make_dflt_ind:`update cdm_ui_cntnt.ui_sav_srch_nm set make_dflt_ind='N'
    where sav_by_usr_prncpl_id=8`,
    ww_program_manager:`update cdm_accs_enttl.prncpl_role_asgn set role_id='1' where prncpl_id='8'`,
    bizops:`update cdm_accs_enttl.prncpl_role_asgn set role_id='3' where prncpl_id='8'`,
    account_manager:`update cdm_accs_enttl.prncpl_role_asgn set role_id='2' where prncpl_id='8'`,
    third_party_submitter:`update cdm_accs_enttl.prncpl_role_asgn set role_id='5' where prncpl_id='8'`,
    partner_data_submitter:`update cdm_accs_enttl.prncpl_role_asgn set role_id='6' where prncpl_id='8'`,
    expected_columns:['','File Reference Id',"Partner","Uploaded Date (UTC)","Dataset","File Name",
    "Submission Period","Rows Loaded",
    "Restatement","Duplicate","Submitted By","File Status","Enriched File","Modified By",
    "Modified Date (UTC)"],
    expected_columns_min:['','File Reference Id',"Partner","Uploaded Date (UTC)","Dataset","File Name",
    "Submission Period","Rows Loaded",
    "Restatement","Duplicate","Submitted By","File Status"],
    all_data_count:`select count(*) as cnt from 
    cdm_core.file_onbord_instc fil
    inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
    --inner join cdm_core.file_onbord_sub_instc sb on fil.file_instc_id=sb.file_instc_id 
    where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive')
    and fil.file_land_dtm >= (now() - interval '12 month')`,
    particular_org_data:`select count(*) as cnt from 
    cdm_core.file_onbord_instc fil
    inner join cdm_accs_enttl.usr usr on fil.upld_by_usr_prncpl_id=usr.prncpl_id
    inner join cdm_accs_enttl.prncpl pl on pl.prncpl_id=usr.prncpl_id
    inner join cdm_accs_enttl.org org on org.org_id=pl.org_id
    --inner join cdm_core.file_onbord_sub_instc sb on fil.file_instc_id=sb.file_instc_id 
    where  fil.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive')
    and fil.file_land_dtm >= (now() - interval '12 month') and org.org_id='3'`,
    org_nm:`select o1.org_nm from cdm_accs_enttl.org o1 where org_nm<>'-1' and org_nm<>'Intel' order by org_nm asc`,
    particular_org_nm:`select o1.org_nm from cdm_accs_enttl.org o1 where org_nm<>'-1' and org_nm='Microsoft' order by org_nm asc`,
    delete_save_filtes_ww_prog_manager_1:`DELETE FROM cdm_ui_cntnt.ui_sav_srch_dtl WHERE ui_sav_srch_dtl_id in (select dtl.ui_sav_srch_dtl_id
        FROM
        cdm_ui_cntnt.ui_sav_srch_nm nm
        inner join cdm_ui_cntnt.ui_sav_srch_dtl dtl on nm.ui_sav_srch_nm_id=dtl.ui_sav_srch_nm_id
        where nm.sav_by_usr_prncpl_id='8' and nm.sav_srch_nm='All_partners_ww_program_manager' );`,
    
        delete_save_filtes_ww_prog_manager_2:`  delete from cdm_ui_cntnt.ui_sav_srch_nm where sav_srch_nm='All_partners_ww_program_manager'`,

       current_month_query:` select count(*) as cnt from  cdm_core.file_onbord_instc a  where  a.latst_onbord_sts_cd in ('CDM_Published','CDM_Processing_Success','CDM_Inactive')
and cast(extract(month FROM a.file_land_dtm) as varchar(100)) =  cast(extract(month FROM now()) as varchar(100))`,
delete_save_filtes_intel_bizops_1:`DELETE FROM cdm_ui_cntnt.ui_sav_srch_dtl WHERE ui_sav_srch_dtl_id in (select dtl.ui_sav_srch_dtl_id
    FROM
    cdm_ui_cntnt.ui_sav_srch_nm nm
    inner join cdm_ui_cntnt.ui_sav_srch_dtl dtl on nm.ui_sav_srch_nm_id=dtl.ui_sav_srch_nm_id
    where nm.sav_by_usr_prncpl_id='8' and nm.sav_srch_nm='All_partners_Intel_bizops' );`,

    delete_save_filtes_intel_bizops_2:`  delete from cdm_ui_cntnt.ui_sav_srch_nm where sav_srch_nm='All_partners_Intel_bizops'`,

}