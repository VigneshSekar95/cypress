// ***********************************************************
// This example support/e2e.ts is processed and
// loaded automatically before your test files.
//
// This is a great place to put global configuration and
// behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************

// Import commands.js using ES2015 syntax:
import './commands'
import "cypress-ag-grid";
require('cypress-xpath');
import "cypress-real-events/support";
import addContext from "mochawesome/addContext";


// used to capture screenshot after every test case failure
Cypress.on("test:after:run", (test, runnable) => {
    console.log(runnable)
    if (test.state === "failed") {
      const screenshot = `screenshots/${Cypress.spec.name}/${runnable.parent.title} -- ${test.title} (failed).png`;
      addContext({ test }, screenshot);
    }

});