// ************************Importing libraries***********************************
// 
// Here we import which we require to perform testing with cypress



/// <reference types="cypress" />
import 'cypress-file-upload'            // used to uploading a file via cypress
require('cypress-downloadfile/lib/downloadFileCommand')    //used to download a file by clicking on the link


