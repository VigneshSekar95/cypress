// ************************Storing Environment Variables***********************************
// 
// Here we store all the environment related varaiables which will change based on the environments 
// in a encrypted format. Since all the information like client_id, client_secret etc.. are sensitive information, we are encrypting 
// it and using it to run the test cases.
//
// The Environment variables that are stored are APP_URL, API_URL, Tenant_id, Client_id, Client_secret, scope, 
// resource and sessionstorage values



module.exports= {

    
    // getBaseUrl(env) {
    //     if (env == 'production' || env=='dev' || env=='qa') 
    //         return "http://localhost:3000";
    // },

    getBaseUrl(env) {
        if (env == 'production') 
            return "https://consumption.intel.com"; 
        else if (env == 'dev')
            return "https://consumption-dev.intel.com";
        else if (env == 'qa')
            return "https://consumption-qa.intel.com";
    },


    getAPIBaseUrl(env) { 
        if (env == 'production') 
            return "https://consumption.intel.com"; 
        else if (env == 'qa')
            return "https://consumption-api-qa.intel.com";
        else if (env == 'dev')
            return "https://consumption-api-dev.intel.com";
    },



    getTenantID(env) { 
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: '6f7cdf22beacd2ca4e67e58de1a97300',
                content: '5974ee098a2384bf673d56d9dc38ec398aa5746480825488962cb1fa5081d8e451bfd342'
              }
        else if (env == 'qa')
            return {
                iv: '6f7cdf22beacd2ca4e67e58de1a97300',
                content: '5974ee098a2384bf673d56d9dc38ec398aa5746480825488962cb1fa5081d8e451bfd342'
              };
    },


    getClientID(env) {
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: '2e46f50cb1ab1c3141708af527a35629',
                content: 'b4a8ae06a93f32aa6f8251b6d866fdcef88ebdfde16804aa1b11a166c6a79e16f8191a22'
              }
        else if (env == 'qa')
            return {
                iv: '3b113e26f6316ae48f710c2b99a261a4',
                content: '7048cef361938442e360e8ea61336d1aea99b7c58072f141f72b3669117759a91202eb60'
              };
    },


    getClientSecret(env) {
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: '31a4a990fb1cd6d73b8f78879750c20c',
                content: '08853f0e7e81e2a117f0cd14115721aad836d6e6821a1d7f2732011c48377a954d4462a1d473df4c'
              }
        else if (env == 'qa')
            return {
                iv: 'f5c459217c1e3470eb080c7f75096d79',
                content: '38cb01c166b300f3f17fec64d76dc5238c4a080aac261d182f88dce0e7884d37164dd8a36d12b823'
              };
    },


    getScope(env) {
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: 'f440bc5a4eac0977c51156a31aa687d5',
                content: 'aab9b044d80b3e0eb214bc844fac18ee3ebd595263b9cefe318d502f3df9bb33ff8b0ca265b0dde19fb6ebe082'
              }
        else if (env == 'qa')
            return {
                iv: '065ada4686d650813a0d09730111f9a7',
                content: '0b9dc75f39f1912d99cc4961be47badb2009e2a62de8bbe88936b496dba7508c2474bf1cf9893d8ca95890dcb4fb42eed0aad0ac5713fe9bd489a3533e2e02fb5fe0361ebe2efef69023bd'  
              };
    },


    getResource(env) {
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: '75ef2e81686aa0228700139ac7921d9f',
                content: '0c3529b5285775adef17bbb79df4d130d40a47d3152e59412ff5c97da9082a1d28227542'
              }
        else if (env == 'qa')
            return {
                iv: '75ef2e81686aa0228700139ac7921d9f',
                content: '0c3529b5285775adef17bbb79df4d130d40a47d3152e59412ff5c97da9082a1d28227542'
              };
    },



    getSessionStorage_2_key(env) {
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: '3f15585f5d407e793baa0f7363f88303',
                content: 'b4643829203365465a7b58314bf1b29878850c96e1911c413a6b00fa2e6f10afee708416ee4c384a0b7703af9ec0c9eb4ecf2671f1a34950939299da4d1dc0b848c791ab3209bdf332245025cd2b10b5dbd3e36a727bc1c8de60ea562f54e4dca5371bc3e0dd0415d3fb9ccde76b530d993b24becba10f7ea6a2b94a5715662e'
              }
        else if (env == 'qa')
            return {
                iv: '3f15585f5d407e793baa0f7363f88303',
                content: 'b4643829203365465a7b58314bf1b29878850c96e1911c413a6b00fa2e6f10afee708416ee4c384a0b7703af9ec0c9eb4ecf2671f1a34950939299da4d1dc0b848c791ab3209bdf332245025cd2b10b5dbd3e36a727bc1c8de60ea562f54e4dca5371bc3e0dd0415d3fb9ccde76b530d993b24becba10f7ea6a2b94a5715662e'
              };
    },


    getSessionStorage_2_value(env) {
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: '4ca6a31f66c18885a87c12e6bb6e9438',
                content: 'f23ace533b8403f00c911347a53086a9b7633802dde8b0d78e9d328794c744cd3a1ecedf1153616e09bd1407d9f1cd476c7b39b03104e827bc202e4aba490495d5b86cb26c34cd7d7b4763bac5659b36765be17fdea9d179d7c13aeb4eaf24252d04fcc7bfeb2f5e684d025a94fc8d4fa6a0e287126203b7d2cca43032c9a5ab2948b1dfe545db37abf8156af6d40b0d660f84eec2df75a939f55d47753e462a60a69031e42509f0a640f8de56c1ae7aae97d1089bed962881effc6325ab6186a253849134d8b01d75f61dda863800c953ebc44b4b130eaf06d024a9417b0a952e6f229dab8f3a8a51b48bb82f701098419c42746a7639be39d5eebfa27a09a78882b7dfab1970de594038268b1aa98ef919fb106c909f65242feb0c923e7423aa8f3db0392718d40a47510fc309099a2805ead5aa882bb64ba6b99d549c53c8c7b9bc374cd7fce600f37e8f988870f99dadb6a6a936b2fba00a17fa0814d116bfd12161b7fd95dc493f51b8796885b62e47f30fd84efdf3fdd18f31b02dd5ba46f550e27b65ea71ee8e5605b9d779a664598c1025ac64f78ffb2688fb9db4b8a1bc9142db09cfbf7228a5bc6959c1f9827767476e3f7f93ace586eba399922bea60e6e8d565dc41afa0356a18be748b1cbbfd867a'
              }
        else if (env == 'qa')
            return {
                iv: '4ca6a31f66c18885a87c12e6bb6e9438',
                content: 'f23ace533b8403f00c911347a53086a9b7633802dde8b0d78e9d328794c744cd3a1ecedf1153616e09bd1407d9f1cd476c7b39b03104e827bc202e4aba490495d5b86cb26c34cd7d7b4763bac5659b36765be17fdea9d179d7c13aeb4eaf24252d04fcc7bfeb2f5e684d025a94fc8d4fa6a0e287126203b7d2cca43032c9a5ab2948b1dfe545db37abf8156af6d40b0d660f84eec2df75a939f55d47753e462a60a69031e42509f0a640f8de56c1ae7aae97d1089bed962881effc6325ab6186a253849134d8b01d75f61dda863800c953ebc44b4b130eaf06d024a9417b0a952e6f229dab8f3a8a51b48bb82f701098419c42746a7639be39d5eebfa27a09a78882b7dfab1970de594038268b1aa98ef919fb106c909f65242feb0c923e7423aa8f3db0392718d40a47510fc309099a2805ead5aa882bb64ba6b99d549c53c8c7b9bc374cd7fce600f37e8f988870f99dadb6a6a936b2fba00a17fa0814d116bfd12161b7fd95dc493f51b8796885b62e47f30fd84efdf3fdd18f31b02dd5ba46f550e27b65ea71ee8e5605b9d779a664598c1025ac64f78ffb2688fb9db4b8a1bc9142db09cfbf7228a5bc6959c1f9827767476e3f7f93ace586eba399922bea60e6e8d565dc41afa0356a18be748b1cbbfd867a'
              };
    },

    getSessionStorage_1_key(env) { 
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: '40bc6c2a030417ad8e0ca66555ef6af1',
                content: '3517a93d3885f20790929bc086154b059198c5f6a46e8c2ec3c3d6cb2509c3596212aeaf62a6556a7bfc8ac11c65bc7bba048aa8271cdea0944480f9db085fa03fbd05632f3cf4a4fcfdcbc40688286748ea4962314d2d8182eab2419e6aed8ac4a3f0275d87df416685e825b6d89d0edfc901ecfbc6eed0e3f030476f7d0a001397c20d0b11fc33677fe54e2f8946f6ffe907eeae1bab0b95fcee0fa2fb7218b08a775a68253393b4c9b9cf37442f8954450d1452cafc0c533bef427435d691961c2d658031839eb3d35c10bfd612c5ce014fdae8df8d8693e35d3cee283ede8e12e07419b3e7c967ef0d7643e340d50dc4b2b58f7789c8516616bb9418f14dc5f528e9e16e05b495d271d79061b032'
              }
        else if (env == 'qa')
            return {
                iv: 'd770c42bf3cec7e5df6625832b4aaaed',
                content: '93c24c2b91d9d83ce5a0bbf0c87e003c912b510cb183872d4ddeaa00b5b665b985090984ee8683776ae1a7340945d50b0c1e687f801398ad76923a48ef5a18a3817b8426445e442ebe9d48d1f7045fb2b4a2565c9cff45f62381bd54e39e6301a94ab703b92913f6fe7f1ea76af5537293120c06dc8c8131f51f86955525eb73ca2ec157fdb66bc0cacc5814edec2567efa22ae9ee60f64de2d8b3630c62ae9b53ef5677d2100e45ec860f91e9d85e2cdf85a8a191e2d07dc6d14498efa9d44209f7cafd7d6b74a3b3200c9448739c32245ee7d5d943a596c5b8c66dc8017497d9a223c4c0539bb404b87347ce2d3f2e6966e905f04ed17b46a732d96553023345f1042ed2f33623494fdc8625d11f31'
              };
    },

    getSessionStorage_1_value1(env) {
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: 'ace533e77b7a391c3c5f9eedc656580b',
                content: '94de5f0e4643a5482751f418a965d5f6892650985e27f466cbea95190d0f4c2e0897f9d57394ed0611cc5e74ce8c44723df7421f9c112c46aba882b4b8a34ecec718833846cc2169327ff1da54ee99c7dcded9d7a238c1b87736680470df6307e3962909ce11e6ce0b439ceec04d6ba36653cf5881cc658eecd8b8c49604443168c1b87910b3'
              }
        else if (env == 'qa')
            return {
                iv: 'ace533e77b7a391c3c5f9eedc656580b',
                content: '94de5f0e4643a5482751f418a965d5f6892650985e27f466cbea95190d0f4c2e0897f9d57394ed0611cc5e74ce8c44723df7421f9c112c46aba882b4b8a34ecec718833846cc2169327ff1da54ee99c7dcded9d7a238c1b87736680470df6307e3962909ce11e6ce0b439ceec04d6ba36653cf5881cc658eecd8b8c49604443168c1b87910b3'
              };
    },


    getSessionStorage_1_value2(env) {
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: '9b85afd3c221086c0ad9084b891f8dc8',
                content: '1cd88548e96453e60d3d08486a0ebee725eb43fd9aa81ca3d5bd604cad45b3ecc5afc82f3faaac22f605fb02722472c438ce69f0c14b701788221acfedc3490074cf71103b534f6038c4ff42f1d292756f6c38c18bd3b3ab756fb4ac3e15823c9e442af745c57035c2f2a80e2c43de951c7c29a20587a78ac970a9815692df2a229487f257f9c9079e803158110167be3a150c665070ae23eac958ba1101ff47eca5918cc14c7281db8ba0fb84eb58ac5231e2c6b3fe11f620a01e72b10e44614cd90d316a2d229d0e2c4ed984ccf875430563386a5818e9c6cab5b9d714d792b163257965f7a6b61b33d0a9d4234840c6029ddbe0891e76e0c100659c678f8bc2fa'
              }
        else if (env == 'qa')
            return {
                iv: '692988564c3bbf3b6ec55af15cb64976',
                content: '58715511ab1d1946b2a3bc6079c50542f8937077adf57f186f2fafe6180375185c0c7150a8ec8ae8da3af8b46330706c4c7ef5c544a8f9a73933a04556a0703edee5b076436da213b3d7cc260e1527dbcc0bc89fea0878053faf13d9c9ef263916ad5983c6e89e5295414e1cefef9ce72da1da907c7441d11c95b3683d73d54d335f0aeebbbc6fb6fb2c92403cdec6a422adffa62a8a0add67bee9be8d60b8d97cbd22365c9d7c20553ec511838d152391183173fe4ec1023b28ffee81e32e815fc165619dc2a1ebbdcf94a007df8c6f04fc09cf9ffdb6d996d59f7260df9bec16ae6bec497958c2ee5163a35a1915e4a602729ff9d6406599b86090f32faf153e4b'
              };
    },

    getpostgres_conn(env){
        if (env == 'production') 
            return ""; 
        else if (env == 'dev')
            return {
                iv: '8c094c700e132289e308bd903446506d',
                content: 'd8ece221e2d2a6a2b14ae769b6312e708eddb003264ad5a68041e27660df883ac0cfd847552c55609159bac7cb31b15076f1821da9fc424c2781a7d683b16180a19d5edd6a13a080852310d990754b948570d73218d70342d19b0d9a41e785099bc53cfc4fc26441c8f2e22e4469e6b013ea114c484645c4b51d4ebffc1683aaf6bb5250403606f36c801d8190f4c04ee6b14d07de1f53bfe9371556c37fadb7485beea8bc27e7ea868ace649d02a334f0602d5703cc35394297050c8e57848685f30b87e94f5813d1ab8af590cedecf4ef8b8355e3fa6054c446f563579894b694908c2c4aa006271bd35921fb45236e2c431e228a3924f7cd2462d91193cddeb25f41412555867f030ead22941e599276d3b9e67a6b82ec8e727912c1e0014d36f726ce4d57ebdef23d9921c0783970a6fef9edd5e9a0aaa9f384aec40a81023d448aaa7c1760e4a246ce3693ad88476d04daa48f95073037cc365b06bdcfdd3157aa99b257dce31d4a8aac9dc7acb075c553f7cd4cf53'
              }
        else if (env == 'qa')
            return {
                iv: 'a57939ba3e39f2f6d85e76ba302625a3',
                content: 'a8734808f7316800558e9971198855daff1798ed9554b0b72f7411853942edebb7e301bcae68acaa2469154d38016ea9d63b91a21b19e3ef062fbca1b5058160917b669937b66881c02fc9702c633658927645ff7164534be7a5c37589a3b31a72acc953716bab7394b81a214d0ddd156e4121e969bb8ba409bf1a5a64ea9dc6c2b41f76cb6cff05477dc3bc79f45cec1daa155ab6c83fabbe9ac16b809346a826fe1b060cd12cf68606c923afab702926611741c8e858ea3ad5802864ae3d608454429285ad2e470ecf9f5b80f84526ab20e343161a486fc83ee6ead4d8e9914423c615d5ad66da0c700682e5b80cced9545f8d82b5e9f60c361fff77b94c838e24ca343c739fb8f4dd2f5401f2b6fccc4ba00263435e5a10e027609a33578ac12e0394c13b8973db83a602bd9ef659933379e75ca6f342476efaabc681048e5f69e283ed5c63fa8895308b7a8c913a5595919fca5c860b9e'
              };
    }




    

}